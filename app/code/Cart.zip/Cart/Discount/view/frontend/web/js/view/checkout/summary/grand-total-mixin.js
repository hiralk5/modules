define([
    'jquery', 
    'mage/utils/wrapper',
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/quote',
    'Magento_Catalog/js/price-utils',
    'Magento_Checkout/js/model/totals'
], function ($, wrapper,Component, quote, priceUtils, totals) {
    'use strict';
    
    return function (grandTotal) {

        /** Override default place order action and add agreement_ids to request */
        return wrapper.wrap(grandTotal, function (originalAction, grand) {
            grand = totals.getSegment('grand_total').value - totals.getSegment('discount-amount').value;
        });
            return grand;
    };
});