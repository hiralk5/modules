define(
    [
        'Cart_Discount/js/view/checkout/summary/custom-discount',
        'jquery',
        'jquery/ui'
    ],
    function (Component,$) {
        'use strict';

        return Component.extend({

            /**
             * @override
             */
            isDisplayed: function () {
                return true;
            }
        });
    }
);