define(
    [
       'jquery',
       'Magento_Checkout/js/view/summary/abstract-total',
       'Magento_Checkout/js/model/quote',
       'Magento_Checkout/js/model/totals',
       'Magento_Catalog/js/price-utils'
    ],
    function ($,Component,quote,totals,priceUtils) {
        "use strict";
        return Component.extend({
            defaults: {
                //template: 'Cart_Discount/checkout/summary/custom-discount'
            },
            getPureValue: function () {
                var totals = quote.getTotals()();

                if (totals) {
                    return totals['subtotal'];
                }

                return quote['subtotal'];
            },
            isDisplayedCustomdiscountTotal : function () {
                return true;
            },
            getCustomdiscountTotal : function () {
                var price =  parseFloat(totals.getSegment('subtotal').value);
                if(price >= 200){
                    var discount = price *20/100;
                    return '$'.concat(parseFloat(discount));
                }
                return 'Not Applicable';
                // return this.getFormattedPrice(this.getPureValue());
            }
         });
    }
);