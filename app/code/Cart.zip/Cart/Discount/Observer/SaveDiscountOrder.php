<?php
namespace Cart\Discount\Observer;

use \Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer;

class SaveDiscountOrder implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer) 
    {
        $total = $observer->getData('total');
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
$logger = new \Zend_Log();
$logger->addWriter($writer);
$logger->info('Your text message');
$logger->info(json_encode($total));
print_r($total);exit;
        /*$subTotal = $total->getSubtotal();
        $discount = $subTotal * 20/100;
        // $taxAmount = $subTotal * $taxRate;
        $shippingAmount = $total->getShippingAmount();
        $totalAmount =  $subTotal  + $shippingAmount - $discount;*/
        
        $label               = 'Custom Discount';
        $subtotal            = $total->getSubtotal();
        $discountAmount      = $subtotal >= 200 ? $subtotal*20/100 : 0;   
        $appliedCartDiscount = 0;

        if($total->getDiscountDescription()) {
            // If a discount exists in cart and another discount is applied, the add both discounts.
            $appliedCartDiscount = $total->getDiscountAmount();
            $discountAmount      = $total->getDiscountAmount()+$discountAmount;
            $label               = $total->getDiscountDescription().', '.$label;
        }   

        $total->setDiscountDescription($label);
        $total->setDiscountAmount(-$discountAmount);
        $total->setBaseDiscountAmount(-$discountAmount);
        $total->setSubtotalWithDiscount($total->getSubtotal() - $discountAmount);
        $total->setBaseSubtotalWithDiscount($total->getBaseSubtotal() - $discountAmount);
        if(isset($appliedCartDiscount)) {
            $total->addTotalAmount($this->getCode(), $discountAmount - $appliedCartDiscount);
            $total->addBaseTotalAmount($this->getCode(), $discountAmount - $appliedCartDiscount);
        } else {
            $total->addTotalAmount($this->getCode(), $discountAmount);
            $total->addBaseTotalAmount($this->getCode(), $discountAmount);
        }

        /*$total->setSubtotal($subTotal);
        $total->setBaseSubtotal($subTotal);
        $total->setGrandTotal($totalAmount);
        $total->setGrandTotal($totalAmount);
        $total->setBaseGrandTotal($totalAmount);
        $total->setTaxAmount($taxAmount);*/
 
        return $this;
    }
}