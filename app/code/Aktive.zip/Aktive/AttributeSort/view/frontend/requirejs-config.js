var config = {
    config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'Aktive_AttributeSort/js/configurable-mixin': true
            }
        }
    }
};