<?php
/**
 * Razor Pay Full payment to
 */

namespace Razorpay\Magento\Cron;

class RazorPayOrderPush
{
    /**
     * @var \Razorpay\Magento\Helper\LogfileDetail
     */
    private $logFile;

    /**
     * @var \Razorpay\Magento\Model\ResourceModel\RazorpayPayments
     */
    private $_resourceModel;

    /**
     * @var \Razorpay\Magento\Model\Mediaagility\Apicall
     */
    private $apiCallModel;

    /**
     * @var \Magento\Sales\Model\Order
     */
    private $_order;

    /**
     * @param \Magento\Sales\Model\Order $order
     * @param \Razorpay\Magento\Model\Mediaagility\Apicall $apiCallModel
     * @param \Razorpay\Magento\Model\ResourceModel\RazorpayPayments $dbResourceModel
     * @param \Razorpay\Magento\Helper\LogfileDetail $logFile
     */
    public function __construct(
        \Magento\Sales\Model\Order $order,
        \Razorpay\Magento\Model\Mediaagility\Apicall $apiCallModel,
        \Razorpay\Magento\Model\ResourceModel\RazorpayPayments $dbResourceModel,
        \Razorpay\Magento\Helper\LogfileDetail $logFile
    ) {
        $this->_order = $order;
        $this->apiCallModel = $apiCallModel;
        $this->_resourceModel = $dbResourceModel;
        $this->logFile = $logFile;
    }

    /**
     * @return void
     */
    public function execute()
    {
        $logger = $this->logFile->createJobLog();
        $query = "select *from razorpay_order_push where order_push_flag = 1 limit 50";
        $resultset = $this->_resourceModel->getConnection()->fetchAll($query);

        if ($resultset && !empty($resultset) && count($resultset) > 0) {

            $ids = array_values(array_column($resultset, 'order_increment_id'));
                $imploded = implode(',', $ids);
            if (!empty($imploded)) {
                $sql = "update razorpay_order_push set order_push_flag = 2 where order_increment_id in ($imploded)";
                $this->_resourceModel->getConnection()->query($sql);
            }

            $razorOrderPush = 0;
            foreach ($resultset as $row) {
                $order = $this->_order->loadByIncrementId($row['order_increment_id']);

                if ($order && $order->getId()) {

                    $successPush = $this->apiCallModel->createJob($row, $logger);
                    if ($successPush) {
                        $razorOrderPush++;
                    }
                }
            }

        }
    }
}
