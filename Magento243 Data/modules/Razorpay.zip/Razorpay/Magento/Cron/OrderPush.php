<?php
/**
 * @Module         : Razorpay Payment
 * @Package        : Razorpay_Magento
 * @Description    : This is cron file that will api for razorpay order push to odm
 * @Developer      : Shaunak Datar <shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Cron;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Razorpay\Magento\Model\OnlineOrderPush;
use Embitel\ApiCalls\Helper\Data as ApiHelper;

class OrderPush
{
    /**
     * Get Recepients email
     */
    public const CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER = 'atos_configuration/orderpush/orderpush_email';

    /**
     * Get Order push failed Email Temaplate
     */
    public const ORDER_API_FAILED_EMAIL = 'atos_configuration/orderpush/orderpush_failed_email_template';
    /*Template id */

    /**
     * Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var Razorpay\Magento\Model\OnlineOrderPush
     */
    protected $onlineOrderPush;

    /**
     * @var ApiHelper
     */
    private $apiHelper;

    /**
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param TransportBuilder $transportBuilder
     * @param OnlineOrderPush $onlineOrderPush
     * @param ApiHelper $apiHelper
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        TransportBuilder $transportBuilder,
        OnlineOrderPush $onlineOrderPush,
        ApiHelper $apiHelper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->transportBuilder = $transportBuilder;
        $this->onlineOrderPush = $onlineOrderPush;
        $this->apiHelper = $apiHelper;
    }

    /**
     * Execute Function Will initially whenever cron runs
     */
    public function execute()
    {
        try {
            $onlineOrders = $this->onlineOrderPush->getCollection()->addFieldToFilter('status', 0);

            if ($onlineOrders->count() > 0) {

                $requestUrl = $this->scopeConfig->getValue(
                    'razorpay/razorpay_odm_url_grp/razorpay_odm_push',
                    ScopeInterface::SCOPE_STORE
                );

                $headerkey = $this->scopeConfig->getValue(
                    'razorpay/razorpay_odm_url_grp/razorpay_odm_push_header_key',
                    ScopeInterface::SCOPE_STORE
                );

                $headerValue = $this->scopeConfig->getValue(
                    'razorpay/razorpay_odm_url_grp/razorpay_odm_push_header_value',
                    ScopeInterface::SCOPE_STORE
                );

                $headers = ['Content-Type: application/json'];
                if ($headerkey && $headerValue) {
                    $headers = ['Content-Type: application/json',$headerkey.':'.$headerValue];
                }

                foreach ($onlineOrders as $item) {
                    $logMessage = '';
                    $jsonData = $item->getRequestParams();

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $requestUrl);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                    $result = curl_exec($ch);
                    $result=  json_decode($result, true);
                    $result=  json_decode($result, true);
                    //$result = array("Status" => 'SUCCESS'); // hardcode value for testing
                    if (isset($result['Status']) && $result['Status'] == 'SUCCESS') {
                        $logMessage = 'Order Pushed : Order ID - '.$item->getOrderId().'---'.$result['Status'];
                        $id = $item->getEntityId();
                        $orderpushRow = $this->onlineOrderPush->load($id);
                        $orderpushRow->setStatus(1);
                        $orderpushRow->save();
                    } else {
                        $success =     $this->sendOrderPushApiFailedEmail($item, $requestUrl, $jsonData, $result);
                        $logMessage .= 'Error while order push : Order ID - '.$item->getOrderId();
                    }
                }
            } else {
                $logMessage = 'No Order Push items';
            }
        } catch (\Exception $e) {
            $logMessage = "Error ".$e->getMessage();
            //$logMessage = 'No Order Push items';
        }
    }

     /**
      * Send Email of failed Order API
      *
      * @param   integer     $orderId
      * @param   string         $apiUrl
      * @param   object         $requestData
      * @param   object         $responseData
      * @return  void
      * @author  Ronak Chauhan - developed
      */
    public function sendOrderPushApiFailedEmail($order, $apiUrl, $requestData, $responseData)
    {
        $orderPushInfo = [];
        $orderPushInfo['order_id'] = $order->getOrderId();
        $orderPushInfo['order_push_url'] = $apiUrl;
        $orderPushInfo['request_data'] = $requestData;
        $orderPushInfo['response_data'] = var_export($responseData, true);

        $postObject = new \Magento\Framework\DataObject();
        $postObject->setData($orderPushInfo);

        $templateData = ['orderpush' => $postObject];

        $storeId = $this->storeManager->getStore()->getId();
        $recipients = explode(",", $this->getEmailRecipient());

        // @var \Magento\Framework\Mail\Template\TransportBuilder $transport
        $transport = $this->transportBuilder->setTemplateIdentifier(
            $this->getEmailTemplateId()
        )->setTemplateOptions(
            ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeId]
        )->setTemplateVars(
            $templateData
        )->setFrom(
            $this->getsender()
        )->addTo(
            $recipients
        )->getTransport();

        $transport->sendMessage();

        return $this;
    }

     /**
      * Get Sender details from configuration.
      *
      * @param  string $type
      * @param  integer $storeId
      * @return  array
      */
    public function getSender($type = null, $storeId = null)
    {
        $senderName = $this->scopeConfig->getValue('trans_email/ident_general/name', ScopeInterface::SCOPE_STORE);
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_general/email', ScopeInterface::SCOPE_STORE);

        $sender ['name'] = $senderName;
        $sender ['email'] = $senderEmail;

        return $sender;
    }


    /**
     * Retrieve Template id of order push failed from configuration.
     *
     * @param  integer $storeId
     * @return string
     */
    public function getEmailTemplateId($storeId = null)
    {
        return $this->scopeConfig->getValue(
            self::ORDER_API_FAILED_EMAIL,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * Get Email Recipients from configuration.
     *
     * @param  integer $storeId
     * @return string]
     */
    public function getEmailRecipient($storeId = null)
    {
        return  $this->scopeConfig->getValue(
            self::CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

     /*
     * function to push notification to ISD App
     * param 1 - object
     * param 2 - Array
     * return boolean
     */
    public function pushIsdAppNotification($item, $requestParamsData)
    {
        $orderId = $item->getOrderId();
        $productSku = isset($requestParamsData['ProductDetails']['SKU']) ? $requestParamsData['ProductDetails']['SKU'] : '';
        $dealerId = isset($requestParamsData['OrderFulfillmentStatus']['DealerCode']) ? $requestParamsData['OrderFulfillmentStatus']['DealerCode'] : '';

        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/isdapp_notification.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        if ($orderId != '' && $productSku != '' && $dealerId != '') {
            $auth_url       = $this->scopeConfig->getValue('atos_configuration/isd_app_config/isd_app_auth_url', ScopeInterface::SCOPE_STORE);
            $auth_username  = $this->scopeConfig->getValue('atos_configuration/isd_app_config/isd_app_auth_username', ScopeInterface::SCOPE_STORE);
            $auth_password  = $this->scopeConfig->getValue('atos_configuration/isd_app_config/isd_app_auth_password', ScopeInterface::SCOPE_STORE);
            $push_url       = $this->scopeConfig->getValue('atos_configuration/isd_app_config/isd_app_push_url', ScopeInterface::SCOPE_STORE);
            $grant_type     = 'password';
            $auth_headers = ['Content-Type: application/x-www-form-urlencoded'];
            $auth_post = "auth_type=".$grant_type."&user_name=".$auth_username."&password=".$auth_password;

            $apiRequest   = [
                'key'   => 'abc',
                'data'  => ['dealer_id' => $dealerId]
            ];
            $resultApiData = [];
            $dealerUserName = '';
            $apiUrl = $this->scopeConfig->getValue('dps_api_urls/general/dps_dealerusername_api_url', ScopeInterface::SCOPE_STORE);
            $jsonApiData = $this->apiHelper->ApiGetData($apiUrl, $apiRequest, 0);
            $resultApiData = json_decode($jsonApiData, true);

            if (!empty($resultApiData)) {
                $dealerUserName = isset($resultApiData['data']['dealerInfo'][0]['dealer_userName']) ? $resultApiData['data']['dealerInfo'][0]['dealer_userName'] : '';
            }
            if ($dealerUserName != '') {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $auth_url);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $auth_post);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_HTTPHEADER, $auth_headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                $response = curl_exec($ch);
                if ($errno = curl_errno($ch)) {
                    $error_message = curl_strerror($errno);
                    $logger->info('cURL error ('.$errno.'): '.$error_message);
                    return false;
                }
                curl_close($ch);
                $result = json_decode($response, true);
                $authtoken = isset($result['authToken']) ? $result['authToken'] : '';

                if ($authtoken) {
                     $data = [];
                     $listType = "PROFILE";
                     $msg = 'You have order number '.$orderId.' for '.$productSku.' pending for confirmation';
                     $optionData = [["name" => 'TEST_MSG',"value" => $msg]]; //TEST_MSG is the identifier for push API
                     $data['recipientData'] = [[
                        "customerId" => $dealerUserName,
                        "emailAddress" => null,
                        "recipientId" => null,
                        "mobileNumber" => null,
                        "emailSHA256Hash" => null,
                        "emailMD5Hash" => null,
                        "deviceId" => null,
                        "apiKey" => null,
                        "listType" => $listType,
                        "optionalData" => $optionData
                     ]];
                     $jsonRequestParams = json_encode($data);
                     $ch = curl_init();
                     curl_setopt($ch, CURLOPT_URL, $push_url);
                     curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json','Authorization:'.$authtoken]);
                     curl_setopt($ch, CURLOPT_POST, 1);
                     curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonRequestParams);
                     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                     curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                     $push_response = curl_exec($ch);
                     $logger->info('---json Request---');
                     $logger->info($jsonRequestParams);
                     $logger->info('---json Response---');
                     $logger->info($push_response);
                     if ($errno = curl_errno($ch)) {
                         $error_message = curl_strerror($errno);
                         $logger->info('cURL error ('.$errno.'): '.$error_message);
                         return false;
                     }
                     curl_close($ch);
                     $push_result = json_decode($push_response, true);
                     return true;
                } else {
                    $logger->info('Auth token not available');
                }
            } else {
                $logger->info('Dealer UserName not available');
            }
        } else {
            $logger->info('orderID or SKU or Dealer ID not available');
        }
        return false;
    }
}
