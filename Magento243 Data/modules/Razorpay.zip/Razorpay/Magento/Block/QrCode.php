<?php
/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Razorpay\Magento\Block;

class QrCode extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
    }

    /**
     *
     * @return mixed
     */
    public function getPreciseScript()
    {
        return $this->scopeConfig->getValue(
            'razorpay/precision_market/precision_market_domain',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );
    }

    /**
     *
     * @return mixed
     */
    public function getSubdomain()
    {
        return $this->scopeConfig->getValue(
            'razorpay/precision_market/precision_market_subdomain',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );
    }
}
