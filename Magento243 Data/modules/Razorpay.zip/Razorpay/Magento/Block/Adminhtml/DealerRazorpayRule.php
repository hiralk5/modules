<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */
namespace Razorpay\Magento\Block\Adminhtml;

class DealerRazorpayRule extends \Magento\Backend\Block\Widget\Grid\Container
{

    /**
     * @inheritDoc
     */
    protected function _construct()
    {

        $this->_controller = 'adminhtml_DealerRazorpayRule';
        $this->_blockGroup = 'Razorpay_Magento';
        $this->_headerText = __('Banners');

        parent::_construct();

            $this->buttonList->update('add', 'label', __('Add'));

             $this->buttonList->add(
                 'inportbtn',
                 [
                    'id' => 'importbtn',
                    'label' => __('Import'),
                    'class' => 'action- scalable primary',
                    'button_class' => '',
                    'onclick' => 'setLocation(\'' . $this->getUrl("razorpay/dealers/importdealerrule") . '\')',
                 ],
                 0
             );
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

     /**
      * Render grid
      *
      * @return string
      */
    public function getGridHtml()
    {
        return $this->getChildHtml('grid');
    }
}
