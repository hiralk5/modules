<?php

namespace Razorpay\Magento\Block\Adminhtml\Transaction;

use Razorpay\Magento\Model\ResourceModel\RazorpayPayments\CollectionFactory as RazorpayPayments;

/**
 * Adminhtml custom category grid
 */
class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{

    /**
     * @var RazorpayPayments
     */
    protected $razorpayCollection;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param RazorpayPayments $razorpayCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        RazorpayPayments $razorpayCollection,
        array $data = []
    ) {
        $this->razorpayCollection = $razorpayCollection;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('razorpayPayment');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setUseAjax(true);
        $this->setSaveParametersInSession(true);
        $this->setFilterVisibility(true);
    }

    /**
     * Prepare collection
     *
     * @return \Magento\Backend\Block\Widget\Grid
     */
    protected function _prepareCollection()
    {
        $collection = $this->razorpayCollection->create();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    /**
     * Prepare columns
     *
     * @return \Magento\Backend\Block\Widget\Grid\Extended
     */
    protected function _prepareColumns()
    {
        $this->addColumn('id', ['header'    => __('ID'),'index'     => 'id']);

        $this->addColumn(
            'order_id',
            [
                'header' => __('Order ID'),
                'index' => 'order_id',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'order_increment_id',
            [
                'header' => __('Increment ID'),
                'index' => 'order_increment_id',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'razorpay_order_id',
            [
                'header' => __('Razorpay Order ID'),
                'index' => 'razorpay_order_id',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'razorpay_request',
            [
                'header' => __('Request Data'),
                'index' => 'razorpay_request',
                'type' => 'text',
                'width' => '30px',
                'filter' => false,
                'sortable' => false
            ]
        );

        $this->addColumn(
            'razorpay_response',
            [
                'header' => __('Response Data'),
                'index' => 'razorpay_response',
                'type' => 'text',
                'width' => '30px',
                'filter' => false,
                'sortable' => false
            ]
        );


        $this->addColumn(
            'created_at',
            [
                'header' => __('Created At'),
                'index' => 'created_at',
                'type' => 'datetime',
                'filter' => false
            ]
        );
        $this->addColumn(
            'transaction_status',
            [
                'header' => __('Status'),
                'index' => 'transaction_status',
                'type' => 'text'
            ]
        );
        $this->addColumn(
            'transaction_type',
            [
                'header' => __('Transaction Type'),
                'index' => 'transaction_type',
                'type' => 'text'
            ]
        );
        $this->addColumn(
            'transaction_to',
            [
                'header' => __('Transaction To'),
                'index' => 'transaction_to',
                'type' => 'text'
            ]
        );
        $this->addExportType('*/transaction/exportCsv', __('CSV'));
        return parent::_prepareColumns();
    }

    /**
     * Get grid url
     *
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('razorpay/*/grid', ['_current' => true]);
    }
}
