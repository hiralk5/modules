<?php

namespace Razorpay\Magento\Block\Adminhtml;

class Transaction extends \Magento\Backend\Block\Widget\Grid\Container
{
     /**
      * @param \Magento\Backend\Block\Widget\Context $context
      * @param array $data
      */
    public function __construct(\Magento\Backend\Block\Widget\Context $context, array $data = [])
    {
        parent::__construct($context, $data);
    }
    
    protected function _construct()
    {
        
        $this->_controller = 'adminhtml_transaction';
        $this->_blockGroup = 'Razorpay_Magento';
        $this->_headerText = __('Razorpay');
        parent::_construct();
        $this->removeButton('add');
    }
    
    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }
    
     /**
      * Render grid
      *
      * @return string
      */
    public function getGridHtml()
    {
        return $this->getChildHtml('grid');
    }
}
