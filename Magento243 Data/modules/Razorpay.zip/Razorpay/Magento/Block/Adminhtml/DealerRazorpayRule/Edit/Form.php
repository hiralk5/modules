<?php
/**
 * @Module         : Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : prepare edit/insert form for adding razorpay dealer rule
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @inheritDoc
     */
    protected function _prepareForm()
    {
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post','enctype' => 'multipart/form-data']]
        );
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
