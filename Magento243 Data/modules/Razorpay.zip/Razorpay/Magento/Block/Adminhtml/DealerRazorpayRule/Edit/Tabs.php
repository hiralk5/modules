<?php
/**
 * @Module         : Razorpay_Magento
 * @Package        : Razorpay_Magento
 * @Description    : Displays tabs in razorpay dealer rule grid
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('page_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Dealer Razorpay'));
    }
}
