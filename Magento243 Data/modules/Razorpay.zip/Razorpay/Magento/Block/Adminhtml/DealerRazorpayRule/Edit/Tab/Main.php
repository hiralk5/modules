<?php

/**
 * @Module         : Dealer Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : Dealer Razorpay Module
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule\Edit\Tab;

class Main extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @var \Razorpay\Magento\Model\DealerRazorpayRule
     */
    protected $dealerModel;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param \Razorpay\Magento\Model\DealerRazorpayRule $dealerModel
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        \Razorpay\Magento\Model\DealerRazorpayRule $dealerModel,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        $this->dealerModel = $dealerModel;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * @inheritDoc
     */
    public function getTabLabel()
    {
        return __('Dealers Razorpay');
    }

    /**
     * @inheritDoc
     */
    public function getTabTitle()
    {
        return __('Dealers Razorpay');
    }

    /**
     * @inheritDoc
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * @inheritDoc
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * @inheritDoc
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('razorpay');
        $readonly = false;
        if ($model->getDealerId() !== null) {
            $readonly = true;
        }

        $form = $this->_formFactory->create();

        $form->setHtmlIdPrefix('question_main_');

        $fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Dealers Razorpay')]);

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $dealerRazorpay = $this->dealerModel->getCollection();

        if ($readonly) {
            $fieldset->addField(
                'dealer_id',
                'text',
                [
                'name' => 'dealer_id',
                'label' => __('Dealer Id'),
                'title' => __('Dealer Id'),
                'required' => true,
                'readonly' => true
                ]
            );
        } else {
            $fieldset->addField(
                'dealer_id',
                'text',
                [
                'name' => 'dealer_id',
                'label' => __('Dealer Id'),
                'title' => __('Dealer Id'),
                'required' => true
                ]
            );
        }

        $fieldset->addField(
            'dealer_razorpay_account',
            'text',
            [
            'name' => 'dealer_razorpay_account',
            'label' => __('Razorpay Account'),
            'title' => __('Razorpay Account'),
            'required' => true
                ]
        );

        $fieldset->addField(
            'default_percentage',
            'text',
            [
            'name' => 'default_percentage',
            'label' => __('Percentage'),
            'title' => __('Percentage'),
            'required' => true
                ]
        );

        $fieldset->addField(
            'fp_cancel_amount',
            'text',
            [
            'name' => 'fp_cancel_amount',
            'label' => __('FP Cancel Amount'),
            'title' => __('FP Cancel Amount'),
            'required' => true
                ]
        );

        $fieldset->addField(
            'fp_deduction_percentage',
            'text',
            [
            'name' => 'fp_deduction_percentage',
            'label' => __('FP Deduction Percent'),
            'title' => __('FP Deduction Percent'),
            'required' => true
                ]
        );

        $fieldset->addField(
            'full_payment_flag',
            'select',
            [
            'name' => 'full_payment_flag',
            'label' => __('FP Status'),
            'title' => __('FP Status'),
            'values' => [['label' => "Active", 'value' => "1"], ['label' => "Inactive", 'value' => "0"]],
            'required' => true,]
        );

        $fieldset->addField(
            'status',
            'select',
            [
            'name' => 'status',
            'label' => __('Status'),
            'title' => __('Status'),
            'values' => [['label' => "Active", 'value' => "1"], ['label' => "Inactive", 'value' => "0"]],
            'required' => true,]
        );

        $data = $model->getData();


        $this->_eventManager->dispatch('adminhtml_dealers_edit_tab_main_prepare_form', ['form' => $form]);
        $form->setValues($data);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}
