<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */

namespace Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule;

use Razorpay\Magento\Model\ResourceModel\DealerRazorpayRule\CollectionFactory as RazorpayCollection;

/**
 * Adminhtml custom category grid
 */
class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{

    /**
     * @var RazorpayCollection
     */
    protected $razorpayCollection;

    /**
     * @var \Razorpay\Magento\Helper\RazorpayHelper
     */
    protected $razorpayHelper;

    /**
     * @var RenderData
     */
    private $renderData;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \Razorpay\Magento\Helper\RazorpayHelper $razorpayHelper
     * @param RazorpayCollection $razorpayCollection
     * @param RenderData $renderData
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \Razorpay\Magento\Helper\RazorpayHelper $razorpayHelper,
        RazorpayCollection $razorpayCollection,
        \Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule\RenderData $renderData,
        array $data = []
    ) {
        $this->razorpayHelper = $razorpayHelper;
        $this->razorpayCollection = $razorpayCollection;
        $this->renderData = $renderData;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {

        parent::_construct();
        $this->setId('razorpayGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('DESC');
        $this->setUseAjax(true);
        $this->setSaveParametersInSession(true);
         $this->setFilterVisibility(true);
    }

    /**
     * Prepare collection
     *
     * @return \Magento\Backend\Block\Widget\Grid
     */
    protected function _prepareCollection()
    {
        $collection = $this->razorpayCollection->create();
        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    /**
     * Prepare columns
     *
     * @return \Magento\Backend\Block\Widget\Grid\Extended
     */
    protected function _prepareColumns()
    {
        $this->addColumn('id', ['header'    => __('ID'),'index'     => 'id',]);

        $this->addColumn(
            'dealer_id',
            [
                'header' => __('Dealer Id'),
                'index' => 'dealer_id',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'dealer_razorpay_account',
            [
                'header' => __('Razorpay Account'),
                'index' => 'dealer_razorpay_account',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'default_percentage',
            [
                'header' => __('Percent Deduction'),
                'index' => 'default_percentage',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'fp_cancel_amount',
            [
                'header' => __('Cancel Charge Amount'),
                'index' => 'fp_cancel_amount',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'fp_deduction_percentage',
            [
                'header' => __('FP Deduction Percent'),
                'index' => 'fp_deduction_percentage',
                'type' => 'text'
            ]
        );

        $this->addColumn(
            'full_payment_flag',
            [
                'header' => __('FP Payment'),
                'index' => 'full_payment_flag',
                'type' => 'options',
                'options' => $this->razorpayHelper->getStatus(),
            ]
        );


        $this->addColumn(
            'status',
            [
                'header' => __('Status'),
                'index' => 'status',
                'type' => 'options',
                'options' => $this->razorpayHelper->getStatus(),
            ]
        );

        $this->addColumn(
            'edit',
            [
            'header' => __('Edit'),
            'type' => 'action',
            'getter' => 'getId',
            'actions' => [
                [
                    'caption' => __('Edit'),
                    'url' => [
                        'base' => '*/*/edit'
                    ],
                    'field' => 'id'
                ]
            ],
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
            'header_css_class' => 'col-action',
            'column_css_class' => 'col-action'
                ]
        );

        $this->addColumn(
            'delete',
            [
            'header' => __('Delete'),
            'type' => 'action',
            'getter' => 'getId',
            'actions' => [
                [
                    'caption' => __('Delete'),
                    'url' => [
                        'base' => '*/*/delete',
                        'params' => ['store' => $this->getRequest()->getParam('store')]
                    ],
                    'confirm' => __('Are you sure?'),
                    'field' => 'id'
                ]
            ],
            'filter' => false,
            'sortable' => false,
            'index' => 'stores',
            'is_system' => true,
            'header_css_class' => 'col-action',
            'column_css_class' => 'col-action'
                ]
        );

        $this->addExportType($this->getUrl('razorpay/*/exportCsv', ['_current' => true]), __('CSV'));
        $this->addExportType($this->getUrl('razorpay/*/exportExcel', ['_current' => true]), __('Excel'));

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

    /**
     * Row click url
     *
     * @param \Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', ['id' => $row->getId()]);
    }

     /**
      * @return $this
      */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('id');
        $this->getMassactionBlock()->setFormFieldName('id');

        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl('razorpay/*/massDelete'),
                'confirm' => __('Are you sure?')
            ]
        );
        return $this;
    }

    /**
     * @return void
     */
    public function getRowId()
    {
        $this->renderData->getRowId();
    }

    /**
     * Get grid url
     *
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('razorpay/*/grid', ['_current' => true]);
    }
}
