<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */
namespace Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule;

/**
 * Image renderer.
 * @category Embitel
 * @package  Embitel_CategoryLanding
 * @module   CategoryLanding
 * @author   Magestore Developer
 */
class RenderData extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer
{
    /**
     * @var int
     */
    protected $_id;

    /**
     * Render action.
     *
     * @param \Magento\Framework\DataObject $row
     *
     * @return string
     */
    public function render(\Magento\Framework\DataObject $row)
    {
        $this->_id = $row->getId();
    }

    /**
     *
     * @return mixed
     */
    public function getRowId()
    {
        return $this->_id;
    }
}
