<?php
/**
 * @Module         : Razorpay Payment
 * @Package        : Razorpay_Magento
 * @Description    : provides data related to razorpay payment response for purpose of showing it in sales order view section in admin panel
 * @Developer      : Shaunak Datar <shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */
namespace Razorpay\Magento\Block\Adminhtml\Order\View;

use Razorpay\Magento\Model\RazorpayPayments;

class RazorpayOrder extends \Magento\Backend\Block\Template
{
    /**
     * @var RazorpayPayments
     */
    protected $razorpayPayments;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Sales\Model\Order $orderModel
     * @param RazorpayPayments $razorpayPayments
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Sales\Model\Order $orderModel,
        RazorpayPayments $razorpayPayments,
        array $data = []
    ) {
        $this->orderModel = $orderModel;
        $this->razorpayPayments = $razorpayPayments;
        parent::__construct($context, $data);
    }

    /**
     * @return \Magento\Framework\Data\Collection\AbstractDb|
     * \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection|null
     */
    public function getRazorpayResponse()
    {
        $order_id = $this->getRequest()->getParam('order_id');
        return $this->razorpayPayments->getCollection()->addFieldToFilter("order_id", ['eq' => $order_id]);
    }
}
