<?php
/**
 * @Module         : Razorpay Payment
 * @Package        : Razorpay_Magento
 * @Description    : This block is related to import of dealer deduction rules
 * @Developer      : Shaunak Datar <shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */
namespace Razorpay\Magento\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class ImportDealerRazorpayRule extends Template
{

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    private $formKey;

    /**
     * @param Template\Context $context
     * @param \Magento\Framework\Data\Form\FormKey $formKey
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey
    ) {
        $this->formKey = $formKey;
        parent::__construct($context);
    }

    /**
     *
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getFormKey()
    {
        return $this->formKey->getFormKey();
    }
}
