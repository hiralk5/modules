<?php
/**
 * @Module         : Razorpay Payment
 * @Package        : Razorpay_Magento
 * @Description    : Will check whether customer can make payment using razorpay gateway
 * @Developer      : Shaunak Datar <shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */
namespace Razorpay\Magento\Block;

require_once __DIR__ . "../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;

use Magento\Framework\View\Element\Template;
use Magento\Customer\Model\Session as CustomerSession;
use Embitel\Order\Helper\Order;
use Embitel\ApiCalls\Helper\Data as ApiCallsHelper;

/**
 * @Block check Razor pay block
 */
class CheckRazorPay extends Template
{
    public const CONV_FEE = 'instacheckout/payment_content/conv_fee';

    /**
     * @var int
     */
    protected $_razorOrderId;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var Order
     */
    protected $_order;

    /**
     * @var ApiCallsHelper
     */
    protected $apiCallHelper;


    /**
     * @param CustomerSession $customerSession
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param Template\Context $context
     * @param Order $_order
     * @param ApiCallsHelper $apiCallHelper
     */
    public function __construct(
        CustomerSession $customerSession,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\View\Element\Template\Context $context,
        Order $_order,
        ApiCallsHelper $apiCallHelper
    ) {
        $this->customerSession = $customerSession;
        $this->scopeConfig = $scopeConfig;
        $this->_order = $_order;
        $this->apiCallHelper = $apiCallHelper;
        parent::__construct($context);
    }

    /**
     *
     * @return int|mixed
     */
    public function CreateApiOrder()
    {
        if ($this->customerSession->getRazorPayOrderId() == null) {
            $api = new Api('rzp_test_a2l65rDuGSicPd', '6QdnP5EjQOhckXN6NyaMBdBu');
            $orderData = [
                'receipt'         => 3456,
                'amount'          => 1 * 100, // 2000 rupees in paise
                'currency'        => 'INR',
                'payment_capture' => 0 // auto capture
             ];

            $razorpayOrder = $api->order->create($orderData);
            $this->_razorOrderId = $razorpayOrder['id'];
            $this->customerSession->setRazorPayOrderId($razorpayOrder['id']);
            return $razorpayOrderId = $this->_razorOrderId;//$razorpayOrder['id'];
        } else {
            $this->_razorOrderId = $this->customerSession->getRazorPayOrderId();
            return $razorpayOrderId = $this->_razorOrderId;
        }
    }

    /**
     *
     * @return mixed
     */
    public function checkPaymentAttemps()
    {
        $api = $this->RazorPayApiConfig();
        $result = $api->order->fetch($this->_razorOrderId)->payments();
        return $result->count;
    }

    /**
     *
     * @return mixed
     */
    public function getConvFee()
    {
        return $this->scopeConfig->getValue(self::CONV_FEE);
    }

    /**
     *
     * @return Order
     */
    public function getOrderData()
    {
        return $this->_order;
    }

    /**
     *
     * @return ApiCallsHelper
     */
    public function getApiCallsHelper()
    {
        return $this->apiCallHelper;
    }

    /**
     *
     * @return mixed
     */
    public function IsQrCodeEnable()
    {
        return $this->scopeConfig->getValue(
            "razorpay/qr_code/enable",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );
    }
}
