<?php

namespace Razorpay\Magento\Model;

use \Razorpay\Magento\Api\WebhookeventsapiInterface;
use \Razorpay\Magento\Api\Data\WebhookeventsDataInterface;
use Razorpay\Magento\Model\RazorpayWebhookEventFactory;

class Webhookeventsapi implements WebhookeventsapiInterface
{

    private $webhookeventsResponse;
    protected $razorpaywebhookeventFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        WebhookeventsDataInterface $webhookeventsResponse,
        RazorpayWebhookEventFactory $razorpaywebhookeventFactory
    ) {
        $this->webhookeventsResponse = $webhookeventsResponse;
        $this->razorpaywebhookeventFactory = $razorpaywebhookeventFactory;
    }

    public function getWebhookevents()
    {
        $dirPath = BP . '/var/log/razorpay/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpay/razorpayWebhookevents.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info("============= Razorpay Webhook Events =================");
        $responsedata = $this->razorpaywebhookeventFactory->create()->getCollection()->addFieldToFilter('status', ['eq' => 0]);
        $eventjsonarr=[];
        if (count($responsedata) > 0) {
            $responsedata = $responsedata->getFirstItem();
            $logger->info("============= Events =================");
            $logger->info($responsedata->getData());
            if ($responsedata->getEventJson() != '') {
                $eventjsonarr[] = (array) json_decode($responsedata->getEventJson(), true);
            }
            $this->webhookeventsResponse->setOrderid($responsedata->getOrderid());
            $this->webhookeventsResponse->setIncremental_id($responsedata->getIncrementalId());
            $this->webhookeventsResponse->setevent_name($responsedata->getEventName());
            $this->webhookeventsResponse->setevent_json($eventjsonarr);
            $this->webhookeventsResponse->setdate_time($responsedata->getDateTime());
            $this->webhookeventsResponse->setStatus($responsedata->getStatus());
            $this->response = $this->webhookeventsResponse;
            if ($responsedata->getId()) {
                try {
                    $updatestatus = $this->razorpaywebhookeventFactory->create()->load($responsedata->getId());
                    $updatestatus->setStatus(1);
                    $updatestatus->save();
                    $logger->info("status updated table id - " . $responsedata->getId());
                } catch (\Exception $e) {
                    $logger->info("Webhook events store Error:" . $e->getMessage());
                }
            }
            return $this->response;
        } else {
            $logger->info("Events Data not found");
        }
    }
}
