<?php
/**
 * @category   Embitel
 * @package    Embitel_Aem
 * @author     kushagra.daharwal@embitel.com
 */
namespace Razorpay\Magento\Model\Config\Source;

class PaymentMethods implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => 'card', 'label' => __('Debit and Credit Card')],
            ['value' => 'emi_on_credit_Card', 'label' => __('EMI on Credit Card')],
            ['value' => 'cardless_emi', 'label' => __('Cardless EMI')],
            ['value' => 'netbanking', 'label' => __('Netbanking')],
            ['value' => 'wallet', 'label' => __('Wallet')],
            ['value' => 'upi', 'label' => __('UPI')],
            ['value' => 'pay_later', 'label' => __('Pay Later')],
            ['value' => 'emandate', 'label' => __('Emandate')],
            ['value' => 'intentupi', 'label' => __('Intent UPI')],
        ];
    }
}
