<?php
/**
 * Cod order push API request and response data store in db
 *
 * @category  Embitel
 * @package   Embitel_CashOnDelivery
 * @author    bratati <bratati.dolai@embitel.com>
 * @copyright 2017-2018 Embitel technologies (I) Pvt. Ltd
 */

namespace Razorpay\Magento\Model\ResourceModel\OrderPush;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{


    protected function _construct()
    {
        $this->_init('Razorpay\Magento\Model\OrderPush', 'Razorpay\Magento\Model\ResourceModel\OrderPush');
    }
}
