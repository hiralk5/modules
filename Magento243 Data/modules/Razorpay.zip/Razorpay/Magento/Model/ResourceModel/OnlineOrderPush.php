<?php

namespace Razorpay\Magento\Model\ResourceModel;

/**
 * Online Order Push Resource Model
 */
class OnlineOrderPush extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('online_order_push', 'entity_id');
    }
}
