<?php

namespace Razorpay\Magento\Model\ResourceModel;

/**
 * RazorpayWebhookEvent Resource Model
 */
class RazorpayWebhookEvent extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('razorpay_webhook_event', 'id');
    }
}
