<?php

/**
 * Razorpay API request and response data store in db
 *
 * @category  Razorpay
 * @package   Razorpay_Magento
 * @author    bratati <bratati.dolai@embitel.com>
 * @copyright 2019-2020 Embitel technologies (I) Pvt. Ltd
 */
namespace Razorpay\Magento\Model\ResourceModel;

class OrderPush extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    protected function _construct()
    {
        $this->_init('razorpay_order_push', 'entity_id');
    }
}
