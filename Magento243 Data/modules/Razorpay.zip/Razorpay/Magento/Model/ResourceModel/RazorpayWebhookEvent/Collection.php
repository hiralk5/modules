<?php

/**
 * RazorpayWebhookEvent Resource Collection
 */
namespace Razorpay\Magento\Model\ResourceModel\RazorpayWebhookEvent;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Razorpay\Magento\Model\RazorpayWebhookEvent', 'Razorpay\Magento\Model\ResourceModel\RazorpayWebhookEvent');
    }
}
