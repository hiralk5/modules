<?php
namespace Razorpay\Magento\Model;

/**
 * RazorpayWebhookEvent Model
 *
 * @method \Embitel\Bannerslider\Model\Resource\Page _getResource()
 * @method \Embitel\Bannerslider\Model\Resource\Page getResource()
 */
class RazorpayWebhookEvent extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Razorpay\Magento\Model\ResourceModel\RazorpayWebhookEvent');
    }
}
