<?php

namespace Razorpay\Magento\Model;

use Razorpay\Magento\Api\WrapperServiceToMaFromOdmInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Razorpay\Magento\Model\Mediaagility\Apicall;

class WrapperServiceToMaFromOdm implements WrapperServiceToMaFromOdmInterface
{

    /**
     * @var \Magento\Framework\Webapi\Rest\Request
     */
    protected $request;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var
     */
    protected $apicall;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Webapi\Rest\Request $request
     * @param ScopeConfigInterface $scopeConfig
     * @param Apicall $Apicall
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Webapi\Rest\Request $request,
        ScopeConfigInterface $scopeConfig,
        Apicall $Apicall
    ) {
        $this->request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->apicall = $Apicall;
    }

    /**
     * GET for Post API
     * @return string
     */

    public function getCreateorUpdateJob($event)
    {

        if ($event=='create' || $event=='update') {
            $apiconfig = $this->scopeConfig->getValue(
                'razorpay/wrapper_service/wrapper_service_fp', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            if ($apiconfig == 1) {
                try {

                    $reqbodyData = $this->request->getBodyParams();
                    if ($reqbodyData) {
                        $request_body = json_encode($reqbodyData);

                        if ($event=='create') {
                            $url = $this->scopeConfig->getValue(
                                'razorpay/mediaagility_api_detail/orderpush_api_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                        } elseif ($event=='update') {
                            $url = $this->scopeConfig->getValue(
                                'razorpay/mediaagility_api_detail/orderupdate_api_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                        }
                        $headers = $this->apicall->getJobHeader();
                        $response = $this->apicall->apicall($url, $headers, $request_body);

                        $actualResponse[] = json_decode($response, true);
                        if (isset($actualResponse[0])) {
                            return json_encode($actualResponse[0]);
                        }
                    } else {

                    }
                } catch (\Exception $e) {

                }
            } else {

            }
        } else {

        }
    }
}
