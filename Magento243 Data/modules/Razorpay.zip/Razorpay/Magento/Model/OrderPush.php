<?php

/**
 *
 * @category  Razorpay
 * @package   Razorpay_Magento
 * @author    bratati <bratati.dolai@embitel.com>
 * @copyright 2019-2020 Embitel technologies (I) Pvt. Ltd
 */
namespace Razorpay\Magento\Model;

class OrderPush extends \Magento\Framework\Model\AbstractModel
{
    
    protected function _construct()
    {
        $this->_init('Razorpay\Magento\Model\ResourceModel\OrderPush');
    }
    
    public function saveCancelJobData($order, $requestBody, $responseBody)
    {
        
        try {
            $collection = $this->getCollection()->addFieldToFilter('order_id', $order->getId());
            if ($collection->count() > 0) {
                foreach ($collection as $orderPushmodel) {
                    $orderPushmodel->setOrderId();
                    $orderPushmodel->setJobType('cancel');
                    $orderPushmodel->setCancelJobRequestBody($requestBody);
                    $orderPushmodel->setCancelJobResponseBody($responseBody);
                    $orderPushmodel->save();
                }
            }
        } catch (Exception $e) {
            //custom log should come here
        }
    }
    
    protected function _clearData()
    {
        $this->_data = [];
        return $this;
    }
}
