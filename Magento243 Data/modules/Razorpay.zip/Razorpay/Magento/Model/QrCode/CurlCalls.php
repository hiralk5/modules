<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Razorpay\Magento\Model\QrCode;

class CurlCalls extends \Magento\Framework\Model\AbstractModel
{
    const QR_CORE_PATH = '/pub/media/qrcode/';
    public function __construct(\Razorpay\Magento\Model\Config $configModel)
    {
        $this->configModel = $configModel;
        $this->key = $this->configModel->getConfigData(\Razorpay\Magento\Model\Config::KEY_PUBLIC_KEY);
        $this->secretKey = $this->configModel->getConfigData(\Razorpay\Magento\Model\Config::KEY_PRIVATE_KEY);
    }

    public function curlCall($body, $curlUrl)
    {
        
        $authKey =   "$this->key:$this->secretKey";
      
        //$authKey = "rzp_live_Q2rAKQplsg6H5v:Scv9HYbg51eb5OIgOrtlWYmr";

        $body = is_array($body) ? json_encode($body) : $body;
        $curl = curl_init($curlUrl);

        curl_setopt_array($curl, [
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",

            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERPWD => $authKey
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            return $err;
        } else {
            $responseData = json_decode($response, true);
            return $responseData;
        }
    }
    
    public function getVirtualAccStatus($curlUrl)
    {
       
        $authKey =   "$this->key:$this->secretKey";
        //$authKey = "rzp_live_Q2rAKQplsg6H5v:Scv9HYbg51eb5OIgOrtlWYmr";

      
        $curl = curl_init($curlUrl);

        curl_setopt_array($curl, [
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",

            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_USERPWD => $authKey
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            return $err;
        } else {
            $responseData = json_decode($response, true);
            return $responseData;
        }
    }
    
    public function closePopup($curlUrl)
    {
         $authKey =   "$this->key:$this->secretKey";
        //$authKey = "rzp_live_Q2rAKQplsg6H5v:Scv9HYbg51eb5OIgOrtlWYmr";

         $data = '{"status": "closed"}';
        $curl = curl_init($curlUrl);

        curl_setopt_array($curl, [
            CURLOPT_HTTPHEADER => [
                "Content-Type: application/json",

            ],
            CURLOPT_CUSTOMREQUEST => "PATCH",
            CURLOPT_POST => 1,

            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_USERPWD => $authKey
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            return $err;
        } else {
            $responseData = json_decode($response, true);
            return $responseData;
        }
    }
    
    public function getPaymentDetails($curlUrl)
    {
       
        $authKey =   "$this->key:$this->secretKey";
        //$authKey = "rzp_live_Q2rAKQplsg6H5v:Scv9HYbg51eb5OIgOrtlWYmr";

      
        $curl = curl_init($curlUrl);

        curl_setopt_array($curl, [
           CURLOPT_HTTPHEADER => [
               "Content-Type: application/json",

           ],
           CURLOPT_RETURNTRANSFER => true,
           CURLOPT_TIMEOUT => 60,
           CURLOPT_USERPWD => $authKey
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);
        if ($err) {
            return $err;
        } else {
            $responseData = json_decode($response, true);
            return $responseData;
        }
    }
    
    public function getCustomerIdCreationReqBody()
    {
        $body = ["name" => "Bajaj Embitel",
        "contact"=>"9898989898",
        "email" => "abc@abc.com",
        "fail_existing" => "0",
        "notes" => ["customer" => "Bajaj Finserv"]
        ];
        return $body;
    }
    
    public function getShortUrlData($curl)
    {
    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $curl);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}
