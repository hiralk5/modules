<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Razorpay\Magento\Model\QrCode;

class AccountCreationManagement implements \Razorpay\Magento\Api\QrCode\AccountCreationInterface
{
    
    public function __construct(
        \Razorpay\Magento\Model\QrCode\CurlCalls $curlCalls,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->apiCall = $curlCalls;
         $this->scopeConfigInterface = $scopeConfig;
    }


    /**
     * Get QrCode Customer Account Details
     * @return array Description
     */
    public function getAccountDetails()
    {
        $body = $this->apiCall->getCustomerIdCreationReqBody();
        $curlUrl = $this->scopeConfigInterface->getValue("razorpay/qr_code/account_creation_url", \Magento\Store\Model\ScopeInterface::SCOPE_STORES);
       // $curlUrl = "https://api.razorpay.com/v1/customers";
        
        $response = $this->apiCall->curlCall($body, $curlUrl);
        if (!isset($response['id'])) {
            $response['error'] = $response;
        }
         /* --Test 8 */
        /*$curlCall = 'https://api.razorpay.com/v1/virtual_accounts';
        $paymentRequestParam = array(
                "receivers" => array("types" => array("qr_code")),
                "description" => "Bharat QR for payment collection",
                "customer_id" => "cust_F6m1S1v8WdjBly",
                "amount_expected" =>  1000,
                "notes" => array("order_id" => "test_01",
                    "seller_id" => 10001)
            );
        echo json_encode($paymentRequestParam);exit;
        $response = $this->apiCall->curlCall($paymentRequestParam, $curlCall);*/
       
        
        
        return [$response];
    }
}
