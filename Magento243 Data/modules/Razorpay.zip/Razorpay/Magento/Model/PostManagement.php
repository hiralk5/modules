<?php

namespace Razorpay\Magento\Model;

use \Razorpay\Magento\Api\PostManagementInterface;
use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Razorpay\Magento\Helper\RazorpayHelper;
use Embitel\SellerModule\Model\CustomSellerInfo;
use Magento\Sales\Model\Order as Order;
use Razorpay\Magento\Model\OnlineOrderPush;
use Razorpay\Magento\Model\DealerRazorpayRule;
use Razorpay\Magento\Helper\Data as MediaaigilityHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class PostManagement implements PostManagementInterface
{

    /**
     * @var Razorpay\Magento\Model\RazorpayPayments
     */
    protected $razorpayPayments;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_orderInterfaceFactory;

    protected $request;

    /**
     * @var Razorpay\Magento\Helper\RazorpayHelper
     */
    protected $razorpayHelper;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $CustomSellerInfo;

    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $_order;

    /**
     * @var Razorpay\Magento\Model\OnlineOrderPush
     */
    protected $onlineOrderPush;

    /**
     * @var Razorpay\Magento\Model\DealerRazorpayRule
     */
    protected $dealerRazorpayRule;

    /**
     * @var Razorpay\Magento\Helper\Data
     */
    protected $mediaaigilityHelper;

    /**
     * @var Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @description Reciever Email Address Path
    */
    const CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER = 'atos_configuration/orderpush/orderpush_email';


    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        RazorpayPayments $razorpayPayments,
        \Magento\Framework\Webapi\Rest\Request $request,
        OrderInterfaceFactory $orderInterfaceFactory,
        RazorpayHelper $razorpayHelper,
        CustomSellerInfo $CustomSellerInfo,
        Order $order,
        OnlineOrderPush $onlineOrderPush,
        DealerRazorpayRule $dealerRazorpayRule,
        MediaaigilityHelper $mediaaigilityHelper,
        StoreManagerInterface $storeManager,
        TransportBuilder $transportBuilder,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->razorpayPayments = $razorpayPayments;
                $this->request = $request;
                $this->_orderInterfaceFactory = $orderInterfaceFactory;
                $this->razorpayHelper = $razorpayHelper;
                $this->CustomSellerInfo = $CustomSellerInfo;
                $this->_order = $order;
                $this->onlineOrderPush = $onlineOrderPush;
                $this->dealerRazorpayRule = $dealerRazorpayRule;
                $this->mediaaigilityHelper = $mediaaigilityHelper;
                $this->nfPrimeHelper = $nfPrimeOrderHelper;
                $this->storeManager = $storeManager;
                $this->transportBuilder = $transportBuilder;
                $this->scopeConfig = $scopeConfig;
        //return parent::__construct($context);
    }

    /**
     * GET for Post api
     * @return string
     */

    public function getPost()
    {
        try {
            $requestPacket = '';
            $dirPath = BP . '/var/log/razorpay/';
            if (!file_exists($dirPath)) {
                mkdir($dirPath, 0775, true);
            }
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpay/razorpayPayment.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
            $parentOrderId = "";
            $payload = $this->request->getBodyParams();
            $this->razorpayHelper->SaveRazorpaywebhookevent($payload, $logger);

            if (isset($payload['event']) && $payload['event'] == "order.paid") {
                $data_array = [];
                $transaction_type = "payment";
                $payment_id = $payload['payload']['payment']['entity']['id'];
                $amount = $payload['payload']['payment']['entity']['amount'];
                $razorpay_order_id = $payload['payload']['payment']['entity']['order_id'];
                $payment_mode = $payload['payload']['payment']['entity']['method'];
                $transaction_status = "success";
                $transaction_type = "payment";
                $retry_count = 1;
                $dealId = '';
                $order_increment_id = "";
                $notes = $payload['payload']['order']['entity']['notes'];

                if (isset($payload['payload']['order']['entity']['notes']['order_id'])) {
                    $order_increment_id = $payload['payload']['order']['entity']['notes']['order_id'];
                }


                $orderData = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
                $parentOrderId = $orderData->getEntityId();
                $full_payment = 0;
                $sellerData = $this->getSellerData($orderData->getEntityId());
                if ($sellerData->getDealId() == null) {
                    $full_payment = 1;
                }
                $razorpayOrder = $this->razorpayHelper->getRazorpayOrder($orderData->getEntityId());
                if ($razorpayOrder) {
                    return "Payment Data Already Present";
                }
                $response = [];
                //if($payment_mode == "upi"){
                $response = ["razorpay_payment_id" => $payment_id,"razorpay_order_id" => $razorpay_order_id];
                $retry_count = $this->getRetryCount($orderData->getEntityId());
                $retry_count = $retry_count + 1;
                //}

                /*Creating Request Packet*/
                $requestPacket = ["amount" => $amount,'currency'=>'INR','order_id' => $razorpay_order_id,'contact' => $payload['payload']['payment']['entity']['contact'],'email' => $payload['payload']['payment']['entity']['email'],'notes' => $notes];


                if ($transaction_status == "success") {
                    $sellerid = $sellerData->getSellerId();
                    $razorpayDealer = $this->razorpayDealer($sellerid);
                    if ($razorpayDealer) {

                        if ($sellerData) {
                            $dealId = $sellerData->getDealId();
                        }
                        if ($dealId != null) {
                            $order_amount_rupees = $amount / 100;
                            $deduction_percent = $razorpayDealer->getDefaultPercentage();
                            $deduction_amount = $deduction_percent * $order_amount_rupees;
                            $deduction_amount = $deduction_amount / 100;
                            $deduction_amount = $order_amount_rupees - $deduction_amount;
                            $deduction_amount = round($deduction_amount);
                            $order_amount_rupees = round($order_amount_rupees);
                            $razorpay_odm_request = ["DealId" => $dealId,"OrderId" => $orderData->getIncrementId(),"RZPPaidOnline" => "Y","Event" => "Confirm", "RZPDisbOnlineAmt" => $order_amount_rupees,"RZPDeduction" => $deduction_amount,"RZPOrderID" => $razorpay_order_id];

                            //add data to online_order_push table
                            $this->onlineOrderPush->setOrderId($orderData->getIncrementId());
                            $this->onlineOrderPush->setRazorpayOrderId($razorpay_order_id);
                            $this->onlineOrderPush->setRequestParams(json_encode($razorpay_odm_request));
                            $this->onlineOrderPush->save();
                        }

                    }

                    //Updating Payment Method
                    $orderData = $this->_order->load($orderData->getEntityId());
                    $orderData->getPayment()->setData('method', 'razorpay')->save();

                    //Updating Payment Method in Admin Sales Order Grid
                    $orderFactory = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
                    $orderFactory->setPaymentMethod("razorpay");
                    $orderFactory->setStatus("order_placed");
                    $orderFactory->save();

                    $IsVirtual = $this->getIsVitualType($orderData);
                    //order push to media agility
                    if ($full_payment && (!$IsVirtual)) { // if it is full payment
                        $this->mediaaigilityHelper->orderPushReqBody($orderData);
                    }

                    // prime netflix order
                    if ($full_payment && $IsVirtual) {
                        // initiate netflix
                        //$this->nfPrimeHelper->createPMOrder($orderData->getEntityId());
                    }


                }
            }

            if (isset($payload['event']) && $payload['event'] == "payment.failed") {
                $transaction_type = "payment";
                $transaction_status = "fail";
                $payment_id = $payload['payload']['payment']['entity']['id'];
                $razorpay_order_id = $payload['payload']['payment']['entity']['order_id'];
                $order_increment_id = "";
                $notes = $payload['payload']['payment']['entity']['notes'];
                $payment_mode = $payload['payload']['payment']['entity']['method'];
                $transaction_type = "payment";
                $error_code = $payload['payload']['payment']['entity']['error_code'];
                $error_description = $payload['payload']['payment']['entity']['error_description'];

                $response = ["error"=>["code" => $error_code,"description" => $error_description]];
                $amount = $payload['payload']['payment']['entity']['amount'];
                if (isset($payload['payload']['payment']['entity']['notes']['order_id'])) {
                    $order_increment_id = $payload['payload']['payment']['entity']['notes']['order_id'];
                }

                $requestPacket = ["amount" => $amount,'currency'=>'INR','order_id' => $razorpay_order_id,'contact' => $payload['payload']['payment']['entity']['contact'],'email' => $payload['payload']['payment']['entity']['email'],'notes' => $notes];


                $orderData = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
                $parentOrderId = $orderData->getEntityId();
                $full_payment = 0;
                $sellerData = $this->getSellerData($orderData->getEntityId());
                if ($sellerData && $sellerData->getDealId() == null) {
                    $full_payment = 1;
                }
                $retry_count = $this->getRetryCount($orderData->getEntityId());
                $retry_count = $retry_count + 1;


                $razorpayOrder = $this->razorpayHelper->getRazorpayOrder($orderData->getEntityId());
                if ($razorpayOrder) {
                    return "Payment Data Already Present";
                }

            }

            if (isset($payload['event']) && $payload['event'] == "transfer.processed") {

                /*Declaring Variables*/
                $transaction_type = "transfer_processed";
                $amount = '';
                $transaction_status = "";
                $full_payment = 0;
                $order_increment_id = '';
                $razorpay_order_id = '';
                $retry_count = 0;
                $payment_mode = '';
                if (isset($payload['payload']['transfer']['entity']['id'])) {

                    $transaction_status = "success";

                    if (isset($payload['payload']['transfer']['entity']['notes']['order_id'])) {
                        $order_increment_id = $payload['payload']['transfer']['entity']['notes']['order_id'];
                    }


                    $orderData = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
                    $parentOrderId = $orderData->getEntityId();
                    $sellerData = $this->getSellerData($orderData->getEntityId());
                    if ($sellerData->getDealId() == null) {
                        $full_payment = 1;
                    }

                    $razorpayOrder = $this->razorpayHelper->getRazorpayOrder($orderData->getEntityId());
                    if ($razorpayOrder) {
                        $razorpay_order_id = $razorpayOrder->getRazorpayOrderId();
                        $amount = $razorpayOrder->getAmount();
                        $payment_mode = $razorpayOrder->getPaymentMode();
                    }

                    $response[] = $payload['payload']['transfer']['entity'];
                    $transferProcessData = $this->checkTransferProcessed($order_increment_id);
                    if ($transferProcessData) {

                        $response = json_decode($transferProcessData->getRazorpayResponse(), true);
                        $response[] = $payload['payload']['transfer']['entity'];
                    }
                }
            }

            if (isset($payload['event']) && ($payload['event'] == "payment.failed" || $payload['event'] == "order.paid" || $payload['event'] == "transfer.processed")) {
                $data_array['order_id'] = $parentOrderId;
                $data_array['razorpay_order_id'] = $razorpay_order_id;
                $data_array['razorpay_request'] = '';
                if ($requestPacket != '') {
                    $data_array['razorpay_request'] = json_encode($requestPacket);
                }
                $data_array['razorpay_response'] = json_encode($response);
                $data_array['transaction_flag'] = 0;
                $data_array['order_increment_id'] = $order_increment_id;
                $data_array['transaction_status'] = $transaction_status;
                $data_array['transaction_type'] = $transaction_type;
                $data_array['transaction_to'] = "BFL";
                $data_array['amount'] = $amount;
                $data_array['payment_mode'] = $payment_mode;
                $data_array['retry_count'] = $retry_count;
                $data_array['payment_flag'] = $full_payment;
                $data_array['payload_event'] = $payload['event'];
                $this->saveRazorpayData($data_array);
            }
        } catch (\Exception $e) {
            $ErrorMessage = $e->getMessage();
            $this->sendRazorpayFailEmail($ErrorMessage, $payload);
            throw new \Magento\Framework\Webapi\Exception(__($e->getMessage()));
        }
    }

    public function getSellerData($order_id)
    {
        $sellerData = $this->CustomSellerInfo->getCollection()->addFieldToFilter('order_id', $order_id);
        if ($sellerData->count() > 0) {
            return $sellerData->getFirstItem();
        }
        return false;
    }

    public function razorpayDealer($dealerId = null)
    {
        if ($dealerId != null) {
            $razorpayDealerData = $this->dealerRazorpayRule->getCollection()->addFieldToFilter("dealer_id", ['eq' => $dealerId])->addFieldToFilter("status", ['eq' => 1]);
            if ($razorpayDealerData->count() > 0) {
                return $razorpayDealerData->getFirstItem();
            }
            return false;
        }
    }

    public function getRetryCount($orderId = null)
    {
        if ($orderId != null) {
            $razorpayData = $this->razorpayPayments->getCollection()->addFieldToFilter("order_id", ['eq' => $orderId])->addFieldToFilter("transaction_type", ['eq' => 'payment']);
            if ($razorpayData->count() > 0) {
                $razorpayData = $razorpayData->getFirstItem();
                return $razorpayData->getRetryCount();
            }
            return 0;
        }
    }

    public function saveRazorpayData($data = [])
    {

        $razorpay_data = $this->razorpayPayments;
        $retry = $this->getRetryCount($data['order_id']);

        if ($retry > 0 && $data['transaction_status'] == 'fail') {
            $razorpayCollection = $this->razorpayPayments->getCollection()->addFieldToFilter("order_id", ['eq' => $data['order_id']])->addFieldToFilter("transaction_type", ['eq' => 'payment'])->addFieldToFilter("transaction_status", ['eq' => 'fail'])->getFirstItem();
            $razorpay_data = $this->razorpayPayments->load($razorpayCollection->getId());
            $data['razorpay_response'] = $razorpayCollection->getRazorpayResponse().$data['razorpay_response'];
        }

        if ($data['payload_event'] == "transfer.processed") {
            $transferProcessed = $this->checkTransferProcessed($data['order_increment_id']);
            if ($transferProcessed) {
                $razorpay_data = $this->razorpayPayments->load($transferProcessed->getId());
            }
        }
        $razorpay_data->setOrderId($data['order_id']);
        $razorpay_data->setRazorpayOrderId($data['razorpay_order_id']);
        $razorpay_data->setRazorpayRequest($data['razorpay_request']);
        $razorpay_data->setRazorpayResponse($data['razorpay_response']);
        $razorpay_data->setTransactionFlag($data['transaction_flag']);
        $razorpay_data->setOrderIncrementId($data['order_increment_id']);
        $razorpay_data->setTransactionTo($data['transaction_to']);
        $razorpay_data->setTransactionStatus($data['transaction_status']);
        $razorpay_data->setTransactionType($data['transaction_type']);
        $razorpay_data->setAmount($data['amount']);
        $razorpay_data->setPaymentMode($data['payment_mode']);
        $razorpay_data->setRetryCount($data['retry_count']);
        $razorpay_data->setPaymentFlag($data['payment_flag']);
        $razorpay_data->save();
    }


    public function checkTransferProcessed($orderId = null)
    {
        if ($orderId !=null) {
            $transferProcessData = $this->razorpayPayments->getCollection()->addFieldToFilter("order_increment_id", ['eq' => $orderId])->
                            addFieldToFilter("transaction_type", ['eq' => 'transfer_processed'])->addFieldToFilter("transaction_status", ['eq' => 'success']);
            if ($transferProcessData->count() > 0) {
                return $transferProcessData->getFirstItem();
            }
            return false;
        }
    }

    /*Fetches product type*/
    public function getIsVitualType($order = null)
    {
        if ($order != null) {
            $orderItems = $order->getAllVisibleItems();
            foreach ($orderItems as $item) {
                if ($item->getProductType() == 'virtual') {
                    return true;
                }
            }
        }
        return false;
    }

    public function sendRazorpayFailEmail($Error = null, $request = null)
    {
        $orderPushInfo = [];
        $orderPushInfo['order_push_url'] = $Error;
        $orderPushInfo['request_data'] = json_encode($request);
        $postObject = new \Magento\Framework\DataObject();
        $postObject->setData($orderPushInfo);
        $templateData = ['orderpush' => $postObject];
        $storeId = $this->storeManager->getStore()->getId();
        $recipients = explode(",", $this->getEmailRecipient());
        // @var \Magento\Framework\Mail\Template\TransportBuilder $transport
        $transport = $this->transportBuilder->setTemplateIdentifier(
            $this->getEmailTemplateId()
        )->setTemplateOptions(
            ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeId]
        )->setTemplateVars(
            $templateData
        )->setFrom(
            $this->getsender()
        )->addTo(
            $recipients
        )->getTransport();

        $transport->sendMessage();

        return $this;
    }

    /**
     * Retrieve Template id of order push failed from configuration.
     *
     * @param  integer $storeId
     * @return string
     */
    public function getEmailTemplateId($storeId = null)
    {
        return 'razorpay_webhook_failed_template';
    }

    /**
     * Get Sender details from configuration.
     *
     * @param  string $type
     * @param  integer $storeId
     * @return  array
     */
    public function getSender($type = null, $storeId = null)
    {
        $senderName = $this->scopeConfig->getValue('trans_email/ident_general/name', ScopeInterface::SCOPE_STORE);
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_general/email', ScopeInterface::SCOPE_STORE);

        $sender ['name'] = $senderName;
        $sender ['email'] = $senderEmail;

        return $sender;
    }

    /**
     * Get Email Recipients from configuration.
     *
     * @param  integer $storeId
     * @return string]
     */
    public function getEmailRecipient($storeId = null)
    {
        return  $this->scopeConfig->getValue(
            self::CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
}
