<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */
namespace Razorpay\Magento\Model;

/**
 * Bannerslider Model
 *
 * @method \Embitel\Bannerslider\Model\Resource\Page _getResource()
 * @method \Embitel\Bannerslider\Model\Resource\Page getResource()
 */
class RazorpayPayments extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Razorpay\Magento\Model\ResourceModel\RazorpayPayments');
    }
}
