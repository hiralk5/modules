<?php
namespace Razorpay\Magento\Model\Data;

use \Razorpay\Magento\Api\Data\WebhookeventsDataInterface;
use Magento\Framework\Api\AbstractExtensibleObject;

class Webhookeventsapidata extends AbstractExtensibleObject implements WebhookeventsDataInterface
{
      
    const RESPONSE_Incremental_id = 'incremental_id';
    const RESPONSE_Orderid = 'orderid';
    const RESPONSE_event_name = 'event_name';
    const RESPONSE_event_json = 'event_json';
    const RESPONSE_date_time = 'date_time';
    const RESPONSE_status = 'status';
    
    public function getOrderid()
    {
        return $this->_get(self::RESPONSE_Orderid);
    }
 
    /**
     * @param string $Orderid
     * @return $this
     */
    public function setOrderid($Orderid)
    {
        return $this->setData(self::RESPONSE_Orderid, $Orderid);
    }
    /**
     * {@inheritdoc}
     */
    public function getIncremental_id()
    {
        return $this->_get(self::RESPONSE_Incremental_id);
    }
 
    /**
     * @param string $Incremental_id
     * @return $this
     */
    public function setIncremental_id($Incremental_id)
    {
        return $this->setData(self::RESPONSE_Incremental_id, $Incremental_id);
    }
     /**
      * {@inheritdoc}
      */
     /**
      * {@inheritdoc}
      */
    public function getevent_name()
    {
        return $this->_get(self::RESPONSE_event_name);
    }
 
    /**
     * @param string $event_name
     * @return $this
     */
    public function setevent_name($event_name)
    {
        return $this->setData(self::RESPONSE_event_name, $event_name);
    }
    /**
     * {@inheritdoc}
     */
    public function getevent_json()
    {
        return $this->_get(self::RESPONSE_event_json);
    }
 
    /**
     * @param string $event_json
     * @return $this
     */
    public function setevent_json($event_json)
    {
        return $this->setData(self::RESPONSE_event_json, $event_json);
    }
     /**
      * {@inheritdoc}
      */
    public function getdate_time()
    {
        return $this->_get(self::RESPONSE_date_time);
    }
 
    /**
     * @param string $date_time
     * @return $this
     */
    public function setdate_time($date_time)
    {
        return $this->setData(self::RESPONSE_date_time, $date_time);
    }
    
    public function getStatus()
    {
        return $this->_get(self::RESPONSE_status);
    }
 
    /**
     * @param string $Status
     * @return $this
     */
    public function setStatus($Status)
    {
        return $this->setData(self::RESPONSE_status, $Status);
    }
}
