<?php

/**
 * Apicall to createjob and canceljob
 *
 * @category  Razorpay
 * @package   Razorpay_Magento
 * @author    bratati <bratati.dolai@embitel.com>
 * @copyright 2018-2019 Embitel technologies (I) Pvt. Ltd
 */
namespace Razorpay\Magento\Model\Mediaagility;

class Apicall extends \Magento\Framework\Model\AbstractModel
{
    
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Sales\Model\Order $orderModel,
        \Razorpay\Magento\Model\OrderPush $orderPushModel,
        \Razorpay\Magento\Helper\LogfileDetail $logFileDetail,
        \Razorpay\Magento\Helper\Data $razorpayHelper
    ) {
        
        $this->scopeConfig = $scopeConfig;
        $this->orderModel = $orderModel;
        $this->orderPushModel = $orderPushModel;
        $this->logFile = $logFileDetail;
        $this->razorpayHelper = $razorpayHelper;
        parent::__construct($context, $registry);
    }
    
    public function createJob($requestRow, $logger)
    {
      
       
        $response = [];
        $successPush = false;
        $bodyData = $requestRow['create_job_request_body'];
        if ($bodyData) {
           
            $url = $this->scopeConfig->getValue(
                'razorpay/mediaagility_api_detail/orderpush_api_url',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );

            //final call for api start
            $headers = $this->getJobHeader();
            $response = $this->apicall($url, $headers, $bodyData);
           
            $actualResponse = json_decode($response, true);

            if (!empty($actualResponse) && $actualResponse['status'] == 'success') {
                $successPush = true;
            } else {
                $requestUrl = $this->scopeConfig->getValue('razorpay/mediaagility_api_detail/orderpush_api_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $this->razorpayHelper->sendOrderPushApiFailedEmail($requestRow['order_increment_id'], $requestUrl, $bodyData, $actualResponse);
            }
            
            //request and response
            $orderPushModel = $this->orderPushModel->load($requestRow['entity_id']);
            if ($orderPushModel->getId() > 0) {
                $orderPushModel->setCreateJobResponseBody($response);
                if (!empty($actualResponse) && $actualResponse['status'] == 'success') {
                    $orderPushModel->setOrderPushFlag(0); // for success flag
                } else {
                     $orderPushModel->setOrderPushFlag(3); // for error flag
                }
                $orderPushModel->save();
            }
        }
        
        return $successPush;
    }
    
    public function cancelJob($orderId)
    {
        $logger = $this->logFile->cancelJobLog();
        $actualResponse = '';
        $orderobj = $this->orderModel->load($orderId);
        if ($orderobj->getId() > 0) {
            $logger->info('Cancellation started : '.$orderobj->getIncrementId());
            $incrementId = $orderobj->getIncrementId();
            $url = $this->scopeConfig->getValue(
                'razorpay/mediaagility_api_detail/ordercancel_api_url',
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );
            $headers = $this->getJobHeader();

            //build body params start
            $bodyData = [
                 'jobCode' => $incrementId,
                 'jobStatus' => 'CANCEL'
            ];
            $bodyData =  json_encode($bodyData);
            $logger->info('Cancellation request Data : '.$bodyData);
            $response = $this->apicall($url, $headers, $bodyData);
            $actualResponse = json_decode($response, true);
            $logger->info('Cancellation response Data : '.$response);
            // save req and response to order push table
           //request and response
            $orderPushModel = $this->orderPushModel->getCollection()->addFieldToFilter('order_increment_id', $incrementId)->getFirstItem();
            if ($orderPushModel && $orderPushModel->getId() > 0) {
                if ($orderPushModel->getId() > 0) {
                    $orderPushModel->setCancelJobRequestBody($bodyData);
                    $orderPushModel->setCancelJobResponseBody($response);
                    $orderPushModel->save();
                }
            }
        }
//        $actualResponse = json_decode('{
// "status": "success",
// "statusCode": 11001,
// "data": {
//  "updatedAt": "2020-01-09T13:30:14.090Z",
//  "createdAt": "2020-01-09T12:43:21.718Z",
//  "id": "6021505739653120",
//  "jobId": "4895605832810496",
//  "jobStatus": "5989654704685056",
//  "jobState": "CANCEL",
//  "userType": "USER",
//  "referenceEntityId": "4911020587876352",
//  "referenceEntityName": "JobStatusHistory"
// }
//}', true);
        return $actualResponse;
    }


    public function getJobHeader()
    {
        $clientId = $this->scopeConfig->getValue(
            'razorpay/mediaagility_api_detail/client_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $secretId = $this->scopeConfig->getValue(
            'razorpay/mediaagility_api_detail/secret_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $userId = $this->scopeConfig->getValue(
            'razorpay/mediaagility_api_detail/user_id',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $headers = [
            'CLIENT_ID:'.$clientId,
            'SECRET_ID:'.$secretId,
            'USER_ID:'.$userId,
            'Content-Type:application/json'];
        
        return $headers;
    }

    public function apicall($url, $headers, $bodyData)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyData);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        return $response;
    }
}
