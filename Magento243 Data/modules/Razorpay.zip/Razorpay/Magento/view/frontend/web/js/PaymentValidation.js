define([
    'jquery',
    'jquery/ui',
    'jquery/validate',
    'mage/translate'
], function($){
    'use strict';
 
    return function(configs) {
        
       $( "#card_number" ).keyup(function() {
           if(configs.bin_numbers == ""){
                    return true;
           }
            var res = false;
            var formdata = $("#payment_card_form");
           var binvalues = configs.bin_numbers;
           var binvalues = binvalues.split('|');
           var value = $(this).val();
           value = value.substring(0,6);
           var result = binvalues.indexOf(value);
           if(result == -1){
                        if($(this).val().length >= 6){
              var res = $(this).valid();
              if(res !== true){
                    $("#payment_card_form").find(":button").prop('disabled', true);
              }else{
                  $("#payment_card_form").find(":button").prop('disabled', false);
                   $(this).removeClass('mage-error').next('div.mage-error').remove();
              }
            }else{
                $("#payment_card_form").find(":button").prop('disabled', false);
                $(this).removeClass('mage-error').next('div.mage-error').remove();
            } 
           }
            
        });
        
        $( "#format-card_number" ).keyup(function() {
           if(configs.bin_numbers == ""){
                    return true;
           }
            var res = false;
           var binvalues = configs.bin_numbers;
           var binvalues = binvalues.split('|');
           var value = $(this).val();
           value = value.substring(0,7);
           var result = binvalues.indexOf(value);
           if(result == -1){
                        if($(this).val().length >= 7){
              var res = $(this).valid();
              if(res !== true){
                    $("#payment_card_form").find(":button").prop('disabled', true);
              }else{
                  $("#payment_card_form").find(":button").prop('disabled', false);
                   $(this).removeClass('mage-error').next('div.mage-error').remove();
              }
            }else{
                $("#payment_card_form").find(":button").prop('disabled', false);
                $(this).removeClass('mage-error').next('div.mage-error').remove();
            } 
           }
            
        });
        
        
        $.validator.addMethod(
            "upi_validation",
            function(value, element) {
                var match = /[a-zA-Z0-9_]{3,}@[a-zA-Z]{3,}/;
                var result = match.test(value);

                    if(result == true){
                        return true;
                    }else{
                        return false;
                    }
                
            },
            $.mage.__("Given UPI is not Valid")
        );
        
       $.validator.addMethod(
            "cardnumber",
            function(value, element) {
                if(configs.bin_numbers == ""){
                    return true;
                }
                
                var binvalues = configs.bin_numbers;

                var binvalues = binvalues.split('|');
                value = value.substring(0,6);
                var result = binvalues.indexOf(value);

                    if(result == -1){
                        return false;
                    }else{
                        return true;
                    }
                return this.optional(element) || /^Inchoo/.test(value);
            },
            $.mage.__("Given card number is not valid rbl card number")
        );

        $.validator.addMethod(
            "formatedcardnumber",
            function(value, element) {
                if(configs.bin_numbers == ""){
                    return true;
                }
                
                var binvalues = configs.bin_numbers;

                var binvalues = binvalues.split('|');
                value = value.substring(0,7);
                value = value.replace('-','');
                console.log(value);
                var result = binvalues.indexOf(value);

                    if(result == -1){
                        return false;
                    }else{
                        return true;
                    }
                return this.optional(element) || /^Inchoo/.test(value);
            },
            $.mage.__("Given card number is not valid rbl card number")
        );
        $.validator.addMethod('credit_card_exp', function(value, element) {
          
          var minMonth = new Date().getMonth() + 1;
         console.log(minMonth);
          var minYear = new Date().getFullYear();
         minYear = minYear.toString().substr(2,2)
          var dateSelected = value.split("/");
          var month = parseInt(dateSelected[0], 10);
          var year = parseInt(dateSelected[1], 10);
          if(isNaN(month) == true || isNaN(year) == true || (year < minYear) || (year == minYear && month < minMonth)){
              return false;
          }else{
              return true;
          }
        },$.mage.__('Enter Expiry date.'));
        
        $.validator.addMethod(
            "cvv-input",
            function(value, element) {
                var match = /[0-9_]{3,}/;
                var result = match.test(value);

                    if(result == true){
                        return true;
                    }else{
                        return false;
                    }
                
            },
            $.mage.__("Invalid CVV")
        );
    }
});