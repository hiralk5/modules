var config = {
    map: {
        '*': {
            transparent: 'Magento_Payment/transparent',
            PaymentValidation: "Razorpay_Magento/js/PaymentValidation"
        }
    }
};
