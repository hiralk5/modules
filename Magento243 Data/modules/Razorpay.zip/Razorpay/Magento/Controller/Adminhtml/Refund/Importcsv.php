<?php

/**
 * @category  Embitel
 * @package   Razorpay_Magento
 * @author    shaunak.datar@embitel.com
 * @copyright 2015-2019 Embitel Technologies (I) Pvt. Ltd
 */

namespace Razorpay\Magento\Controller\Adminhtml\Refund;

use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Razorpay\Magento\Helper\RazorpayHelper;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Embitel\SellerModule\Model\CustomSellerInfo;
use Razorpay\Magento\Model\DealerRazorpayRule;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

class Importcsv extends \Magento\Backend\App\Action
{
    protected $_razorpayPayment;

    /**
     * @var Embitel\BbpsPayment\Helper\BbpsPaymentHelper
     */
    protected $_razorpayHelper;

    /**
     * @var Magento\Sales\Api\Data\OrderInterfaceFactory
     */
    protected $_orderFactory;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $customSellerInfo;

    /**
     * @var Razorpay\Magento\Model\DealerRazorpayRule
     */
    protected $dealerRazorpayRule;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * @var File
     */
    private $file;

    /**
     * @param Context $context
     * @param RazorpayPayments $razorpayPayment
     * @param RazorpayHelper $razorpayHelper
     * @param OrderInterfaceFactory $orderFactory
     * @param CustomSellerInfo $customSellerInfo
     * @param DealerRazorpayRule $dealerRazorpayRule
     * @param ScopeConfigInterface $scopeConfig
     * @param DirectoryList $directoryList
     * @param File $file
     */
    public function __construct(
        Context $context,
        RazorpayPayments $razorpayPayment,
        RazorpayHelper $razorpayHelper,
        OrderInterfaceFactory $orderFactory,
        CustomSellerInfo $customSellerInfo,
        DealerRazorpayRule $dealerRazorpayRule,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $directoryList,
        File $file
    ) {
        parent::__construct($context);
        $this->_razorpayPayment = $razorpayPayment;
        $this->_razorpayHelper = $razorpayHelper;
        $this->_orderFactory = $orderFactory;
        $this->customSellerInfo = $customSellerInfo;
        $this->dealerRazorpayRule = $dealerRazorpayRule;
        $this->scopeConfig = $scopeConfig;
        $this->directoryList = $directoryList;
        $this->file = $file;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        /*Maintaining Loggers*/
        $dirPath = BP . '/var/log/razorpay/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $writer_refund = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpayRefund.log');
        $logger_refund = new \Zend_Log();
        $logger_refund->addWriter($writer_refund);

        $writer_transfer = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpay/razorpayTransfer.log');
        $logger_transfer = new \Zend_Log();
        $logger_transfer->addWriter($writer_transfer);

        /*Transaction Varaibles*/
        $transaction_flag = '';
        $transaction_to = '';
        $transaction_type = '';
        $transaction_status = '';
        $razoarpay_response = '';
        $dealerId = '';

        try {
            $icount = 0;
            $_error = false;
            $checkRecord = false;
            $response = [];

            $file = $this->getRequest()->getFiles()->get('importcsv');
            if (isset($file['name'])) {
                $csvCheck = pathinfo($file['name'], PATHINFO_EXTENSION);
                if ($csvCheck == 'csv') {
                    /*If file is csv*/
                    $filename = $file["tmp_name"];
                    $file = fopen($filename, "r");
                    while (($getData = fgetcsv($file, 99999, ",")) !== false) {
                            /*Getting Order Increment Id from csv*/
                        if (isset($getData[0]) && isset($getData[1])) {
                            if ($icount) {
                                $orderData = $this->_orderFactory->create()->loadByIncrementId($getData[0]);
                                $razorResponse = $this->checkTransaction($orderData->getEntityId());

                                /*checking if refund already paid for this order*/
                                /*Below commented code is for checking if order amount already trasfered/ refunded*/
//                                    $refundStatus = $this->_razorpayHelper->checkRazorpayRefund($orderData->getEntityId());
//                                    if($refundStatus){
//                                        $logger_refund->info("Refund Already Paid For this order");
//                                        $message = "Refund Already Paid For this order";
//                                        $response[] = array($getData[0],$getData[1],$message);
//                                        continue;
//                                    }

                                /*Checking if transfer already Done for this order*/
//                                    $transferStatus = $this->_razorpayHelper->checkRazorpayTransfer($orderData->getEntityId());
//                                    if($transferStatus){
//                                        $logger_transfer->info("Transfer Already Done For this order");
//                                        $message = "Transfer Already Done For this order";
//                                        $response[] = array($getData[0],$getData[1],$message);
//                                        continue;
//                                    }

                                try {
                                    if ($razorResponse['razorpay_payment_id']) {
                                        $requestPacket = '';
                                        if ($getData[1] == 0) {
                                            $logger_refund->info(
                                                "===========Razorpay Order Cancel By Admin CSV Import============"
                                            );
                                            $logger_refund->info(
                                                "Refund request payment id".$razorResponse['razorpay_payment_id']
                                            );
                                            $transaction_flag = 2;
                                            $transaction_to = "customer";
                                            $transaction_type = "refund";
                                            $requestPacket = [
                                                "payment_id" => $razorResponse['razorpay_payment_id'],
                                                "order_id" => $getData[0],"reverse_all" => 1];
                                        /*Call Refund function*/
                                            $result = $this->_razorpayHelper->refundPaymentWithReverse(
                                                $razorResponse['razorpay_payment_id']
                                            );
                                            $result = json_decode($result);
                                            $result = (array)$result;
                                            $resultArr = $result;

                                            $logger_refund->info("Refund Response:".json_encode($resultArr));
                                            $razoarpay_response = json_encode($resultArr);
                                            if (isset($result['id'])) {
                                                $transaction_status = "success";
                                                $message = "Success";
                                            } else {
                                                $transaction_status = "fail";
                                                $message = "Fail";
                                            }
                                        } elseif ($getData[1] == 1) {
                                            $sellerData = $this->customSellerInfo->getCollection()
                                                ->addFieldToFilter('order_id', $orderData->getEntityId());
                                            /*Getting Order Dealer Id*/
                                            if ($sellerData->count() == 0) {

                                                $message = "No Dealer Found For This Order";
                                                $response[] = [$getData[0],$getData[1],$message];
                                                continue;
                                            }
                                            $dealerId = $sellerData->getFirstItem()->getSellerId();
                                            $dealid = $sellerData->getFirstItem()->getDealId();
                                            $razorpayDealerData = $this->razorpayDealer($dealerId);
                                            if (!$razorpayDealerData) {

                                                $message = "Razorpay Account No. for Dealer Not Prsent";
                                                $response[] = [$getData[0],$getData[1],$message];
                                                continue;
                                            }
                                            $percent_deduct = "";
                                            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
                                            $isFPEnable = $this->scopeConfig->getValue(
                                                "razorpay/razorpay_fp_config/enabled_razorpay_fp",
                                                $storeScope
                                            );
                                            $fpDealerStatus = $razorpayDealerData->getFullPaymentFlag();
                                            if ($fpDealerStatus == 1 && $isFPEnable == 1 && $razorResponse['payment_flag'] == 1) {
                                                $percent_deduct = $razorpayDealerData->getFpDeductionPercentage();
                                            } else {
                                                $percent_deduct = $razorpayDealerData->getDefaultPercentage();
                                            }

                                            $deducted_amount = $percent_deduct * $razorResponse['amount'];
                                            $deducted_amount = $deducted_amount / 100;
                                            $transferAmount = $razorResponse['amount'] - $deducted_amount;
                                            $transferAmount = round($transferAmount);
                                            $razorpay_acc = $razorpayDealerData->getDealerRazorpayAccount();
                                            /*Checking Dealer data in dealer_razorpay_rule table*/

                                            $transaction_flag = 6;
                                            $transaction_to = "dealer";
                                            $transaction_type = "transfer";

                                            /*Preparing Notes & Amount*/
                                            $firstName = $orderData->getCustomerFirstname();
                                            $lastName = $orderData->getCustomerLastname();
                                            $incrementId = $orderData->getIncrementId();
                                            $notes = [
                                                'order_id' => $orderData->getEntityId(),
                                                'roll_no' => $incrementId,'name' => $firstName.' '.$lastName
                                            ];
                                            $deducted_amount = $razorResponse['amount'] - $transferAmount;

                                            /*Fetching BFL account*/
                                            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
                                            $BlfAccountRazorpay = $this->scopeConfig->getValue(
                                                "razorpay/rzp_transfer/rzp_bfl_account",
                                                $storeScope
                                            );

                                            /*Preparing Request*/
                                            $requestPacket = [
                                                "transfers" => [
                                                    ['account' => $razorpay_acc,'amount' => $transferAmount,'currency' => 'INR','notes' => $notes],
                                                    ['account' => $BlfAccountRazorpay,'amount' => $deducted_amount,'currency' => 'INR','notes' => $notes]
                                                ]
                                            ];

                                            /*Call Transfer function*/
                                            $result = $this->_razorpayHelper->transferByPaymentId($razorResponse['razorpay_payment_id'], $requestPacket);
                                            if (isset($result['items'][0]['id'])) {
                                                $resultArr[] = (array)$result['items'][0];
                                                $resultArr[] = (array)$result['items'][1];
                                                $transaction_status = "success";
                                                $message = "Success";
                                            } else {
                                                $resultArr = (array)$result;
                                                $transaction_status = "fail";
                                                $message = "Fail";
                                            }
                                            $razoarpay_response = json_encode($resultArr);

                                        }

                                        /*Save data to razorpay table*/
                                         $razorpayPayments = $this->_razorpayPayment;
                                         $razorpayPayments->setOrderId($orderData->getEntityId());
                                         $razorpayPayments->setRazorpayOrderId($razorResponse['razorpay_order_id']);
                                         $razorpayPayments->setTransactionFlag($transaction_flag); // 2 flag for refund from csv import or force refund
                                        if ($requestPacket != '') {
                                            $razorpayPayments->setRazorpayRequest(json_encode($requestPacket));
                                        }
                                         $razorpayPayments->setRazorpayResponse($razoarpay_response);
                                         $razorpayPayments->setOrderIncrementId($getData[0]);
                                         $razorpayPayments->setTransactionStatus($transaction_status);
                                         $razorpayPayments->setTransactionType($transaction_type);
                                         $razorpayPayments->setTransactionTo($transaction_to);
                                         $razorpayPayments->setAmount($razorResponse['amount']);
                                         $razorpayPayments->save();
                                         $checkRecord = true;

                                         /*Order cancel in magento*/
                                        if ($transaction_status == "success" && $getData[1] == 0) {
                                            $orderData->cancel($orderData->getEntityId());
                                            $orderData->addStatusHistoryComment("order cancelled");
                                            $orderData->setCancelledBy("Admin");
                                            $orderData->setCancelledByName("Admin");// newly added by Shaunak Datar
                                            $orderData->save();
                                        }

                                        if ($transaction_status == "success" && $getData[1] == 1) {
                                            $orderData->setState('product_delivered');
                                            $orderData->setStatus("product_delivered");
                                            $orderData->save();
                                        }

                                    } else {
                                        $message = "Not Paid By Razorpay";
                                    }
                                } catch (\Exception $e) {

                                    $logger_refund->info("Razorpay Error: ".$e->getMessage());
                                    $message = $e->getMessage();
                                    $exception_params = [];
                                    $exception_params['order_id'] = $orderData->getEntityId();
                                    $exception_params['order_increment_id'] = $getData[0];
                                    $exception_params['transaction_status'] = "fail";
                                    $exception_params['transaction_type'] = $transaction_type;
                                    if ($requestPacket != '') {
                                        $exception_params['razorpay_request'] = json_encode($requestPacket);
                                    }
                                    $exception_params['razorpay_response'] = json_encode(['error' => $e->getMessage()]);
                                    $this->_razorpayHelper->RazorpayExceptions($exception_params);
                                }
                                $response[] = [$getData[0],$getData[1],$message];
                            }
                        } else {
                            $_error = true;
                        }
                        $icount++;
                    }

                    if ($_error) {
                        $this->messageManager->addErrorMessage(__('Invalid column Count. Please verify file. Download the sample CSV for reference.'));
                    } elseif (!$checkRecord) {
                        $this->messageManager->addErrorMessage(__('No Records has been imported'));
                        if ($response!="") {
                            return $this->createCsv($response);
                        }
                    } else {
                        $this->messageManager->addSuccessMessage(__('Razorpay file has been imported successfully.'));
                        if ($response!="") {
                            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                            return $this->createCsv($response);
                        }
                    }
                } else {
                    $this->messageManager->addErrorMessage(__('Invalid File Format.'));
                }
            }
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(
                __('Something went wrong. Please verify the CSV file. Download the sample CSV for reference.'.$e->getMessage())
            );
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }
    }

    /**
     *
     * @param $orderId
     * @return false|mixed
     */
    public function checkTransaction($orderId)
    {
        $_razorPaymentData = $this->_razorpayPayment->getCollection()
            ->addFieldToFilter('order_id', ['eq' => $orderId])
            ->addFieldToFilter('transaction_flag', ['eq' => '0'])
            ->addFieldToFilter('transaction_status', ['eq' => 'success']);
        if ($_razorPaymentData->count() > 0) {
            $razorResponse = $_razorPaymentData->getFirstItem()->getRazorpayResponse();
            $razorResponse = json_decode($razorResponse, true);
            if (isset($razorResponse['razorpay_payment_id'])) {
                $razorResponse['amount'] = $_razorPaymentData->getFirstItem()->getAmount();
                $razorResponse['payment_flag'] = $_razorPaymentData->getFirstItem()->getPaymentFlag();
                return $razorResponse;
            }
            return false;
        } else {
            return false;
        }
    }

    /**
     *
     * @param $dealerId
     * @return false|\Magento\Framework\DataObject|void
     */
    public function razorpayDealer($dealerId = null)
    {
        if ($dealerId != null) {
            $razorpayDealerData = $this->dealerRazorpayRule->getCollection()
                ->addFieldToFilter("dealer_id", ['eq' => $dealerId])->addFieldToFilter("status", ['eq' => 1]);
            if ($razorpayDealerData->count() > 0) {
                return $razorpayDealerData->getFirstItem();
            }
            return false;
        }
    }

    /**
     * @param type void
     */
    public function createCsv($response)
    {
        $heading = [
            __('OrderId'),
            __('Transaction Flag'),
            __('Status'),
        ];
        $outputDirectory = $this->directoryList->getPath('var') . '/razorpay-sample';
        if (!is_dir($outputDirectory)) {
            $this->file->mkdir(
                $this->directoryList->getPath('var').'/razorpay-sample',
                0775
            );
        }
        $outputFile = $this->directoryList->getPath('var') . '/razorpay-sample/razorpay_refund.csv';
        $handle = fopen($outputFile, 'w');
        if ($handle != false) {
            fputcsv($handle, $heading);
            foreach ($response as $row) {
                $row = [ __($row[0]),__($row[1]),__($row[2])];
                fputcsv($handle, $row);
            }
        }
        fclose($handle);
        chmod($outputFile, 0757);
        $this->_razorpayHelper->downloadCsv($outputFile);
        //unlink($outputFile);
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_refund');
    }
}
