<?php
/**
 * @category  Embitel
 * @package   Razorpay_Magento
 * @author    shaunak.datar@embitel.com
 * @copyright 2015-2019 Embitel Technologies (I) Pvt. Ltd
 * @description this file allows user to download a sample of csv file
 */

namespace Razorpay\Magento\Controller\Adminhtml\Refund;

use Magento\ImportExport\Controller\Adminhtml\Export as ExportController;
use Magento\Framework\Controller\ResultFactory;
use Razorpay\Magento\Helper\RazorpayHelper;

class Samplecsv extends ExportController
{

    /**
     * @var RazorpayHelper
     */
    private $razorpayHelper;

    /**
     * @var \Magento\Framework\Filesystem\DirectoryList
     */
    private $directoryList;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param RazorpayHelper $razorpayHelper
     * @param \Magento\Framework\Filesystem\DirectoryList $directoryList
     */
    public function __construct(
        \Magento\Backend\App\Action\Context  $context,
        RazorpayHelper $razorpayHelper,
        \Magento\Framework\Filesystem\DirectoryList $directoryList
    ) {
        $this->razorpayHelper = $razorpayHelper;
        $this->directoryList = $directoryList;
        parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        try {
            //$sample_file = $this->directoryList->getPath('var') . '/bbps_payment_sample.csv';
            $this->createCsv();
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__('Something went wrong. Please try again.'));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }
    }

    /**
     * @return void
     * @throws \Magento\Framework\Exception\FileSystemException
     */
    public function createCsv()
    {
        $heading = [
            __('Order Increment Id'),
            __('Refund / Transfer')
        ];

        $rows = [];
        $rows[] = ['OrderId' => '1000003966',"transaction_status" => "0"];
        $rows[] = ['OrderId' => '1000003967',"transaction_status" => "0"];
        $rows[] = ['OrderId' => '1000003968',"transaction_status" => "1"];
        $outputFile = $this->directoryList->getPath('var') . '/razorpay_refund_sample.csv';
        $handle = fopen($outputFile, 'w');
        if ($handle != false) {
            fputcsv($handle, $heading);
            foreach ($rows as $data) {
                $row = [
                __($data['OrderId']),
                __($data['transaction_status'])
                ];
                fputcsv($handle, $row);
            }

        }
        fclose($handle);
        chmod($outputFile, 0777);

        $this->razorpayHelper->downloadCsv($outputFile);
        unlink($outputFile);
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_refund');
    }
}
