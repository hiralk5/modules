<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;
use Razorpay\Magento\Model\DealerRazorpayRuleFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;

class ImportDealerRulePost extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var DealerRazorpayRuleFactory
     */
    protected $dealerRazorpayRuleFactory;

    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * @var File
     */
    private $file;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
     * @param DirectoryList $directoryList
     * @param File $file
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        DealerRazorpayRuleFactory $dealerRazorpayRuleFactory,
        DirectoryList $directoryList,
        File  $file
    ) {
        parent::__construct($context);
        $this->dealerRazorpayRuleFactory = $dealerRazorpayRuleFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->directoryList = $directoryList;
        $this->file = $file;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $icount = 0;
        $_error = false;
        $response = [];
        $checkRecord = false;
        try {
            $file = $this->getRequest()->getFiles()->get('importcsv');
            if (isset($file['name'])) {
                  $csvCheck = pathinfo($file['name'], PATHINFO_EXTENSION);
                if ($csvCheck == 'csv') {

                    $filename = $file["tmp_name"];
                    $file = fopen($filename, "r");
                    while (($getData = fgetcsv($file, 99999, ",")) !== false) {

                        if (isset($getData[0]) && isset($getData[1])) {
                            if ($icount) {
                                $dataCount = $this->checkData($getData[0], $getData[1]);
                                if ($dataCount == 0) {
                                    if ($getData[2] > 0) {

                                        if ($getData[5] > 1) {
                                            $getData[5] = 1;
                                        }

                                        if ($getData[6] > 1) {
                                            $getData[6] = 1;
                                        }
                                        $getData[2] = number_format($getData[2], 2);
                                         $razorpayData = $this->dealerRazorpayRuleFactory->create();
                                            $razorpayData->setDealerId($getData[0]);
                                            $razorpayData->setDealerRazorpayAccount($getData[1]);
                                            $razorpayData->setDefaultPercentage($getData[2]);
                                            $razorpayData->setFpCancelAmount($getData[3]);
                                            $razorpayData->setFpDeductionPercentage($getData[4]);
                                            $razorpayData->setFullPaymentFlag($getData[5]);
                                            $razorpayData->setStatus($getData[6]);

                                            $razorpayData->save();
                                            $message = "Success";
                                            $checkRecord = true;
                                    } else {
                                        $message = "Percentage Value Invalid";
                                    }

                                } else {
                                    if ($getData[2] > 0) {
                                        if ($getData[5] > 1) {
                                            $getData[5] = 1;
                                        }
                                        if ($getData[6] > 1) {
                                            $getData[6] = 1;
                                        }
                                        $getData[2] = number_format($getData[2], 2);
                                        $updatedata = $this->dealerRazorpayRuleFactory->create()->getCollection()
                                            ->addFieldToFilter(['dealer_id'], [['eq' => $getData[0]]])->getFirstItem();
                                        $updateid = $updatedata->getId();
                                        if ($updateid!='') {
                                            $razorpayupdateData = $this->dealerRazorpayRuleFactory->create();
                                            $razorpayupdateData->load($updateid);
                                            $razorpayupdateData->setDealerId($getData[0]);
                                            $razorpayupdateData->setDealerRazorpayAccount($getData[1]);
                                            $razorpayupdateData->setDefaultPercentage($getData[2]);
                                            $razorpayupdateData->setFpCancelAmount($getData[3]);
                                            $razorpayupdateData->setFpDeductionPercentage($getData[4]);
                                            $razorpayupdateData->setFullPaymentFlag($getData[5]);
                                            $razorpayupdateData->setStatus($getData[6]);
                                            $razorpayupdateData->save();
                                                $message = "Razorpay Dealers Update successfully";
                                                $checkRecord = true;
                                        }
                                    } else {
                                        $message = "Percentage Value Invalid";
                                    }
                                }
                                    $response[] = [
                                        $getData[0], $getData[1], $getData[2], $getData[3],
                                        $getData[4],$getData[5],$getData[6],$message
                                    ];
                            }
                        } else {
                            $_error = true;
                        }
                        $icount++;
                    }

                    if ($_error) {
                        $this->messageManager->addErrorMessage(
                            __('Invalid column Count. Please verify file. Download the sample CSV for reference.')
                        );
                    } elseif (!$checkRecord) {
                        $this->messageManager->addErrorMessage(
                            __('No Records has been imported')
                        );
                    } else {
                        $this->messageManager->addSuccessMessage(
                            __('Razorpay Dealers file has been imported successfully.')
                        );
                        if ($response!="") {
                            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                            $resultRedirect->setUrl($this->getUrl("razorpay/dealers/importdealerrule"));
                            return $this->createCsv($response);
                        }
                    }
                } else {
                    $this->messageManager->addErrorMessage(__('Invalid File Format.'));
                }

                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $resultRedirect->setUrl($this->getUrl("razorpay/dealers/importdealerrule"));
                return $resultRedirect;
            }
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(
                __('Something went wrong. Please verify the CSV file. Download the sample CSV for reference.'.$e->getMessage())
            );
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->getUrl("razorpay/dealers/importdealerrule"));
            return $resultRedirect;
        }
    }

    /**
     *
     * @param $dealer_id
     * @param $razorpay_id
     * @return mixed
     */
    public function checkData($dealer_id, $razorpay_id)
    {
        $dealertData = $this->dealerRazorpayRule
            ->getCollection()->addFieldToFilter(['dealer_id'], [['eq' => $dealer_id]]);
        return $dealertData->count();
    }

    /**
     * @param type void
     */
    public function createCsv($response)
    {
        $heading = [
            __('Dealer Id'),
            __('Razorpay Account'),
            __('Percentage'),
            __('Cancel Charge Amount'),
            __('FP Deduction Percent'),
            __('FP Payment'),
            __('Status'),
            __('Import Status'),
        ];
        $directory_path = $this->directoryList;
        $outputDirectory = $directory_path->getPath('var') . '/razorpay-sample';
        if (!is_dir($outputDirectory)) {
            $this->file->mkdir($directory_path->getPath('var').'/razorpay-sample', 0775);
        }
        $outputFile = $this->directoryList->getPath('var') . '/razorpay-sample/razorpay_dealer_response.csv';

        $handle = fopen($outputFile, 'w');
        if ($handle != false) {
            fputcsv($handle, $heading);
            foreach ($response as $row) {
                $row = [
                    __($row[0]),__($row[1]), __($row[2]),__($row[3]),
                    __($row[4]), __($row[5]), __($row[5]), __($row[7])
                ];
                fputcsv($handle, $row);
            }
        }
        fclose($handle);
        chmod($outputFile, 0757);
        $this->downloadCsv($outputFile);
        //unlink($outputFile);
    }

    /**
     * @param type $file
     * @description this function used to download file while records export functionality
     */
    public function downloadCsv($file)
    {
        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename=' . basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
        }
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }
}
