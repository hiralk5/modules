<?php
/**
 * @Module         : Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : Razorpay Dealer
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Razorpay\Magento\Model\DealerRazorpayRuleFactory;

class MassDelete extends \Magento\Backend\App\Action
{

    /**
     * @param Context $context
     * @param DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
     */
    public function __construct(
        Context $context,
        DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
    ) {
        parent::__construct($context);
        $this->dealerRazorpayRuleFactory = $dealerRazorpayRuleFactory;
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $ids = $this->getRequest()->getParam('id');

        if (!is_array($ids) || empty($ids)) {
            $this->messageManager->addErrorMessage(__('Please select Dealers.'));
        } else {
            try {
                foreach ($ids as $id) {
                    $row = $this->dealerRazorpayRuleFactory->create()->load($id);
                    $row->delete();
                }
                $this->messageManager->addSuccessMessage(
                    __('A total of %1 record(s) have been deleted.', count($ids))
                );
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }

        $this->_redirect('*/*/');
    }
}
