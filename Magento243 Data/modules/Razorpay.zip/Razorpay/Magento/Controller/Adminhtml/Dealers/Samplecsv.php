<?php

/**
 * @category  Embitel
 * @package   Razorpay_Magento
 * @author    shaunak.datar@embitel.com
 * @copyright 2015-2019 Embitel Technologies (I) Pvt. Ltd
 * @description this file allows user to download a sample of csv file
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Filesystem\Io\File;
use Magento\ImportExport\Controller\Adminhtml\Export as ExportController;
use Magento\Framework\Controller\ResultFactory;

class Samplecsv extends ExportController
{

    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * @var File
     */
    private $file;

    /**
     * @param Context $context
     * @param DirectoryList $directoryList
     * @param File $file
     */
    public function __construct(
        Context $context,
        DirectoryList $directoryList,
        File $file
    ) {
        $this->directoryList = $directoryList;
        $this->file = $file;
        parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        try {
            $this->createCsv();
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(__('Something went wrong. Please try again.'));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            return $resultRedirect;
        }
    }

   /**
    * @param type void
    */
    public function createCsv()
    {
        $heading = [
            __('Dealer Id'),
            __('Razorpay Account'),
            __('Percentage'),
            __('Cancel Charge Amount'),
            __('FP Deduction Percent'),
            __('FP Flag 1/0'),
            __('Status')
        ];

        $rows = [];
        $rows[] = [
            'Dealer_Id' => 'BFD123','Razorpay_Account' => '996664260411',
            'Percentage' => '2.5','Cancel_Charge_Amount' => '10',
            'FP_Deduction_Percent' => '5.0','Status' => '1','FP_Flag' => 1
        ];
        $rows[] = [
            'Dealer_Id' => 'BFD124','Razorpay_Account' => '996664260412',
            'Percentage' => '3.5','Cancel_Charge_Amount' => '12',
            'FP_Deduction_Percent' => '6.0','Status' => '1','FP_Flag' => 0
        ];
        $directory_path = $this->directoryList;
        $outputDirectory = $directory_path->getPath('var') . '/razorpay-sample';
        if (!is_dir($outputDirectory)) {
            $this->file->mkdir($directory_path->getPath('var').'/razorpay-sample', 0775);
        }
        $outputFile = $this->directoryList->getPath('var') . '/razorpay-sample/razorpay_dealer_sample.csv';

        $handle = fopen($outputFile, 'w');
        if ($handle != false) {
            fputcsv($handle, $heading);
            foreach ($rows as $data) {
                $row = [
                __($data['Dealer_Id']),
                __($data['Razorpay_Account']),
                __($data['Percentage']),
                __($data['Cancel_Charge_Amount']),
                __($data['FP_Deduction_Percent']),
                __($data['FP_Flag']),
                __($data['Status'])
                ];
                fputcsv($handle, $row);
            }

        }
        fclose($handle);
        chmod($outputFile, 0757);

        $this->downloadCsv($outputFile);
        //unlink($outputFile);
    }

    /**
     * @param type $file
     * @description this function used to download file while records export functionality
     */
    public function downloadCsv($file)
    {
        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename=' . basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
        }
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }
}
