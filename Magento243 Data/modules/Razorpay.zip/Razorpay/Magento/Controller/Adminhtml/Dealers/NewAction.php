<?php
/**
 * @Module         : Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : Razorpay Dealer Module
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

class NewAction extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Backend\Model\View\Result\ForwardFactory
     */
    protected $resultForwardFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory
    ) {
        $this->resultForwardFactory = $resultForwardFactory;
        parent::__construct($context);
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $resultForward = $this->resultForwardFactory->create();
        return $resultForward->forward('edit');
    }
}
