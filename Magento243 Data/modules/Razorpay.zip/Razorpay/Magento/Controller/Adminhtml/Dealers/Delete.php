<?php
/**
 * @category   Embitel
 * @package    Magento_Razorpay
 * @author     shaunak.datar@embitel.com
 * @description  delete dealer rule record
 */
namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Razorpay\Magento\Model\DealerRazorpayRuleFactory;

class Delete extends \Magento\Backend\App\Action
{
    /**
     * @var DealerRazorpayRuleFactory
     */
    private $dealerRazorpayRuleFactory;

    /**
     * @param Context $context
     * @param DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
     */
    public function __construct(
        Context $context,
        DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
    ) {
        parent::__construct($context);
        $this->dealerRazorpayRuleFactory = $dealerRazorpayRuleFactory;
    }
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }

    /**
     * Delete Action
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        if (!isset($id)) {
            $this->messageManager->addErrorMessage(__('Please select Record.'));
        } else {
            try {
                $row = $this->dealerRazorpayRuleFactory->create()->load($id);
                $row->delete();
                $this->messageManager->addSuccessMessage(
                    __('Record has been deleted.')
                );
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            }
        }
         $this->_redirect('*/*/');
    }
}
