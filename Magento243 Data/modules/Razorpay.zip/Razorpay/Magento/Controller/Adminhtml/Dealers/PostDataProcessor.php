<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Razorpay\Magento\Model\DealerRazorpayRule;

class PostDataProcessor
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime\Filter\Date
     */
    protected $dateFilter;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $messageManager;

    /**
     * @var DealerRazorpayRule
     */
    protected $dealerRazorpayRule;

    /**
     * @param \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\Core\Model\Layout\Update\ValidatorFactory $validatorFactory
     */
    public function __construct(
        \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        DealerRazorpayRule $dealerRazorpayRule
    ) {
        $this->dateFilter = $dateFilter;
        $this->messageManager = $messageManager;
        $this->dealerRazorpayRule = $dealerRazorpayRule;
    }

    /**
     * Filtering posted data. Converting localized data if needed
     *
     * @param array $data
     * @return array
     */
    public function filter($data)
    {
        $inputFilter = new \Zend_Filter_Input(
            [],
            [],
            $data
        );
        $data = $inputFilter->getUnescaped();
        return $data;
    }

    /**
     * Validate post data
     *
     * @param array $data
     * @return bool     Return FALSE if someone item is invalid
     */
    public function validate($data)
    {
        $errorNo = true;
        return $errorNo;
    }

    /**
     *
     * @param $data
     * @return int
     */
    public function validateData($data)
    {
        $dealerData = $this->dealerRazorpayRule->getCollection()
            ->addFieldToFilter(['dealer_id'], [['eq' => $data['dealer_id']]]);
        if (isset($data['id'])) {
            $dealerData->addFieldToFilter("id", ['neq' => $data['id']]);
        }

        return $dealerData->count();
    }
}
