<?php
/**
 * @category   Embitel
 * @package    Razorpay_Magento
 * @author     shaunak.datar@embitel.com
 */
 
namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
   /**
    * @var PageFactory
    */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
    
    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }

    /**
     * Bannerslider List action
     *
     * @return void
     */
    public function execute()
    {
        /* @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu(
            'Razorpay_Magento::razorpay'
        )->addBreadcrumb(
            __('Razorpay'),
            __('Razorpay')
        )->addBreadcrumb(
            __('Razorpay Dealer Rule'),
            __('Razorpay Dealer Rule')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Dealer Razorpay Rule'));
        return $resultPage;
    }
}
