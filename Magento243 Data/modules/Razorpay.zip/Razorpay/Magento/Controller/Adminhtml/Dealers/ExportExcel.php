<?php

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;

class ExportExcel extends \Magento\Backend\App\Action
{
    public const ADMIN_RESOURCE = 'Razorpay_Magento::razorpay_dealer_rule';

    /**
     * @var FileFactory
     */
    private $fileFactory;

    /**
     * @param Context $context
     * @param FileFactory $fileFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory
    ) {
        parent::__construct($context);
        $this->fileFactory = $fileFactory;
    }

    /**
     * Check permission for passed action
     *
     * @param string $resourceId
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        try {
            $this->_view->loadLayout(false);
            $fileName = 'DealerRazorpayRule.xls';
            $exportBlock = $this->_view->getLayout()
                ->createBlock('Razorpay\Magento\Block\Adminhtml\DealerRazorpayRule\Grid');
        } catch (Exception $ex) {
            return ;
        }

        return $this->fileFactory->create(
            $fileName,
            $exportBlock->getExcelFile(),
            DirectoryList::VAR_DIR
        );
    }
}
