<?php
/**
 * @Module         : Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : Saves Dealer rule record
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action;
use Razorpay\Magento\Model\DealerRazorpayRuleFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var PostDataProcessor
     */
    protected $dataProcessor;

    /**
     * @var DealerRazorpayRuleFactory
     */
    private DealerRazorpayRuleFactory $dealerRazorpayRuleFactory;

    /**
     * @param Action\Context $context
     * @param PostDataProcessor $dataProcessor
     * @param DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
     */
    public function __construct(
        Action\Context $context,
        PostDataProcessor $dataProcessor,
        DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
    ) {
        $this->dataProcessor = $dataProcessor;
        $this->dealerRazorpayRuleFactory = $dealerRazorpayRuleFactory;
        parent::__construct($context);
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }

     /**
      * Save action
      *
      * @return void
      */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        if ($data) {
            $data = $this->dataProcessor->filter($data);
            $model = $this->dealerRazorpayRuleFactory->create();
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
            $dataCount = $this->dataProcessor->validateData($data);

            if ($dataCount > 0) {
                $this->messageManager->addErrorMessage(__('Dealer Id or Razorpay Id already exists'));
                $this->_redirect('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                return;
            }

            if ($data['default_percentage'] <= 0) {
                $this->messageManager->addErrorMessage(__('Please enter percent value greater than 0'));
                $this->_redirect('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                return;
            }


            $model->addData($data);
            if (!$this->dataProcessor->validate($data)) {
                $this->_redirect('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                return;
            }



            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('The Data has been saved.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                    return;
                }
                $this->_redirect('*/*/');
                return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the data.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
            return;
        }
        $this->_redirect('*/*/');
    }
}
