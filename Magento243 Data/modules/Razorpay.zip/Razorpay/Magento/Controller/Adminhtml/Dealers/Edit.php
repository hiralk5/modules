<?php
/**
 * @Module         : Razorpay Module
 * @Package        : Razorpay_Magento
 * @Description    : Edit razorpay dealer rule
 * @Developer      : Shaunak Datar<shaunak.datarr@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Adminhtml\Dealers;

use Magento\Backend\App\Action;
use Razorpay\Magento\Model\DealerRazorpayRuleFactory;

class Edit extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry|null
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var DealerRazorpayRuleFactory
     */
    private $dealerRazorpayRuleFactory;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     * @param DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
        DealerRazorpayRuleFactory $dealerRazorpayRuleFactory
    ) {
        $this->resultPageFactory     = $resultPageFactory;
        $this->_coreRegistry         = $registry;
        parent::__construct($context);
        $this->dealerRazorpayRuleFactory = $dealerRazorpayRuleFactory;
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $id     = $this->getRequest()->getParam('id');
        $model     = $this->dealerRazorpayRuleFactory->create();

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This selected record no longer exists.'));
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }

        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);

        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('razorpay', $model);

        $resultPage = $this->_initAction();
        return $resultPage;
    }

    /**
     *
     * @return \Magento\Framework\View\Result\Page
     */
    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }

    /**
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_dealer_rule');
    }
}
