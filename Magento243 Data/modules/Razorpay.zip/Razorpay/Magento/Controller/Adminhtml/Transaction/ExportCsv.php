<?php
namespace Razorpay\Magento\Controller\Adminhtml\Transaction;

use Magento\Framework\App\Filesystem\DirectoryList;

class ExportCsv extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    private $_resultPageFactory;

    /**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */
    private $_fileFactory;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\App\Response\Http\FileFactory $_fileFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context  $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\App\Response\Http\FileFactory $_fileFactory
    ) {
        $this->_resultPageFactory  = $resultPageFactory;
        $this->_fileFactory  = $_fileFactory;
        parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $fileName = 'razorpay_trasaction.csv';
        $resultPage = $this->_resultPageFactory->create();
        $content = $resultPage->getLayout()
            ->createBlock('Razorpay\Magento\Block\Adminhtml\Transaction\Grid')->getCsv();
        return $this->_fileFactory->create($fileName, $content, DirectoryList::VAR_DIR);
    }

     /**
      * {@inheritdoc}
      */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Razorpay_Magento::razorpay_payments_report');
    }
}
