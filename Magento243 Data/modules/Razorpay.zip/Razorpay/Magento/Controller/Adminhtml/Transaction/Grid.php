<?php

namespace Razorpay\Magento\Controller\Adminhtml\Transaction;

class Grid extends \Magento\Customer\Controller\Adminhtml\Index
{
    /**
     * @inheritDoc
     */
    public function execute()
    {
        $this->_view->loadLayout(false);
        $this->_view->renderLayout();
    }
}
