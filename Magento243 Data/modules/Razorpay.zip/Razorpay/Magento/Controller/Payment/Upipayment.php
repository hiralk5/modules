<?php

/**
 * @Package        : Razorpay_Magento
 * @Description    : create razorpay order for upi payment
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;

use Magento\Checkout\Model\Session;
use Magento\Customer\Model\Session as CustomerSession;
use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\AddressFactory;
use Razorpay\Magento\Model\Config;
use Razorpay\Magento\Helper\RazorpayHelper;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Embitel\SellerModule\Model\CustomSellerInfo;

class Upipayment extends \Magento\Framework\App\Action\Action
{

    /**
     * @var Razorpay Order Id
     */
    protected $_razorOrderId;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var Razorpay\Magento\Model\RazorpayPayments
     */
    protected $_razorpayPayments;

    /**
     * @var Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var Magento\Customer\Model\AddressFactory
     */
    protected $_addressFactory;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_Config;

    /**
     * @description Public key for Razorpay
     */
    protected $key_id;

    /**
     * @description Private key for Razorpay
     */
    protected $key_secret;

    /**
     * @var Razorpay\Magento\Helper\RazorpayHelper
     */
    protected $razorpayHelper;

    /**
     * @var Magento\Sales\Api\Data\OrderInterfaceFactory
     */
    protected $orderFactory;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfigInterface;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $customSellerInfo;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param Session $checkoutSession
     * @param CustomerSession $customerSession
     * @param RazorpayPayments $razorpayPayments
     * @param CustomerFactory $customerFactory
     * @param AddressFactory $addressFactory
     * @param Config $Config
     * @param RazorpayHelper $razorpayHelper
     * @param OrderInterfaceFactory $orderFactory
     * @param ScopeConfigInterface $scopeConfigInterface
     * @param CustomSellerInfo $customSellerInfo
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Session $checkoutSession,
        CustomerSession $customerSession,
        RazorpayPayments $razorpayPayments,
        CustomerFactory $customerFactory,
        AddressFactory $addressFactory,
        Config $Config,
        RazorpayHelper $razorpayHelper,
        OrderInterfaceFactory $orderFactory,
        ScopeConfigInterface $scopeConfigInterface,
        CustomSellerInfo $customSellerInfo
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->_razorpayPayments = $razorpayPayments;
        $this->_customerFactory = $customerFactory;
        $this->_addressFactory = $addressFactory;
        $this->_Config = $Config;
        $this->razorpayHelper = $razorpayHelper;
        $this->orderFactory = $orderFactory;
        $this->scopeConfigInterface = $scopeConfigInterface;
        $this->customSellerInfo = $customSellerInfo;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        /*Logger*/
        $dirPath = BP . '/var/log/razorpay/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }

        /*Razorpay Keys*/
        $this->key_id = $this->_Config->getConfigData(Config::KEY_PUBLIC_KEY);
        $this->key_secret = $this->_Config->getConfigData(Config::KEY_PRIVATE_KEY);

         /*Default Customer Name, Email Or Mobile*/
        $customerName =  "Test123";
        $customerEmail = "test123@gmail.com";
        $customerTelephone = "9898989898";

        $customerName = $this->scopeConfigInterface->getValue(
            "razorpay/razorpay_dummy_fields/cust_full_name",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );
        $customerEmail = $this->scopeConfigInterface->getValue(
            "razorpay/razorpay_dummy_fields/cust_email",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );
        $customerTelephone = $this->scopeConfigInterface->getValue(
            "razorpay/razorpay_dummy_fields/cust_mobile",
            \Magento\Store\Model\ScopeInterface::SCOPE_STORES
        );

        try {

            $incrementId = $this->getRequest()->getParam('incrementid');

            $razorpayPaybleAmt = $this->getRequest()->getParam('razorpayPaybleAmt');

            $sellerid = $this->getRequest()->getParam('sellerid');
            $isFPDealer = $this->razorpayHelper->checkFPDealer($sellerid);
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
            $isEnabledFP = $this->scopeConfigInterface->getValue(
                "razorpay/razorpay_fp_config/enabled_razorpay_fp",
                $storeScope
            );
            $dealId = "";
            $offerprice = "";
            $order = $this->orderFactory->create()->loadByIncrementId($incrementId);//$this->_checkoutSession->getLastRealOrder();
            /*Getting order details from session*/
            if ($order->getEntityId()) {

                /*Fetching Request Data*/
                $paymentData = $this->getRequest()->getParam('paymentData');
                if (isset($paymentData['method']) && $paymentData['method'] != 'intentupi') {
                //Validate VPA
                    if ($paymentData['vpa'] != null) {
                        $vpaResponse = $this->razorpayHelper->validateVpa($paymentData['vpa']);
                        $vpaResponse = json_decode($vpaResponse, true);
                        if (isset($vpaResponse['error'])) {
                            $result = $this->_resultJsonFactory->create();
                            $result->setData($vpaResponse);
                            return $result;
                        }
                    }
                }
                $order = $this->orderFactory->create()->loadByIncrementId($incrementId);//$this->_checkoutSession->getLastRealOrder();

                $customSellerInfoData = $this->customSellerInfo->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()]);
                if ($customSellerInfoData->count() > 0) {
                    $customSellerInfoData = $customSellerInfoData->getFirstItem();
                    $dealId = $customSellerInfoData->getDealId();
                    $offerprice = $customSellerInfoData->getOfferPrice();
                }
                if ($isEnabledFP == 1 && $isFPDealer == 1 && $dealId == null) {
                    $razorpayPaybleAmt = $offerprice * 100;
                } else {
                    $razorpayPaybleAmt = $razorpayPaybleAmt * 100;
                }

                /*Converting Payble amount in paisa format for razorpay*/

               /* $customer = array("name" => $this->_customerSession->getCustomer()->getFirstname()." ".$this->_customerSession->getCustomer()->getLastname(),"email" => $this->_customerSession->getCustomer()->getEmail());
                $customerLoad = $this->_customerFactory->create()->load($this->_customerSession->getCustomer()->getEntityId());
                $billingAddressId = $customerLoad->getDefaultBilling();
                $BillingAddress = $this->_addressFactory->create()->load($billingAddressId);
                $customerTelephone = '';
                if($BillingAddress->getTelephone()){
                    $customerTelephone = $BillingAddress->getTelephone();
                }*/
                //$razorpayPaybleAmt = 100;
                $notes = $this->razorpayHelper->getPushFieldsNotes($order->getEntityId(), $incrementId, $order->getDeliveryDate());

                $customer = ["name" => $customerName,"email" => $customerEmail];

                /*Creating Order & Payment*/
                $api = new Api($this->key_id, $this->key_secret);
                $ramdom_number = rand(10, 100);
                //$razorpayPaybleAmt = 10000;
                $orderData = [
                    'receipt'         => $order->getEntityId().$ramdom_number,
                    'amount'          => $razorpayPaybleAmt,
                    'currency'        => 'INR',
                    'payment_capture' => 1,
                    'notes'           => $notes
                ];

                $razorpayData = $this->_razorpayPayments->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()])
                    ->addFieldToFilter('transaction_type', ['eq' => "payment"]);
                $this->_razorOrderId = "";
                if ($razorpayData->count() > 0) {
                    $retry_count = $razorpayData->getFirstItem()->getRetryCount();
                    if ($retry_count >= 3) {
                        $data = [
                            "order_id" => $razorpayData->getFirstItem()->getRazorpayOrderId(),
                            "payment_attempt_error" => true
                        ];
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($data);
                        return $result;
                    }
                    $this->_razorOrderId = $razorpayData->getFirstItem()->getRazorpayOrderId();
                } else {
                    $razorpayOrder = $api->order->create($orderData);
                    $razorOrderArr = (array)$razorpayOrder;

                    $this->_razorOrderId = $razorpayOrder['id'];
                }

                try {
//                    $ismobile = $this->isMobile();
//                    if($ismobile){
//                        unset($paymentData['vpa']);
//                        $paymentData['flow'] = 'intent';
//                    }
                    if (isset($paymentData['method']) && $paymentData['method'] == 'intentupi') {
                        unset($paymentData['vpa']);
                        $paymentData['flow'] = 'intent';
                    }
                    $paymentData['amount'] = $razorpayPaybleAmt;
                    $paymentData['currency'] = "INR";
                    $paymentData['order_id'] = $this->_razorOrderId;
                    $paymentData['contact'] = $customerTelephone;
                    $paymentData['email'] =   $customerEmail;//$this->_customerSession->getCustomer()->getEmail();
                    $paymentData['referer'] = $_SERVER['HTTP_REFERER'];
                    $paymentData['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
                    $paymentData['ip'] = $_SERVER['REMOTE_ADDR'];
                    $paymentData['notes'] = $notes;

                    $response = $this->razorpayHelper->createUpiPayment($paymentData);

                    $response = json_decode($response, true);

                    if (isset($response['razorpay_payment_id'])) {
                        $response['amount'] = $razorpayPaybleAmt;
                        $response['razorpay_order_id'] = $this->_razorOrderId;
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($response);
                        return $result;
                    }

                } catch (\Exception $e) {

                    $data = ["order_id" => '',"error" => 'error in payment processing'];
                    $result = $this->_resultJsonFactory->create();
                    $result->setData($data);
                    return $result;
                }

            } else {
                 $data = ["order_id" => '',"error" => 'error in payment processing'];
            }

            $result = $this->_resultJsonFactory->create();
            $result->setData($paymentData);
            return $result;

        } catch (\Exception $e) {

            $data = ["order_id" => '',"error" => 'error in payment processing'];
            $result = $this->_resultJsonFactory->create();
            $result->setData($data);
            return $result;
        }
    }

    /**
     *
     * @return false|int
     */
    function isMobile()
    {
        return preg_match(
            "/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",
            $_SERVER["HTTP_USER_AGENT"]
        );
    }
}
