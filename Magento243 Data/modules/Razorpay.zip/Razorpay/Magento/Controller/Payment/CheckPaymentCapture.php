<?php

namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;
use Razorpay\Magento\Model\Config;

class CheckPaymentCapture extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @var \Razorpay\Magento\Model\Config
     */
    protected $config;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param Config $config
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Config $config
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->config = $config;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
            /*Maintaining Logger*/
            /*Getting Payment Id*/
            $payment_id = "";
        if ($this->getRequest()->getParam('razorpay_payment_id') != null) {
            $payment_id = $this->getRequest()->getParam('razorpay_payment_id');
        }
            /*Fetching Razorpay Keys*/
            $key_id = $this->config->getConfigData(Config::KEY_PUBLIC_KEY);
            $key_secret = $this->config->getConfigData(Config::KEY_PRIVATE_KEY);

            /*Initiating API*/
            $api = new Api($key_id, $key_secret);

            $response = $api->payment->fetch($payment_id);

        if (isset($response['status'])) {
            $response = ["status" => $response['status']];
            $result = $this->_resultJsonFactory->create();
        } else {
            $response = ["error" => $response['error']];
            $result = $this->_resultJsonFactory->create();
        }

            $result->setData($response);
            return $result;
    }
}
