<?php
namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;
use Razorpay\Magento\Model\Config;
use Magento\Framework\Module\Manager as ModuleManager;

class Test extends \Magento\Framework\App\Action\Action
{

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_Config;

    /**
     * @var Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param Config $config
     * @param ModuleManager $moduleManager
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        Config $config,
        ModuleManager $moduleManager
    ) {
        $this->_pageFactory = $pageFactory;
        $this->_Config = $config;
        $this->moduleManager = $moduleManager;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
            /*Logger*/
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpay/razorpayRefund.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $logger->info("test log");

            $razorPayKey = "rzp_test_dY5S5wHp8XqzGB";
        $razorPaySecret = "4ua0wIW6AsLYaFqj1lKphhmP";
            $api = new Api($razorPayKey, $razorPaySecret);
            //$result = $api->payment->fetch("");
            //$result = json_encode($result);
            //echo "<pre>";
            //print_r($result);exit;
           /*try{
            $url = "https://api.razorpay.com/v1/payments/validate/vpa/";
            $vpa = "8888513386@upii";
            $userData = array("vpa" => $vpa);
            $autKey = $razorPayKey . ':' . $razorPaySecret;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url."?vpa=8888@upi");
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_USERPWD, "$autKey");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            if($response){

                $response = json_decode($response,true);

                if(isset($response['success'])){
                    print_r($response['success']);
                }else if (isset ($response['error'])){
                    print_r($response);
                }
            }
            exit;
            $logger->info('Api Response'.$response);
            if (curl_errno($ch)) {
                 $error_msg = curl_error($ch);
                 $logger->info('Api Error'.$error_msg);
            }
            curl_close($ch);
          }catch(Exception $e){
           $logger->info('Error'.$e->getMessage());
          }*/

   /*$userData = array("username" => "bfladmin", "password" => "Bajaj@dmin1");
   $ch = curl_init("http://bfl.dev.emb/rest/V1/integration/admin/token");
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
   curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($userData));
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Content-Lenght: " . strlen(json_encode($userData))));

   $token = curl_exec($ch);


   $data = array("statusHistory" => array("comment" => "test transfer","status" => "canceled"));
   $ch = curl_init("http://bfl.dev.emb//rest/V1/orders/1000004174/comments");
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
   curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . json_decode($token)));

   $result = curl_exec($ch);
   $err = curl_error($ch);
   if ($err) {
     echo "cURL Error #:" . $err;exit;
   }
   print_r($result);*/
            $key_id = $this->_Config->getConfigData(Config::KEY_PUBLIC_KEY);
            $key_secret = $this->_Config->getConfigData(Config::KEY_PRIVATE_KEY);

            $api = new Api($key_id, $key_secret);
            $paymentId = "pay_DrGVzsJP6ZilXc";
            $arr = ["account" => "acc_D8CQeicVwxXll3","amount" => 200,"currency" => 'INR'];
            $result = $api->payment->fetch("pay_DrHrRxbxvkKhwP");
            $result->capture(['amount' => 100, 'currency' => 'INR']);
            print_r($result);
            return;
            //$this->_razorCron->execute();
   //return $this->_pageFactory->create();
    }
}
