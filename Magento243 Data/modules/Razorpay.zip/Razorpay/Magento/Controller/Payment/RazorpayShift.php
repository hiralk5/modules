<?php

/**
 * @Package        : Razorpay_Magento
 * @Description    : create razorpay order for upi payment
 * @Developer      : Shaunak  Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;

use Magento\Checkout\Model\Session;
use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\AddressFactory;
use Razorpay\Magento\Model\Config;
use Razorpay\Magento\Helper\RazorpayHelper;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Embitel\SellerModule\Model\CustomSellerInfo;
use Magento\Store\Model\StoreManagerInterface;
use Embitel\Nds\Helper\Data as NdsHelper;

class RazorpayShift extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Razorpay Order Id
     */
    protected $_razorOrderId;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var Razorpay\Magento\Model\RazorpayPayments
     */
    protected $_razorpayPayments;

    /**
     * @var Magento\Customer\Model\CustomerFactory
     */
    protected $_customerFactory;

    /**
     * @var Magento\Customer\Model\AddressFactory
     */
    protected $_addressFactory;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_Config;

    /**
     * @description Public key for Razorpay
     */
    protected $key_id;

    /**
     * @description Private key for Razorpay
     */
    protected $key_secret;

    /**
     * @var Razorpay\Magento\Helper\RazorpayHelper
     */
    protected $razorpayHelper;

    /**
     * @var Magento\Sales\Api\Data\OrderInterfaceFactory
     */
    protected $orderFactory;

    /**
     * @var Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfigInterface;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $customSellerInfo;

    /**
     * @var \Embitel\PerpetualLogin\Helper\Data
     */
    protected $perpetualHelper;

    /**
     * @var
     */
    protected $logger;

    /**
     * @var
     */
    private $amount;

    /**
     * @var StoreManagerInterface
     */
    private $storeManagerInterface;

    /**
     * @var NdsHelper
     */
    protected $ndsHelper;

    /**
     * @var \Embitel\Sales\Helper\SendEmailSms
     */
    protected $salesHelper;

    /**
     * @var \Razorpay\Magento\Model\QrCode\CurlCalls
     */
    private $qrCodecall;

    /**
     * @var \Razorpay\Magento\Helper\LogfileDetail
     */
    private $qrlogger;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param Session $checkoutSession
     * @param RazorpayPayments $razorpayPayments
     * @param CustomerFactory $customerFactory
     * @param AddressFactory $addressFactory
     * @param Config $Config
     * @param RazorpayHelper $razorpayHelper
     * @param OrderInterfaceFactory $orderFactory
     * @param ScopeConfigInterface $scopeConfigInterface
     * @param CustomSellerInfo $customSellerInfo
     * @param \Embitel\PerpetualLogin\Helper\Data $perpetualHelper
     * @param StoreManagerInterface $storeManagerInterface
     * @param \Embitel\Sales\Helper\SendEmailSms $salesHelper
     * @param NdsHelper $ndsHelper
     * @param \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall
     * @param \Razorpay\Magento\Helper\LogfileDetail $logger
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        RazorpayPayments $razorpayPayments,
        CustomerFactory $customerFactory,
        AddressFactory $addressFactory,
        Config $Config,
        RazorpayHelper $razorpayHelper,
        OrderInterfaceFactory $orderFactory,
        ScopeConfigInterface $scopeConfigInterface,
        CustomSellerInfo $customSellerInfo,
        \Embitel\PerpetualLogin\Helper\Data $perpetualHelper,
        StoreManagerInterface $storeManagerInterface,
        \Embitel\Sales\Helper\SendEmailSms $salesHelper,
        NdsHelper $ndsHelper,
        \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall,
        \Razorpay\Magento\Helper\LogfileDetail $logger
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_razorpayPayments = $razorpayPayments;
        $this->_customerFactory = $customerFactory;
        $this->_addressFactory = $addressFactory;
        $this->_Config = $Config;
        $this->razorpayHelper = $razorpayHelper;
        $this->orderFactory = $orderFactory;
        $this->scopeConfigInterface = $scopeConfigInterface;
        $this->customSellerInfo = $customSellerInfo;
        $this->perpetualHelper = $perpetualHelper;
        $this->storeManagerInterface = $storeManagerInterface;
        $this->ndsHelper = $ndsHelper;
        $this->salesHelper = $salesHelper;
        $this->qrCodecall = $curlCall;
        $this->qrlogger = $logger;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {

        /*Logger*/
        $dirPath = BP . '/var/log/razorpay/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $this->_razorOrderId = "";
        $this->amount = "";

        $sellerId = "";

         /*Razorpay Keys*/
        $this->key_id = $this->_Config->getConfigData(Config::KEY_PUBLIC_KEY);
        $this->key_secret = $this->_Config->getConfigData(Config::KEY_PRIVATE_KEY);
        $paymentData = $this->getRequest()->getParam('paymentdata');

        $paymentMethod = $paymentData['method'];//$this->getRequest()->getParam('paymentMethod');
        $encrypOrderId = $paymentData['encryptedOrderid'];//'MTQ4NF9CTEY=';//$this->getRequest()->getParam('encrypOrderId');
        //$vpa = "123@upi";
        $orderId = $this->perpetualHelper->getDecryptVaue($encrypOrderId);

        $order = $this->orderFactory->create()->load($orderId);
        try {
            $sellerData = $this->getSellerDetails($order->getEntityId());
            if ($sellerData) {
                $sellerId = $sellerData->getSellerId();
                $isNds = $this->ndsHelper->isNdsSeller($sellerId);
                if ($isNds) {
                    $order->setIsNds(1)->save();
                }
            }

            if ($sellerData) {
                if ($order->getCouponCode() != null) {
                    $this->amount = $order->getBaseGrandTotal() * 100;
                } else {
                    $this->amount = $sellerData->getOfferPrice() * 100;
                }
                //$this->amount = $order->getBaseGrandTotal() * 100;//$sellerData->getOfferPrice() * 100;
            }
            $customer_id = $order->getCustomerId();
            $customerLoad = $this->_customerFactory->create()->load($customer_id);
            $billingAddressId = $customerLoad->getDefaultBilling();
            $BillingAddress = $this->_addressFactory->create()->load($billingAddressId);
            $customerTelephone = $this->scopeConfigInterface->getValue("razorpay/razorpay_dummy_fields/cust_mobile", \Magento\Store\Model\ScopeInterface::SCOPE_STORES);

        /*$customerTelephone = '';
        if($BillingAddress->getTelephone()){
            $customerTelephone = $BillingAddress->getTelephone();
        }*/

        //qr code payment
            if ($paymentMethod == 'qr_code') {
                $qrLogger = $this->qrlogger->qrCodeLog();
                $vaCustomerId = $this->scopeConfigInterface->getValue("razorpay/qr_code/customer_id", \Magento\Store\Model\ScopeInterface::SCOPE_STORES);
                if (empty($vaCustomerId)) {
                    $paymentresult['error'] = 'Virtual Account Customer ID is blank and call this api V1/razorpay/qrcode_account';
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($paymentresult);
                        return $result;
                }
                $paymentRequestParam = [
                    "receivers" => ["types" => ["qr_code"]],
                    "description" => "Bharat QR for payment collection",
                    "customer_id" =>$vaCustomerId,
                    "amount_expected" =>  $this->amount,
                    "notes" => ["order_id" => $order->getIncrementId(),
                        "seller_id" => $sellerId]
                ];
                // curl call for virtual payment
                $url = $this->scopeConfigInterface->getValue(
                    "razorpay/qr_code/virtual_account_creation_url",
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORES
                );

                $paymentResponse = $this->qrCodecall->curlCall($paymentRequestParam, $url);
                $qrLogger ->info("=== VA creation start for order Id === ".$order->getIncrementId());
                $qrLogger ->info("=== Request ==".json_encode($paymentRequestParam));
                $qrLogger ->info("== Response==".json_encode($paymentResponse));

                //prepare response
                $paymentresult['increment_id'] = $order->getIncrementId();
                $paymentresult['method'] = $paymentMethod;

                $paymentresult['amount'] = $this->amount;
                // save Razorpaydata
                if (isset($paymentResponse['id']) && $paymentResponse['id']) {

                        $this->_razorpayPayments->setOrderId($order->getId());
                        $this->_razorpayPayments->setRazorpayOrderId($paymentResponse['id']);
                        $this->_razorpayPayments->setRazorpayResponse(json_encode($paymentResponse));
                        $this->_razorpayPayments->setTransactionFlag(0);//0 flag for order payment
                        $this->_razorpayPayments->setOrderIncrementId($order->getIncrementId());
                        $this->_razorpayPayments->setTransactionStatus($paymentResponse['status']);
                        $this->_razorpayPayments->setTransactionType("payment");
                        $this->_razorpayPayments->setTransactionTo("BFL");
                        $this->_razorpayPayments->setPaymentMode($paymentMethod);
                        $this->_razorpayPayments->setAmount($paymentResponse['amount_expected']);
                        $this->_razorpayPayments->setPaymentFlag(1);
                        $this->_razorpayPayments->save();

                        //set response and store qr code in file system start
                         $dirPath = BP . \Razorpay\Magento\Model\QrCode\CurlCalls::QR_CORE_PATH.  $order->getIncrementId() . '/';
                    if (!file_exists($dirPath)) {
                           mkdir($dirPath, 0777, true);
                    }
                        $targetFile =  $dirPath ."qrcode.jpeg";
                        //$current = file_get_contents($paymentResponse['receivers'][0]['short_url']);
                        $current = $this->qrCodecall->getShortUrlData($paymentResponse['receivers'][0]['short_url']);
                        file_put_contents($targetFile, $current);

                         $im = imagecreatefromjpeg($targetFile);
                        // Set the crop image size
                        $im2 = imagecrop($im, ['x' => 20, 'y' => 145, 'width' => 245, 'height' => 350]);
                    if ($im2 !== false) {

                           imagejpeg($im2, $targetFile);
                        ;
                    }
                          imagedestroy($im);

                         //set response and store qr code in file system end

                        $paymentresult['razorpay_order_id'] = $paymentResponse['id'];
                        $mediaBaseUrl =  $this->storeManagerInterface->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                        $paymentresult['qrcode_img_url'] = $mediaBaseUrl . 'qrcode/'. $order->getIncrementId() . '/qrcode.jpeg';

                } else {
                    $paymentresult['error'] = $paymentResponse;

                }
                $result = $this->_resultJsonFactory->create();
                $result->setData($paymentresult);
                return $result;

            } elseif (($paymentMethod == 'upi') || ($paymentMethod == 'intentupi')) {
                $vpa = "";
                if ($paymentMethod == 'upi') {
                    if ($paymentData['vpa'] != null) {
                        $vpa = $paymentData['vpa'];
                    }
                    if ($paymentData['vpa'] != null) {
                        $vpaResponse = $this->razorpayHelper->validateVpa($paymentData['vpa']);
                        $vpaResponse = json_decode($vpaResponse, true);
                        if (isset($vpaResponse['error'])) {
                            $result = $this->_resultJsonFactory->create();
                            $vpaResponse['increment_id'] = $order->getIncrementId();
                            $result->setData($vpaResponse);
                            return $result;
                        } elseif ((isset($vpaResponse['success'])) && ($vpaResponse['success']==false)) {
                            $result = $this->_resultJsonFactory->create();
                            $vpaResponse['increment_id'] = $order->getIncrementId();
                            $vpaResponse['error'] = ["description"=>"Invalid VPA. Please enter a valid Virtual Payment Address"];
                            $result->setData($vpaResponse);
                            return $result;
                        }
                    }
                }
            //$vpa = $paymentData['vpa'];
                $checkOrder = $this->checkRazorpayOrder($order);
                if ($checkOrder) {
                    $retry_count = $checkOrder->getRetryCount();
                    if ($retry_count >= 3) {
                        $data = ["order_id" => $checkOrder->getRazorpayOrderId(),"payment_attempt_error" => true];
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($data);
                        return $result;
                    }
                    $this->_razorOrderId = $checkOrder->getRazorpayOrderId();
                } else {
                    $razorpayOrder = $this->CreateOrder($order);
                    $razorOrderArr = (array)$razorpayOrder;

                    $this->_razorOrderId = $razorpayOrder['id'];
                }
                try {
                    $this->salesHelper->sendEmailSms($order->getId());

                } catch (\Exception $e) {

                }
                $referer = '';
                if (isset($_SERVER['HTTP_REFERER'])) {
                    $referer = $_SERVER['HTTP_REFERER'];
                }

                $baseUrl = $this->storeManagerInterface->getStore()->getBaseUrl();
                $notes = $this->razorpayHelper->getPushFieldsNotes(
                    $order->getEntityId(),
                    $order->getIncrementId(),
                    $order->getDeliveryDate()
                );
                $userAgent = isset($_SERVER['HTTP_USER_AGENT'])?$_SERVER['HTTP_USER_AGENT']:"";
                $paymentData = [
                    "vpa" => $vpa,"amount" => $this->amount,"currency" => "INR",
                    "order_id" => $this->_razorOrderId,"contact" => $customerTelephone,
                    "email" => "abc@abc.in","referer" => $baseUrl,"user_agent" => $userAgent,
                    "ip" =>  $_SERVER['REMOTE_ADDR'],"notes" => $notes
                ];
                if ($paymentMethod == 'intentupi') {
                    unset($paymentData['vpa']);
                    $paymentData['flow'] = 'intent';
                }

                $paymentresult = $this->CreateUpiPayment($paymentData);
                if (isset($paymentresult['razorpay_payment_id'])) {
                    $paymentresult['increment_id'] = $order->getIncrementId();
                    $paymentresult['method'] = $paymentMethod;
                    $paymentresult['razorpay_order_id'] = $this->_razorOrderId;
                    $paymentresult['amount'] = $this->amount;
                    $result = $this->_resultJsonFactory->create();
                        $result->setData($paymentresult);
                        return $result;
                }
            } elseif ($paymentMethod == "card") {
                 $checkOrder = $this->checkRazorpayOrder($order);
                if ($checkOrder) {
                    $retry_count = $checkOrder->getRetryCount();
                    if ($retry_count >= 3) {
                        $data = ["order_id" => $checkOrder->getRazorpayOrderId(),"payment_attempt_error" => true];
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($data);
                        return $result;
                    }
                    $this->_razorOrderId = $checkOrder->getRazorpayOrderId();
                } else {
                    $razorpayOrder = $this->CreateOrder($order);
                    $razorOrderArr = (array)$razorpayOrder;

                    $this->_razorOrderId = $razorpayOrder['id'];
                }
                try {
                    $this->salesHelper->sendEmailSms($order->getId());

                } catch (\Exception $e) {

                }
                $notes = $this->razorpayHelper->getPushFieldsNotes(
                    $order->getEntityId(),
                    $order->getIncrementId(),
                    $order->getDeliveryDate()
                );
                $data = [
                "amount"            => $this->amount,
                'method'            => $paymentMethod,
                'email'             => 'abc@abc.in',//$customer['email'],
                'contact'           => $customerTelephone,
                "notes"             => $notes,
                "order_id"          => $this->_razorOrderId,
                "increment_id"          => $order->getIncrementId()
                ];
                $result = $this->_resultJsonFactory->create();
                $result->setData($data);
                return $result;

            }
        } catch (\Exception $e) {

            $data = [
                "order_id" => '',"error" => 'error in payment processing',
                "increment_id" => $order->getIncrementId()
            ];
            $result = $this->_resultJsonFactory->create();
            $result->setData($data);
            return $result;
        }
    }

    /**
     *
     * @param $order
     * @return void
     */
    public function CreateOrder($order = null)
    {
        if ($order != null) {
            $notes = $this->razorpayHelper->getPushFieldsNotes(
                $order->getEntityId(),
                $order->getIncrementId(),
                $order->getDeliveryDate()
            );
            $api = new Api($this->key_id, $this->key_secret);
            $ramdom_number = rand(10, 100);
            //$razorpayPaybleAmt = 10000;
            $orderData = [
                'receipt'         => $order->getEntityId().$ramdom_number,
                'amount'          => $this->amount,
                'currency'        => 'INR',
                'payment_capture' => 1,
                'notes'           => $notes
            ];

            return $api->order->create($orderData);
        }
    }

    /**
     *
     * @param $order
     * @return false|\Magento\Framework\DataObject|void
     */
    public function checkRazorpayOrder($order = null)
    {
        if ($order != null) {
            $razorpayData = $this->_razorpayPayments->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()])
                ->addFieldToFilter('transaction_type', ['eq' => "payment"]);
            if ($razorpayData->count() > 0) {
                return $razorpayData->getFirstItem();
            }
            return false;
        }
    }

    /**
     *
     * @param $paymentData
     * @return mixed|void
     */
    public function CreateUpiPayment($paymentData = null)
    {
        if ($paymentData != null) {

            $response = $this->razorpayHelper->createUpiPayment($paymentData);

            return json_decode($response, true);
        }
    }

    /**
     *
     * @param $order_id
     * @return false|\Magento\Framework\DataObject
     */
    public function getSellerDetails($order_id = null)
    {
        if ($order_id != null) {
            $sellerinfo = $this->customSellerInfo->getCollection()->addFieldToFilter('order_id', ['eq' => $order_id]);
            if ($sellerinfo->count() > 0) {
                return $sellerinfo->getFirstItem();
            }
        }
        return false;
    }

    /**
     *
     * @return false|int
     */
    function isMobile()
    {
        return preg_match(
            "/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i",
            $_SERVER["HTTP_USER_AGENT"]
        );
    }
}
