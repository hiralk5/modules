<?php
/**
 * @Module         : Razorpay Payment
 * @Package        : Razorpay_Magento
 * @Description    : Will check whether razorpay payment successfull or not and redirect user accordingly
 * @Developer      : Shaunak Datar <shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */
namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";

use Razorpay\Api\Api;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultFactory;
use Razorpay\Magento\Model\RazorpayPaymentsFactory;
use Embitel\SellerModule\Model\CustomSellerInfoFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\Order as Order;
use Razorpay\Magento\Model\Config;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Embitel\SellerModule\Model\CustomSellerInfo;
use Razorpay\Magento\Helper\Data as MediaaigilityHelper;
use Razorpay\Magento\Model\OnlineOrderPush;
use Razorpay\Magento\Model\DealerRazorpayRule;
use Razorpay\Magento\Helper\RazorpayHelper;

class VerifyPaymentMethod extends \Magento\Framework\App\Action\Action
{

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_pageFactory;

    /**
     * @var Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var Magento\Framework\UrlInterface
     */
    private $url;

    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Magento\Framework\Controller\ResultFactory
     */
    protected $resultFactory;

    /**
     * @var RazorpayPaymentsFactory
     */
    private $razorpayPaymentsFactory;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $_order;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_Config;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_orderInterfaceFactory;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $customSellerInfo;

    /**
     * @var Razorpay\Magento\Model\OnlineOrderPush
     */
    protected $onlineOrderPush;

    /**
     * @var Razorpay\Magento\Model\DealerRazorpayRule
     */
    protected $dealerRazorpayRule;

    /**
     * @var Razorpay\Magento\Helper\RazorpayHelper
     */
    protected $RazorpayHelper;

    /**
     * @var CustomSellerInfoFactory
     */
    private $customSellerInfoFactory;

    /**
     * @var MediaaigilityHelper
     */
    private $mediaaigilityHelper;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param CustomerSession $customerSession
     * @param UrlInterface $url
     * @param JsonFactory $resultJsonFactory
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param ResultFactory $resultFactory
     * @param CheckoutSession $checkoutSession
     * @param RazorpayPaymentsFactory $razorpayPaymentsFactory
     * @param Order $order
     * @param Config $Config
     * @param OrderInterfaceFactory $orderInterfaceFactory
     * @param CustomSellerInfo $customSellerInfo
     * @param MediaaigilityHelper $mediaaigilityHelper
     * @param OnlineOrderPush $onlineOrderPush
     * @param DealerRazorpayRule $dealerRazorpayRule
     * @param RazorpayHelper $RazorpayHelper
     * @param CustomSellerInfoFactory $customSellerInfoFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CustomerSession $customerSession,
        UrlInterface $url,
        JsonFactory $resultJsonFactory,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        ResultFactory $resultFactory,
        CheckoutSession $checkoutSession,
        RazorpayPaymentsFactory $razorpayPaymentsFactory,
        Order $order,
        Config $Config,
        OrderInterfaceFactory $orderInterfaceFactory,
        CustomSellerInfo $customSellerInfo,
        MediaaigilityHelper $mediaaigilityHelper,
        OnlineOrderPush $onlineOrderPush,
        DealerRazorpayRule $dealerRazorpayRule,
        RazorpayHelper $RazorpayHelper,
        CustomSellerInfoFactory $customSellerInfoFactory
    ) {
        $this->_pageFactory = $pageFactory;
        $this->customerSession = $customerSession;
        $this->url = $url;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->resultFactory = $resultFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->razorpayPaymentsFactory = $razorpayPaymentsFactory;
        $this->_order = $order;
        $this->_Config = $Config;
        $this->_orderInterfaceFactory = $orderInterfaceFactory;
        $this->customSellerInfo = $customSellerInfo;
        $this->mediaaigilityHelper = $mediaaigilityHelper;
        $this->onlineOrderPush = $onlineOrderPush;
        $this->dealerRazorpayRule = $dealerRazorpayRule;
        $this->RazorpayHelper = $RazorpayHelper;
        $this->customSellerInfoFactory = $customSellerInfoFactory;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        /*Adding logger*/
        /*Maintaining Logger*/
        $dirPath = BP . '/var/log/razorpay/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }


        /*Fetching razorpay keys from config*/
        $key_id = $this->_Config->getConfigData(Config::KEY_PUBLIC_KEY);
        $key_secret = $this->_Config->getConfigData(Config::KEY_PRIVATE_KEY);

        $dealId = null;
        $sellerid = ($this->getRequest()->getParam('sellerid') != null) ? $this->getRequest()->getParam('sellerid') : null;

        $result = $this->resultJsonFactory->create();

        $RazorResponse = [
            'Status' => '','Error' => '',
            'Message' => '','OrderStatus' =>'',
            'PaymentMode' =>'','DisplayErrMsg' => ''
        ];


        $order_increment_id = $this->getRequest()->getParam('orderIncrementid');

        /*get order data from session*/
        $orderSessionData = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
        //$this->_checkoutSession->getLastRealOrder();

        /*Define razorpay api object*/
        $api = new Api($key_id, $key_secret);
        $secret = $api->getSecret();

        /*Declaring transaction variables*/
        $order_amount = '';
        $razorpay_response = '';
        $transaction_status = '';
        $payment_attempts = 1;
        $payment_flag = 0;
        $offer_price = 0;

        $customSellerInfoData = $this->customSellerInfo->getCollection()
            ->addFieldToFilter('order_id', ['eq' => $orderSessionData->getEntityId()]);
        if ($customSellerInfoData->count() > 0) {
            $customSellerInfoData = $customSellerInfoData->getFirstItem();
            $offer_price = $customSellerInfoData->getOfferPrice();
            $offer_price = $offer_price * 100;
        }

        $razorpayorderId = ($this->getRequest()->getParam('razorpay_order_id') != null) ? $this->getRequest()->getParam('razorpay_order_id') : null;
        $razorpay_payment_mode = ($this->getRequest()->getParam('razorpay_order_method') != null) ? $this->getRequest()->getParam('razorpay_order_method') : null;

        try {

            /*checking if got success response*/
            if ($this->getRequest()->getParam('razorpay_order_id') != null) {
                $razorpayData = $this->razorpayPaymentsFactory->create()->getCollection()
                    ->addFieldToFilter('razorpay_order_id', ['eq' => $razorpayorderId])
                    ->addFieldToFilter('transaction_status', ['eq' => "success"]);
                if ($razorpayData->count() > 0) {
                    $RazorResponse['PaymentMode'] = __('CCDC');
                    if ($razorpay_payment_mode == 'upi') {
                        $RazorResponse['PaymentMode'] = __('UPI');
                    }
                    $RazorResponse['Status'] = __('Success');
                    $RazorResponse['Message'] = __('Your Payment is successful');
                    $result->setData($RazorResponse);
                    return $result;
                }
            }

            if (($this->getRequest()->getParam('razorpay_payment_id') !== null &&
                    !empty($this->getRequest()->getParam('razorpay_payment_id'))) &&
                ($this->getRequest()->getParam('razorpay_signature') !== null &&
                    !empty($this->getRequest()->getParam('razorpay_signature')))) {

                /*Maintaining Logs*/

                $arguments = [
                    'razorpay_payment_id' => $this->getRequest()->getParam('razorpay_payment_id'),
                    'razorpay_signature' => $this->getRequest()->getParam('razorpay_signature'),
                    'razorpay_order_id' => $this->getRequest()->getParam('razorpay_order_id')];

                $order_amount = $this->getRequest()->getParam('razorpay_order_amount');
                /*razorpay_signature verification*/
                $payload = $this->getRequest()->getParam('razorpay_order_id') . '|' . $this->getRequest()->getParam('razorpay_payment_id');
                $expectedSignature = hash_hmac('sha256', $payload, $secret);

                $hashresult = $this->hashEquals(
                    $expectedSignature,
                    $this->getRequest()->getParam('razorpay_signature')
                );

                if ($hashresult == 1) {
                    $transaction_status = "success";
                    $razorpay_response = json_encode($arguments);

                    /*Signature Verified*/
                    /*Saving Data to Razorpay*/

                    /*changing order payment method*/
                    $RazorResponse['PaymentMode'] = __('CCDC');
                    $RazorResponse['Status'] = __('Success');
                    $RazorResponse['Message'] = __('Your Payment is successful');
                } else {
                    /*Signature Not verified*/
                    $RazorResponse['Status'] = __('Fail');
                    $RazorResponse['Message'] = __('Payment Failed');
                    $RazorResponse['Error'] = __('Payment Signature Mismatch');
                }

            } elseif (($this->getRequest()->getParam('razorpay_payment_id') !== null &&
                    !empty($this->getRequest()->getParam('razorpay_payment_id'))) && $razorpay_payment_mode == "upi") {

               /*Maintaining Logs*/

                $arguments = [
                    'razorpay_payment_id' => $this->getRequest()->getParam('razorpay_payment_id'),
                    'razorpay_order_id' => $this->getRequest()->getParam('razorpay_order_id')];

                $order_amount = $this->getRequest()->getParam('razorpay_order_amount');
                $transaction_status = "success";
                $razorpay_response = json_encode($arguments);
                $RazorResponse['PaymentMode'] = __('UPI');
                $RazorResponse['Status'] = __('Success');
                $RazorResponse['Message'] = __('Your Payment is successful');

            } elseif (($this->getRequest()->getParam('razorpay_payment_id') !== null &&
                    !empty($this->getRequest()->getParam('razorpay_payment_id'))) &&
                $razorpay_payment_mode == "intentupi") {

               /*Maintaining Logs*/

                $arguments = [
                    'razorpay_payment_id' => $this->getRequest()->getParam('razorpay_payment_id'),
                    'razorpay_order_id' => $this->getRequest()->getParam('razorpay_order_id')];

                $order_amount = $this->getRequest()->getParam('razorpay_order_amount');
                $transaction_status = "success";
                $razorpay_response = json_encode($arguments);
                $RazorResponse['PaymentMode'] = __('INTENTUPI');
                $RazorResponse['Status'] = __('Success');
                $RazorResponse['Message'] = __('Your Payment is successful');

            } else {
                /*If we got Error*/

                $response = $this->getRequest()->getparams();

                $razorpay_response = $response['razorpay_error'];
                $transaction_status = "fail";

                $order_amount = $this->getRequest()->getParam('razorpay_order_amount');
                //$razorpayCollection = $this->razorpayPaymentsFactory->create()->getCollection()
                //->addFieldToFilter('order_id',['eq' => $orderSessionData->getEntityId()])
                //->addFieldToFilter('transaction_status',['eq' => "success"]);
                $razorpayCollection = $this->razorpayPaymentsFactory->create()->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $orderSessionData->getEntityId()])
                    ->addFieldToFilter('transaction_status', ['eq' => "fail"]);
                if ($razorpayCollection->count() > 0) {
                    $razorpayId = $razorpayCollection->getFirstItem()->getId();
                    $payment_attempts = $razorpayCollection->getFirstItem()->getRetryCount() + 1;
                    $razorpay_response = $razorpay_response.$razorpayCollection->getFirstItem()->getRazorpayResponse();
                    $model = $this->razorpayPaymentsFactory->create()->load($razorpayId);
                }


                $RazorResponse['Status'] = __('Fail');
                $RazorResponse['Message'] = __('Payment Failed');
                $err = json_decode($response['razorpay_error'], true);
                $RazorResponse['Error'] = __($err['error']['description']);
               // if(isset($err['error']['description'])){
                 $RazorResponse['DisplayErrMsg'] = __(
                     $this->RazorpayHelper->dispositionType($err['error']['description'])
                 );
               // }
                $result->setData($RazorResponse);
                return $result;
            }

        //Checking FP Condition
            if ($offer_price != 0 && $offer_price == $order_amount) {
                $payment_flag = 1;
            }
        /*Signature Verified*/
                /*Saving Data to Razorpay*/
                $model = $this->_razorpayPaymentsFactory->create();
                $model->setOrderId($orderSessionData->getEntityId());
                $model->setRazorpayOrderId($razorpayorderId);
                $model->setRazorpayResponse($razorpay_response);
                $model->setTransactionFlag(0);//0 flag for order payment
                $model->setOrderIncrementId($orderSessionData->getIncrementId());
                $model->setTransactionStatus($transaction_status);
                $model->setTransactionType("payment");
                $model->setTransactionTo("BFL");
                $model->setPaymentMode($razorpay_payment_mode);
                $model->setAmount($order_amount);
                $model->setRetryCount($payment_attempts);
                $model->setPaymentFlag($payment_flag);
                $model->save();

            if ($transaction_status == "success") {
                $razorpayData = $this->razorpayDealer($sellerid);
                if ($razorpayData) {

                    $sellerInfoCollection = $this->customSellerInfoFactory->create()
                        ->getCollection()->addFieldToFilter('order_id', ['eq' => $orderSessionData->getEntityId()]);
                    if ($sellerInfoCollection->count() > 0) {
                        $dealId = $sellerInfoCollection->getFirstItem()->getDealId();
                    }
                    if ($dealId != null) {
                        $order_amount_rupees = $order_amount / 100;
                        $deduction_percent = $razorpayData->getDefaultPercentage();
                        $deduction_amount = $deduction_percent * $order_amount_rupees;
                        $deduction_amount = $deduction_amount / 100;
                        $deduction_amount = $order_amount_rupees - $deduction_amount;
                        $deduction_amount = round($deduction_amount);
                        $order_amount_rupees = round($order_amount_rupees);
                        $razorpay_odm_request = [
                            "DealId" => $dealId,
                            "OrderId" => $orderSessionData->getIncrementId(),
                            "RZPPaidOnline" => "Y",
                            "Event" => "Confirm",
                            "RZPDisbOnlineAmt" => $order_amount_rupees,"RZPDeduction" => $deduction_amount,
                            "RZPOrderID" => $razorpayorderId];

                        //add data to online_order_push table
                        $this->onlineOrderPush->setOrderId($orderSessionData->getIncrementId());
                        $this->onlineOrderPush->setRazorpayOrderId($razorpayorderId);
                        $this->onlineOrderPush->setRequestParams(json_encode($razorpay_odm_request));
                        $this->onlineOrderPush->save();
                    }

                }

                //Updating Payment Method
                $orderData = $this->_order->load($orderSessionData->getEntityId());
                $orderData->getPayment()->setData('method', 'razorpay')->save();

                //Updating Payment Method in Admin Sales Order Grid
                $orderFactory = $this->_orderInterfaceFactory->create()->loadByIncrementId($order_increment_id);
                $orderFactory->setPaymentMethod("razorpay");
                $orderFactory->setStatus("order_placed");
                $orderFactory->save();

                //order push to media agility
                if ($payment_flag) { // if it is full payment
                    $this->mediaaigilityHelper->orderPushReqBody($orderData);
                }
            }

            $result->setData($RazorResponse);
            return $result;
        } catch (\Exception $e) {
            /*If some exception occurs*/
            $RazorResponse['Status'] = __('Fail');
            $RazorResponse['Message'] = __('Payment Failed');
            $RazorResponse['Error'] = __($e->getMessage());

            $exception_params = [];
            $exception_params['order_id'] = $orderSessionData->getEntityId();
            $exception_params['razorpay_response'] = $orderSessionData->getEntityId();
            $exception_params['order_increment_id'] = $orderSessionData->getIncrementId();
            $exception_params['transaction_flag'] = 0;
            $exception_params['razorpay_response'] = json_encode(['error' => $e->getMessage()]);
            $this->RazorpayHelper->RazorpayExceptions($exception_params);
            $result->setData($RazorResponse);
            return $result;
        }
    }

    /**
     *
     * @param $dealerId
     * @return false|\Magento\Framework\DataObject|void
     */
    public function razorpayDealer($dealerId = null)
    {
        if ($dealerId != null) {
            $razorpayDealerData = $this->dealerRazorpayRule->getCollection()
                ->addFieldToFilter("dealer_id", ['eq' => $dealerId])->addFieldToFilter("status", ['eq' => 1]);
            if ($razorpayDealerData->count() > 0) {
                return $razorpayDealerData->getFirstItem();
            }
            return false;
        }
    }

    /**
     * Below function verify that payment signature which we get from razorpay is corrent or not
     */
    private function hashEquals($expectedSignature, $actualSignature)
    {
        if (strlen($expectedSignature) === strlen($actualSignature)) {
            $res = $expectedSignature ^ $actualSignature;
            $return = 0;
            for ($i = strlen($res) - 1; $i >= 0; $i--) {
                $return |= ord($res[$i]);
            }
            return ($return === 0);
        }
        return false;
    }
}
