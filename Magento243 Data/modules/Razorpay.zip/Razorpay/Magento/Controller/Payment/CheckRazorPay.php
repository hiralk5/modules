<?php
/**
 * @Package        : Razorpay_Magento
 * @Description    : create razorpay order
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */

namespace Razorpay\Magento\Controller\Payment;

require_once __DIR__ . "../../../../Razorpay/Razorpay.php";
use Razorpay\Api\Api;

use Magento\Checkout\Model\Session;
use Magento\Customer\Model\Session as CustomerSession;
use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\AddressFactory;
use Razorpay\Magento\Model\Config;
use Magento\Sales\Api\Data\OrderInterfaceFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Razorpay\Magento\Helper\RazorpayHelper;
use Embitel\SellerModule\Model\CustomSellerInfo;

class CheckRazorPay extends \Magento\Framework\App\Action\Action
{

        /**
         * @var Razorpay Order Id
         */
        protected $_razorOrderId;

        /**
         * @var \Magento\Framework\Controller\Result\JsonFactory
         */
        protected $_resultJsonFactory;

        /**
         * @var \Magento\Checkout\Model\Session
         */
        protected $_checkoutSession;

        /**
         * @var Magento\Customer\Model\Session
         */
        protected $_customerSession;

        /**
         * @var Razorpay\Magento\Model\RazorpayPayments
         */
        protected $_razorpayPayments;

        /**
         * @var Magento\Customer\Model\CustomerFactory
         */
        protected $_customerFactory;

        /**
         * @var Magento\Customer\Model\AddressFactory
         */
        protected $_addressFactory;

        /**
         * @var Magento\Framework\App\Config\ScopeConfigInterface
         */
        protected $_config;

        /**
         * @var Magento\Sales\Api\Data\OrderInterfaceFactory
         */
        protected $orderFactory;

        /**
         * @var Magento\Framework\App\Config\ScopeConfigInterface
         */
        protected $scopeConfigInterface;

        /**
         * @var Magento\Framework\App\Config\ScopeConfigInterface
         */
        protected $razorpayHelper;

        /**
         * @var Embitel\SellerModule\Model\CustomSellerInfo
         */
        protected $customSellerInfo;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param Session $checkoutSession
     * @param CustomerSession $customerSession
     * @param RazorpayPayments $razorpayPayments
     * @param CustomerFactory $customerFactory
     * @param AddressFactory $addressFactory
     * @param Config $config
     * @param OrderInterfaceFactory $orderFactory
     * @param ScopeConfigInterface $scopeConfigInterface
     * @param RazorpayHelper $razorpayHelper
     * @param CustomSellerInfo $customSellerInfo
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        Session $checkoutSession,
        CustomerSession $customerSession,
        RazorpayPayments $razorpayPayments,
        CustomerFactory $customerFactory,
        AddressFactory $addressFactory,
        Config $config,
        OrderInterfaceFactory $orderFactory,
        ScopeConfigInterface $scopeConfigInterface,
        RazorpayHelper $razorpayHelper,
        CustomSellerInfo $customSellerInfo
    ) {
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_customerSession = $customerSession;
        $this->_razorpayPayments = $razorpayPayments;
        $this->_customerFactory = $customerFactory;
        $this->_addressFactory = $addressFactory;
        $this->_config = $config;
        $this->orderFactory = $orderFactory;
        $this->scopeConfigInterface = $scopeConfigInterface;
        $this->razorpayHelper = $razorpayHelper;
        $this->customSellerInfo = $customSellerInfo;
        return parent::__construct($context);
    }

    public function execute()
    {
            /*Fetching Razorpay Keys*/
            $key_id = $this->_config->getConfigData(Config::KEY_PUBLIC_KEY);
            $key_secret = $this->_config->getConfigData(Config::KEY_PRIVATE_KEY);

               /*Default Customer Name, Email Or Mobile*/
            $customerName =  "Test123";
            $customerEmail = "test123@gmail.com";
            $customerTelephone = "9898989898";

            $customerName = $this->scopeConfigInterface->getValue(
                "razorpay/razorpay_dummy_fields/cust_full_name",
                \Magento\Store\Model\ScopeInterface::SCOPE_STORES
            );
            $customerEmail = $this->scopeConfigInterface->getValue(
                "razorpay/razorpay_dummy_fields/cust_email",
                \Magento\Store\Model\ScopeInterface::SCOPE_STORES
            );
            $customerTelephone = $this->scopeConfigInterface->getValue(
                "razorpay/razorpay_dummy_fields/cust_mobile",
                \Magento\Store\Model\ScopeInterface::SCOPE_STORES
            );

        try {

            $incrementId = $this->getRequest()->getParam('incrementid');
            $razorpayPaybleAmt = $this->getRequest()->getParam('razorpayPaybleAmt');
            $sellerid = $this->getRequest()->getParam('sellerid');
            $isFPDealer = $this->razorpayHelper->checkFPDealer($sellerid);
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORES;
            $isEnabledFP = $this->scopeConfigInterface->getValue(
                "razorpay/razorpay_fp_config/enabled_razorpay_fp",
                $storeScope
            );
            $dealId = "";
            $offerprice = "";
            $order = $this->orderFactory->create()->loadByIncrementId($incrementId);//$this->_checkoutSession->getLastRealOrder();

            /*Getting order details from session*/
            /*Checking if FP is enabled */
            if ($order->getEntityId()) {


                $customSellerInfoData = $this->customSellerInfo->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()]);
                if ($customSellerInfoData->count() > 0) {
                    $customSellerInfoData = $customSellerInfoData->getFirstItem();
                    $dealId = $customSellerInfoData->getDealId();
                    $offerprice = $customSellerInfoData->getOfferPrice();
                }
                if ($isEnabledFP == 1 && $isFPDealer == 1 && $dealId == null) {
                    $razorpayPaybleAmt = $offerprice * 100;
                } else {
                    $razorpayPaybleAmt = $razorpayPaybleAmt * 100;
                }
                /*Converting Payble amount in paisa format for razorpay*/

               /* $customer = array("name" => $this->_customerSession->getCustomer()->getFirstname()." ".$this->_customerSession->getCustomer()->getLastname(),"email" => $this->_customerSession->getCustomer()->getEmail());
                $customerLoad = $this->_customerFactory->create()->load($this->_customerSession->getCustomer()->getEntityId());
                $billingAddressId = $customerLoad->getDefaultBilling();
                $BillingAddress = $this->_addressFactory->create()->load($billingAddressId);
                $customerTelephone = '';
                if($BillingAddress->getTelephone()){
                    $customerTelephone = $BillingAddress->getTelephone();
                }*/

                $notes = $this->razorpayHelper->getPushFieldsNotes(
                    $order->getEntityId(),
                    $incrementId,
                    $order->getDeliveryDate()
                );
                $customer = ["name" => $customerName,"email" => $customerEmail];
                $api = new Api($key_id, $key_secret);
                $ramdom_number = rand(10, 100);
                $orderData = [
                'receipt'         => $order->getEntityId().$ramdom_number,
                'amount'          => $razorpayPaybleAmt,
                'currency'        => 'INR',
                'payment_capture' => 1,
                'notes'           => $notes
                ];


                $razorpayData = $this->_razorpayPayments->getCollection()
                    ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()])
                    ->addFieldToFilter('transaction_type', ['eq' => "payment"]);
                $this->_razorOrderId = "";
                if ($razorpayData->count() > 0) {
                    $retry_count = $razorpayData->getFirstItem()->getRetryCount();
                    if ($retry_count >= 3) {
                        $data = [
                            "order_id" => $razorpayData->getFirstItem()->getRazorpayOrderId(),
                            "payment_attempt_error" => true
                        ];
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($data);
                        return $result;
                    }
                    $this->_razorOrderId = $razorpayData->getFirstItem()->getRazorpayOrderId();
                } else {
                    $razorpayOrder = $api->order->create($orderData);
                    $razorOrderArr = (array)$razorpayOrder;

                    $this->_razorOrderId = $razorpayOrder['id'];
                }

                $data = [
                "amount"            => $razorpayPaybleAmt,
                'email'             => $customerEmail,//$customer['email'],
                'contact'           => $customerTelephone,
                "notes"             => $notes,
                "order_id"          => $this->_razorOrderId
                ];

            } else {
                $data = ["order_id" => '',"error" => 'error in payment processing'];
            }

            $result = $this->_resultJsonFactory->create();
            $result->setData($data);
            return $result;
        } catch (\Exception $e) {
            $data = ["order_id" => '',"error" => 'error in payment processing'];
            $result = $this->_resultJsonFactory->create();
            $result->setData($data);
            return $result;
        }
    }
}
