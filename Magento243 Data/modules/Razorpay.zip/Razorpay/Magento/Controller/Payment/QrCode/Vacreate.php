<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of vacreate
 *
 * @author emb-bratdol
 */
namespace Razorpay\Magento\Controller\Payment\QrCode;

class Vacreate extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Razorpay\Magento\Model\QrCode\CurlCalls
     */
    private $qrCodecall;

    /**
     * @var \Razorpay\Magento\Helper\LogfileDetail
     */
    private $qrlogger;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManagerInterface;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $_resultJsonFactory;

    /**
     * @var \Razorpay\Magento\Model\RazorpayPayments
     */
    private $_razorpayPayments;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfigInterface;

    /**
     * @var \Magento\Sales\Model\Order
     */
    private $orderModel;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall
     * @param \Magento\Sales\Model\Order $orderModel
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Razorpay\Magento\Model\RazorpayPayments $razorpayPayment
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeInterFace
     * @param \Razorpay\Magento\Helper\LogfileDetail $logger
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall,
        \Magento\Sales\Model\Order $orderModel,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Razorpay\Magento\Model\RazorpayPayments $razorpayPayment,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Store\Model\StoreManagerInterface $storeInterFace,
        \Razorpay\Magento\Helper\LogfileDetail $logger
    ) {
         $this->qrCodecall = $curlCall;
         $this->orderModel = $orderModel;
         $this->scopeConfigInterface = $scopeConfig;
         $this->_razorpayPayments = $razorpayPayment;
         $this->_resultJsonFactory = $resultJsonFactory;
         $this->storeManagerInterface = $storeInterFace;
         $this->qrlogger = $logger;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
         $logger = $this->qrlogger->qrCodeLog();
         $incrementId = $this->getRequest()->getParam('incrementid');

        $razorpayPaybleAmt = $this->getRequest()->getParam('razorpayPaybleAmt');
         $paymentresult['status'] = false;
        try {
            if ($incrementId && $incrementId > 0 && $razorpayPaybleAmt && intval($razorpayPaybleAmt) > 0) {
                    $paymentMethod = 'qr_code';
                    $razorpayPaybleAmt = $razorpayPaybleAmt * 100;

                    $order = $this->orderModel->loadByIncrementId($incrementId);
                    $vaCustomerId = $this->scopeConfigInterface->getValue(
                        "razorpay/qr_code/customer_id",
                        \Magento\Store\Model\ScopeInterface::SCOPE_STORES
                    );
                if (empty($vaCustomerId)) {
                    $paymentresult['error'] = 'Virtual Account Customer ID is blank and call this api V1/razorpay/qrcode_account';
                        $result = $this->_resultJsonFactory->create();
                        $result->setData($paymentresult);
                        return $result;
                }

                     // actual virtual account creation start

                            $paymentRequestParam = [
                                "receivers" => ["types" => ["qr_code"]],
                                "description" => "Bharat QR for payment collection",
                                "customer_id" => $vaCustomerId,
                                "amount_expected" =>  $razorpayPaybleAmt,
                                "notes" => ["order_id" => $incrementId
                                   ]
                            ];
                            // curl call for virtual payment
                            $url = $this->scopeConfigInterface->getValue(
                                "razorpay/qr_code/virtual_account_creation_url",
                                \Magento\Store\Model\ScopeInterface::SCOPE_STORES
                            );

                            $paymentResponse = $this->qrCodecall->curlCall($paymentRequestParam, $url);
                            $logger ->info("=== VA creation start for order Id === ".$order->getIncrementId());
                            $logger ->info("=== Request ==".json_encode($paymentRequestParam));
                            $logger ->info("== Response==".json_encode($paymentResponse));

                            //prepare response
                            $paymentresult['increment_id'] = $order->getIncrementId();

                            $paymentresult['amount'] =$razorpayPaybleAmt;
                             $paymentresult['status'] = true;
                            // save Razorpaydata
                if (isset($paymentResponse['id']) && $paymentResponse['id']) {

                    // if va created for previous try then delete
                    $paymentModel = $this->_razorpayPayments->getCollection()
                        ->addFieldToFilter('order_increment_id', $order->getIncrementId())
                            ->addFieldToFilter('transaction_type', 'payment')
                            ->addFieldToFilter('payment_mode', $paymentMethod)->getFirstItem();
                    if ($paymentModel && $paymentModel->getId() > 0) {
                        $paymentModel->delete();
                    }
                        $this->_razorpayPayments->setOrderId($order->getId());
                        $this->_razorpayPayments->setRazorpayOrderId($paymentResponse['id']);
                        $this->_razorpayPayments->setRazorpayResponse(json_encode($paymentResponse));
                        $this->_razorpayPayments->setTransactionFlag(0);//0 flag for order payment
                        $this->_razorpayPayments->setOrderIncrementId($order->getIncrementId());
                        $this->_razorpayPayments->setTransactionStatus($paymentResponse['status']);
                        $this->_razorpayPayments->setTransactionType("payment");
                        $this->_razorpayPayments->setTransactionTo("BFL");
                        $this->_razorpayPayments->setPaymentMode($paymentMethod);
                        $this->_razorpayPayments->setAmount($paymentResponse['amount_expected']);
                        $this->_razorpayPayments->setPaymentFlag(1);
                        $this->_razorpayPayments->save();

                        //set response and store qr code in file system start
                         $dirPath = BP . \Razorpay\Magento\Model\QrCode\CurlCalls::QR_CORE_PATH.  $order->getIncrementId() . '/';
                    if (!file_exists($dirPath)) {
                           mkdir($dirPath, 0777, true);
                    }
                        $targetFile =  $dirPath ."qrcode.jpeg";
                        //$current = file_get_contents($paymentResponse['receivers'][0]['short_url']);
                         $current = $this->qrCodecall->getShortUrlData($paymentResponse['receivers'][0]['short_url']);
                        file_put_contents($targetFile, $current);

                         $im = imagecreatefromjpeg($targetFile);
                        // Set the crop image size
                        $im2 = imagecrop($im, ['x' => 20, 'y' => 145, 'width' => 245, 'height' => 350]);
                    if ($im2 !== false) {

                           imagejpeg($im2, $targetFile);
                        ;
                    }
                          imagedestroy($im);

                         //set response and store qr code in file system end

                        $paymentresult['razorpay_order_id'] = $paymentResponse['id'];
                        $mediaBaseUrl =  $this->storeManagerInterface->getStore()
                            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
                        $paymentresult['qrcode_img_url'] = $mediaBaseUrl . 'qrcode/'. $order->getIncrementId() . '/qrcode.jpeg';

                } else {
                        $paymentresult['error'] = $paymentResponse;

                }
            }
            $result = $this->_resultJsonFactory->create();
            $result->setData($paymentresult);
            return $result;
        } catch (\Exception $e) {
            $paymentresult['error'] = $e->getMessage();
            $result = $this->_resultJsonFactory->create();
             $result->setData($paymentresult);
              return $result;
        }
    }
}
