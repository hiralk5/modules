<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CheckStatus
 *
 * @author emb-bratdol
 */

namespace Razorpay\Magento\Controller\Payment\QrCode;

class CheckStatus extends \Magento\Framework\App\Action\Action
{

    /**
     * @var \Razorpay\Magento\Helper\LogfileDetail
     */
    private $logger;

    /**
     * @var \Razorpay\Magento\Model\RazorpayPayments
     */
    private $razorpayPayment;

    /**
     * @var \Magento\Sales\Api\Data\OrderInterfaceFactory
     */
    private $_orderInterfaceFactory;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $_resultJsonFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var \Razorpay\Magento\Model\QrCode\CurlCalls
     */
    private $qrCodecall;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Magento\Sales\Api\Data\OrderInterfaceFactory $orderCategoryFactor
     * @param \Razorpay\Magento\Model\RazorpayPayments $razorpayPayment
     * @param \Razorpay\Magento\Helper\LogfileDetail $logger
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Razorpay\Magento\Model\QrCode\CurlCalls $curlCall,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Sales\Api\Data\OrderInterfaceFactory $orderCategoryFactor,
        \Razorpay\Magento\Model\RazorpayPayments $razorpayPayment,
        \Razorpay\Magento\Helper\LogfileDetail $logger
    ) {
        $this->qrCodecall = $curlCall;
        $this->scopeConfig = $scopeConfig;
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_orderInterfaceFactory = $orderCategoryFactor;
        $this->razorpayPayment = $razorpayPayment;
        $this->logger = $logger;
        return parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function execute()
    {
        $response = ['close_popup' => false];
        $closeStatus = false;
        $logger = $this->logger->qrCodeLog();
        try {

            $vitualAccrountId = $this->getRequest()->getParam('razorpay_order_id');
            $orderId = $this->getRequest()->getParam('increment_order_id');
            $customerClose = $this->getRequest()->getParam('customer_close');
//            $vitualAccrountId = 'va_FHz7UMf38ZE1zy';
//            $orderId = 1000006473;
            if ($vitualAccrountId && !empty($vitualAccrountId)) {
                $url = $this->scopeConfig->getValue(
                    "razorpay/qr_code/virtual_account_creation_url",
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORES
                );
                $url = $url . "/" . $vitualAccrountId;

                // customer requested close and close it thourgh put patches
                if ($customerClose) {
                     $this->qrCodecall->closePopup($url);
                      $closeStatus = true;
                      // remove media file
                      $dirPath = BP . \Razorpay\Magento\Model\QrCode\CurlCalls::QR_CORE_PATH.  $orderId . '/';
                    if (file_exists($dirPath) && is_dir($dirPath)) {
                        unlink($dirPath."qrcode.jpeg");
                        rmdir($dirPath);
                    }
                }

                    $statusResponse = $this->qrCodecall->getVirtualAccStatus($url);

                     $logger->info('<===virtualacc status ===>');
                    $logger->info("==Response ==" .json_encode($statusResponse));

                if (isset($statusResponse['amount_expected']) && isset($statusResponse['amount_paid']) &&
                        $statusResponse['amount_expected'] == $statusResponse['amount_paid']) {

                    // get va payment Details start
                    $paymentUrl = $url.'/payments';
                    $paymentResponse = $this->qrCodecall->getPaymentDetails($paymentUrl);

                    if (isset($paymentResponse['items']) && is_array($paymentResponse['items'])) {
                        foreach ($paymentResponse['items'] as $payData) {
                            if ($payData['entity'] == 'payment') {
                                //storing extra data
                                $arraymerge['razorpay_payment_id'] = $payData['id'];
                                $arraymerge['razorpay_order_id'] =   $vitualAccrountId;
                                $payData = array_merge($arraymerge, $payData);
                                $paymentResponse = json_encode($payData);
                                break;
                            }
                        }
                    }
                    // get va payment Details end

                    // get close payment
                    if ($closeStatus === false) {
                        $this->qrCodecall->closePopup($url);
                        $response['close_popup'] = true;
                         // remove media file
                        $dirPath = BP . \Razorpay\Magento\Model\QrCode\CurlCalls::QR_CORE_PATH.  $orderId . '/';
                        if (file_exists($dirPath) && is_dir($dirPath)) {
                            unlink($dirPath."qrcode.jpeg");
                            rmdir($dirPath);
                        }
                    }

                    // update order status
                    $orderFactory = $this->_orderInterfaceFactory->create()->loadByIncrementId($orderId);

                    $orderFactory->setStatus("order_placed");
                    $orderFactory->save();

                    // updare razorpay payment
                    $razormodel = $this->razorpayPayment->getCollection()
                        ->addFieldToFilter('razorpay_order_id', $vitualAccrountId)
                            ->addFieldToFilter('transaction_type', 'payment')
                            ->getFirstItem();
                    if ($razormodel && $razormodel->getId() > 0) {

                        if (isset($paymentResponse)) {
                            $razormodel->setRazorpayResponse($paymentResponse);
                        }
                        $razormodel->setTransactionStatus('success');
                        $razormodel->save();
                    }
                }
            }

            $result = $this->_resultJsonFactory->create();
            $result->setData($response);
            return $result;
        } catch (\Exception $e) {
            $logger->info('Error in controller CheckStatus and reason:  ' . $e->getMessage());
            $result = $this->_resultJsonFactory->create();
            $result->setData($response);
            return $result;
        }
    }
}
