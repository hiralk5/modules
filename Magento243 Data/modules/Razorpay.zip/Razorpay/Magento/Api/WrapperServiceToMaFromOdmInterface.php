<?php
namespace Razorpay\Magento\Api;

interface WrapperServiceToMaFromOdmInterface
{

        /**
         * GET for Post API
         * @param string $event
         * @return array[]
         */

    public function getCreateorUpdateJob($event);
}
