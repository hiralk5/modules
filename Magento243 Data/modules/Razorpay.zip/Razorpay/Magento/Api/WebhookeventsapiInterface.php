<?php

namespace Razorpay\Magento\Api;

interface WebhookeventsapiInterface
{

    /**
     * GET for Post API
     * @param string $orderid
     * @return \Razorpay\Magento\Api\Data\WebhookeventsDataInterface
     */
    public function getWebhookevents();
}
