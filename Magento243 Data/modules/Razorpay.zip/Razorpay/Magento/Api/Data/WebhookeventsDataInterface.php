<?php

namespace Razorpay\Magento\Api\Data;

interface WebhookeventsDataInterface
{

     /**
      * @return string
      */
    public function getOrderid();
 
    /**
     * @param string $Orderid
     * @return $this
     */
    public function setOrderid($Orderid);
     /**
      * @return string
      */
    public function getIncremental_id();
 
    /**
     * @param string $Incremental_id
     * @return $this
     */
    public function setIncremental_id($Incremental_id);
     /**
      * @return string
      */
    public function getevent_name();

    /**
     * @param string $event_name
     * @return $this
     */
    public function setevent_name($event_name);
    /**
     * @return string
     */
    public function getevent_json();

    /**
     * @param string $event_json
     * @return $this
     */
    public function setevent_json($event_json);
     /**
      * @return string
      */
    public function getdate_time();

    /**
     * @param string $date_time
     * @return $this
     */
    public function setdate_time($date_time);
    
     /**
      * @return string
      */
    public function getStatus();
 
    /**
     * @param string $Status
     * @return $this
     */
    public function setStatus($Status);
}
