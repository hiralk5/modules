<?php
namespace Razorpay\Magento\Api;

interface PostManagementInterface
{


    /**
     * GET for Post api
     * @param string $customerId
     * @return string
     */
    
    public function getPost();
}
