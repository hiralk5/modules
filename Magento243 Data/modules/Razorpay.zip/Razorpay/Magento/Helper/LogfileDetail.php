<?php

/*
 * ALL Log Files location details
 *
 */

namespace Razorpay\Magento\Helper;

class LogfileDetail extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * @var \Magento\Framework\Stdlib\DateTime\DateTime
     */
    private $dateTimeModel;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\Stdlib\DateTime\DateTime $dateTimeModel
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTimeModel
    ) {
        $this->dateTimeModel = $dateTimeModel;
        parent::__construct($context);
    }

    /**
     *
     * @return \Zend\Log\Logger
     */
    public function createJobLog()
    {
        $date = $this->dateTimeModel->gmtDate('d-m-Y');
        $dirPath = BP . '/var/log/razorpay/createjob/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $writer = new \Zend_Log_Writer_Stream($dirPath.'createjob-'.$date.'.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        return $logger;
    }

    /**
     *
     * @return \Zend_Log
     */
    public function cancelJobLog()
    {
        $date = $this->dateTimeModel->gmtDate('d-m-Y');
        $dirPath = BP . '/var/log/razorpay/canceljob/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $writer = new \Zend_Log_Writer_Stream($dirPath.'canceljob-'.$date.'.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        return $logger;
    }

    /**
     *
     * @return \Zend_Log
     */
    public function qrCodeLog()
    {
         $date = $this->dateTimeModel->gmtDate('d-m-Y');
        $dirPath = BP . '/var/log/razorpay/qrcode/';
        if (!file_exists($dirPath)) {
            mkdir($dirPath, 0775, true);
        }
        $writer = new \Zend_Log_Writer_Stream($dirPath.'qrcode-'.$date.'.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        return $logger;
    }
}
