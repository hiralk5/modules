<?php
/**
 * @Package        : Razorpay_Magento
 * @Description    : Apis for Transfer razorpay Amount
 * @Developer      : Shaunak Datar<shaunak.datar@embitel.com>
 * @Copyright      : Embitel Technologies Pvt Ltd.
 */
namespace Razorpay\Magento\Helper;

require_once __DIR__ . "../../../Razorpay/Razorpay.php";

use Razorpay\Magento\Model\RazorpayPayments;
use Magento\Checkout\Model\Session as CheckoutSession;
use Razorpay\Api\Api;
use Razorpay\Magento\Model\Config;
use Razorpay\Magento\Model\DealerRazorpayRule;
use Embitel\ApiCalls\Helper\Data as Apihelper;
use Embitel\SellerModule\Model\CustomSellerInfo;
use Magento\Sales\Model\OrderFactory;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use Razorpay\Magento\Model\RazorpayWebhookEventFactory;

class RazorpayHelper extends \Magento\Framework\App\Helper\AbstractHelper
{
    public const ACTIVE = 'Active';
    public const INACTIVE = 'Inactive';
    public const TUNE_SCRIPT = 'razorpay/tune_script/tune_script_details';

    /**
     * @var Razorpay\Magento\Model\RazorpayPayments
     */
    protected $_razorPayPayment;

    /**
     * @var Razorpay\Magento\Model\Config
     */
    protected $_config;

    /**
     * @var Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    protected $key_id;

    protected $key_secret;

    /**
     * @var Razorpay\Magento\Model\DealerRazorpayRule
     */
    protected $dealerRazorpayRule;

    /**
     * @var Embitel\ApiCalls\Helper\Data
     */
    protected $apiHelper;

    /**
     * @var Embitel\SellerModule\Model\CustomSellerInfo
     */
    protected $customSellerInfo;

    /**
     * @var Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * @var RazorpayWebhookEventFactory
     */
    protected $razorpaywebhookeventFactory;

    /**
     * @var \Magento\Variable\Model\VariableFactory
     */
    private $_varFactory;

    /**
     * @param RazorpayPayments $razorPayPayment
     * @param CheckoutSession $checkoutSession
     * @param Config $config
     * @param DealerRazorpayRule $dealerRazorpayRule
     * @param Apihelper $apiHelper
     * @param CustomSellerInfo $customSellerInfo
     * @param OrderFactory $orderFactory
     * @param ScopeConfigInterface $scopeConfig
     * @param RazorpayWebhookEventFactory $razorpaywebhookeventFactory
     * @param \Magento\Variable\Model\VariableFactory $varFactory
     */
    public function __construct(
        RazorpayPayments $razorPayPayment,
        CheckoutSession $checkoutSession,
        Config $config,
        DealerRazorpayRule $dealerRazorpayRule,
        Apihelper $apiHelper,
        CustomSellerInfo $customSellerInfo,
        OrderFactory $orderFactory,
        ScopeConfigInterface $scopeConfig,
        RazorpayWebhookEventFactory $razorpaywebhookeventFactory,
        \Magento\Variable\Model\VariableFactory $varFactory
    ) {
        $this->_razorPayPayment = $razorPayPayment;
        $this->_checkoutSession = $checkoutSession;
        $this->_config = $config;
        $this->dealerRazorpayRule = $dealerRazorpayRule;
        $this->key_id = $this->_config->getConfigData(Config::KEY_PUBLIC_KEY);
        $this->key_secret = $this->_config->getConfigData(Config::KEY_PRIVATE_KEY);
        $this->apiHelper = $apiHelper;
        $this->customSellerInfo = $customSellerInfo;
        $this->orderFactory = $orderFactory;
        $this->scopeConfig = $scopeConfig;
        $this->razorpaywebhookeventFactory = $razorpaywebhookeventFactory;
        $this->_varFactory = $varFactory;
    }

    /**
     *
     * @return type
     */
    public function getStatus()
    {
        $params = [
            '' => '-please select-',
            '1' => self::ACTIVE,
            '0' => self::INACTIVE
        ];
        return $params;
    }

    /**
     * @description Below function checks if order present in razorpay database table and returns the count accordingly
     */
    public function checkRazorpayOrder()
    {
        if ($this->_checkoutSession->getLastOrderId()) {
            $order = $this->_checkoutSession->getLastRealOrder();
            $razorpayData = $this->_razorPayPayment->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $order->getEntityId()])
                ->addFieldToFilter('transaction_status', ['eq' => "success"]);
            return $razorpayData->count();
        }
    }

    /**
     * @description Below function checks if dealer present in dealer_razorpay_rule table
     */
    public function checkRazorpayDealer($dealerId = null)
    {
        if ($dealerId != null) {
            $result = $this->dealerRazorpayRule->getCollection()
                ->addFieldToFilter("dealer_id", ['eq' => $dealerId])->addFieldToFilter("status", ['eq' => 1]);
            if ($result->count() > 0) {
                return $result->count();
            }
        }
        return false;
    }

    /**
     * @description Below function checks if order refund entry is there or not in system
     */
    public function checkRazorpayRefund($order_id)
    {
        $transaction_flags = [1,2,3,4];
        $razorpayData = $this->_razorPayPayment->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $order_id])
                ->addFieldToFilter('transaction_flag', ['in' => $transaction_flags])
                ->addFieldToFilter('transaction_status', ['eq' => "Success"]);
        if ($razorpayData->count() > 0) {
            return true;
        }
        return false;
    }

    public function refundPayment($razorpayPaymentId = null)
    {
        if ($razorpayPaymentId != null) {
            $api = new Api($this->key_id, $this->key_secret);
            $result = $api->payment->fetch($razorpayPaymentId)->refund();
            return $result;
        }
    }

    public function refundPaymentWithReverse($razorpayPaymentId = null)
    {
        if ($razorpayPaymentId != null) {
            $option = ["reverse_all" => 1];
            $attributes = http_build_query($option);
            $url = "https://api.razorpay.com/v1/payments/".$razorpayPaymentId."/refund";
            $autKey = $this->key_id . ':' . $this->key_secret;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url."?".$attributes);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($attributes));
            curl_setopt($ch, CURLOPT_USERPWD, $autKey);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            return $response = curl_exec($ch);
        }
    }

    public function downloadCsv($file)
    {
        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename=' . basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
        }
    }

    /**
     *
     * @param $paymentId
     * @param $requestPacket
     * @return false
     */
    public function transferByPaymentId($paymentId, $requestPacket = null)
    {
        if ($requestPacket != null) {
            $api = new Api($this->key_id, $this->key_secret);
            $result = $api->payment->fetch($paymentId)->transfer($requestPacket);
            return $result;
        }
        return false;
    }

    /**
     * @description Below function checks if order refund entry is there or not in system
     */
    public function checkRazorpayTransfer($order_id)
    {
        $transaction_flags = [5,6];
        $razorpayData = $this->_razorPayPayment->getCollection()
                ->addFieldToFilter('order_id', ['eq' => $order_id])
                ->addFieldToFilter('transaction_flag', ['in' => $transaction_flags])
                ->addFieldToFilter('transaction_status', ['eq' => "Success"])
                ->addFieldToFilter('transaction_type', ['eq' => "transfer"])
                ->addFieldToFilter('transaction_to', ['eq' => "dealer"]);
        if ($razorpayData->count() > 0) {
            return true;
        }
        return false;
    }

    /**
     * @description Get Razorpay Order
     */
    public function getRazorpayOrder($orderId = null)
    {
        if ($orderId != null) {
            $razorpayData = $this->_razorPayPayment->getCollection()->addFieldToFilter('order_id', ['eq' => $orderId])
                    ->addFieldToFilter('transaction_status', ['eq' => "success"])
                    ->addFieldToFilter('transaction_type', ['eq' => "payment"]);
            if ($razorpayData->count() > 0) {
                return $razorpayData->getFirstItem();
            }
        }
        return false;
    }

    /**
     * @description Get Razorpay Order
     */
    public function getRazorpayOrderDetail($incrementId = null)
    {
        if ($incrementId != null) {
            $razorpayData = $this->_razorPayPayment->getCollection()->addFieldToFilter('order_increment_id', ['eq' => $incrementId])
                    ->addFieldToFilter('transaction_status', ['eq' => "success"])
                    ->addFieldToFilter('transaction_type', ['eq' => "payment"]);
            if ($razorpayData->count() > 0) {
                return $razorpayData->getFirstItem();
            }
        }
        return false;
    }

    /**
     * @description Create UPI Payment
     */
    public function createUpiPayment($attributes = null)
    {
        if ($attributes != null) {
            $attributes = http_build_query($attributes);
            $url = $this->apiHelper->getConfig('razorpay/vpa_payment_url/vpa_payment');
            $autKey = $this->key_id . ':' . $this->key_secret;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url."?".$attributes);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($attributes));
            curl_setopt($ch, CURLOPT_USERPWD, $autKey);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            return $response = curl_exec($ch);
        }
        return false;
    }

    /**
     * @description Create UPI Payment
     */
    public function validateVpa($vpa = null)
    {
        if ($vpa != null) {
            $url = $this->apiHelper->getConfig('razorpay/vpa_validate_url/vpa_validate');
            $autKey = $this->key_id . ':' . $this->key_secret;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url."?vpa=".$vpa);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($attributes));
            curl_setopt($ch, CURLOPT_USERPWD, $autKey);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            return $response = curl_exec($ch);
        }
        return false;
    }

    /**
     *
     * @param $seller_id
     * @return bool
     */
    public function checkFPDealer($seller_id = null)
    {
        if ($seller_id != null) {
            $result = $this->dealerRazorpayRule->getCollection()->addFieldToFilter("dealer_id", ['eq' => $seller_id])
                ->addFieldToFilter("full_payment_flag", ['eq' => 1])->addFieldToFilter("status", ['eq' => 1]);
            if ($result->count() > 0) {
                return true;
            }
        }
            return false;
    }

    /**
     *
     * @param $params
     * @return bool
     * @throws \Exception
     */
    public function RazorpayExceptions($params = null)
    {
        if ($params != null) {
            $this->_razorPayPayment->addData($params);
            $this->_razorPayPayment->save();
            return true;
        }
        return false;
    }

    /**
     *
     * @param $status
     * @param $order
     * @param $transaction_status_flag
     * @return string|void
     */
    public function RazorpayTransactionOnStatus($status = null, $order = null, $transaction_status_flag = null)
    {
        if ($status != null && $order != null) {
            $razorpay_order_id = '';
              $resultArr = '';
            //$razorpayData = $this->razorpayPayments->getCollection()
            //->addFieldToFilter('order_id',['eq' => $order->getId()])
            //->addFieldToFilter('transaction_flag',['eq' => 0])
            //->addFieldToFilter('transaction_type',['eq' => 'payment'])
            //->addFieldToFilter('transaction_status',['eq' => 'success']);
            $razorpayData = $this->getRazorpayOrder($order->getId());
            /*Razorpay Transfer To Dealer Code - Added by Shaunak Datar*/
            $requestPacket = null;
            if ($status == "product_delivered" && ($razorpayData)) {
                $dirPath = BP . '/var/log/razorpay/';
                if (!file_exists($dirPath)) {
                    mkdir($dirPath, 0775, true);
                }



                /*Getting Dealer Id*/
                $dealerCollection = $this->customSellerInfo->getCollection()
                    ->addFieldToFilter('order_id', $order->getId());
                $dealerCollection = $dealerCollection->getFirstItem();
                $dealerid = $dealerCollection->getSellerId();

                $razorpay_order_id = $razorpayData->getRazorpayOrderId();
                $amount = $razorpayData->getAmount();
                $transaction_status = '';
                $transaction_type = 'transfer';
                $transaction_to = 'dealer';
                $transaction_flag = 5;
                if ($transaction_status_flag != null) {
                    $transaction_flag = $transaction_status_flag;
                }

                $amount = $razorpayData->getAmount();
                $resultArr = [];
                try {
                    $transferStatus = $this->checkRazorpayTransfer($order->getId());
                    if (!$transferStatus) {

                        $razorpayResponse = json_decode($razorpayData->getRazorpayResponse(), true);
                        if (isset($razorpayResponse['razorpay_payment_id'])) {

                            $DealerData = $this->dealerRazorpayRule->getCollection()->addFieldToFilter("dealer_id", ['eq' => $dealerid]);
                            if ($DealerData->count() > 0) {
                                $razorpay_account_number = $DealerData->getFirstItem()->getDealerRazorpayAccount();
                                $isfpDealerEnabled = $DealerData->getFirstItem()->getFullPaymentFlag();
                                $isfpEnabled =  $this->apiHelper->getConfig('razorpay/razorpay_fp_config/enabled_razorpay_fp');
                                $percent_deduct = "";
                                if ($razorpayData->getPaymentFlag() == 1 && $isfpDealerEnabled == 1 && $isfpEnabled == 1) {
                                    $percent_deduct = $DealerData->getFirstItem()->getFpDeductionPercentage();
                                } else {
                                    $percent_deduct = $DealerData->getFirstItem()->getDefaultPercentage();
                                }


                                $deducted_amount = $percent_deduct * $amount;
                                $deducted_amount = $deducted_amount / 100;
                                $transferAmount = $amount - $deducted_amount;
                                $transferAmount = round($transferAmount);


                                /*Preparing Notes & Amount*/
                                $firstName = $order->getCustomerFirstname();
                                $lastName = $order->getCustomerLastname();
                                $incrementId = $order->getIncrementId();
                                //$notes = array('order_id' => $order->getEntityId(),'roll_no' => $incrementId,'name' => $firstName.' '.$lastName);
                                $notes = $this->getPushFieldsNotes($order->getEntityId(), $incrementId, $order->getDeliveryDate());
                                $deducted_amount = $amount - $transferAmount;

                                /*Fetching BFL account*/
                                $BlfAccountRazorpay = $this->apiHelper->getConfig('razorpay/rzp_transfer/rzp_bfl_account');

                                /*Preparing Request*/
                                $requestPacket = [
                                    "transfers" => [
                                        ['account' => $razorpay_account_number,'amount' => $transferAmount,'currency' => 'INR','notes' => $notes],
                                        ['account' => $BlfAccountRazorpay,'amount' => $deducted_amount,'currency' => 'INR','notes' => $notes]
                                    ]
                                ];


                                $result = $this->transferByPaymentId($razorpayResponse['razorpay_payment_id'], $requestPacket);
                                if (isset($result['items'][0]['id'])) {
                                    $transaction_status = "success";
                                    $resultArr[] = (array)$result['items'][0];
                                    $resultArr[] = (array)$result['items'][1];
                                    $amount = $transferAmount;
                                } else {
                                    $transaction_status = "fail";
                                    $resultArr = (array)$result;
                                }

                            }
                        }
                    } else {

                    }
                } catch (\Exception $e) {
                    $transaction_status = "fail";
                    $resultArr = ["error" => $e->getMessage()];

                }
            }

            /*Razorpay Refund Code - Added by Shaunak Datar*/

            if ($status == "canceled" && ($razorpayData)) {
                $dirPath = BP . '/var/log/razorpay/';
                if (!file_exists($dirPath)) {
                    mkdir($dirPath, 0775, true);
                }
                $razorpaywriter = new \Zend_Log_Writer_Stream(BP . '/var/log/razorpayRefund.log');
                $razorpaylogger = new \Zend_Log();
                $razorpaylogger->addWriter($razorpaywriter);
                $razorpaylogger->info("========Razorpay Order Cancel From ODM API==============");
                $razorpaylogger->info("Order ID:".$order->getId());
                $razorpaylogger->info("Increment ID:".$order->getIncrementId());
                //$razorpayData = $razorpayData->getFirstItem();
                $razorpay_order_id = $razorpayData->getRazorpayOrderId();
                $transaction_status = '';
                $transaction_type = 'refund';
                $transaction_to = 'customer';
                $transaction_flag = 4;
                if ($transaction_status_flag != null) {
                    $transaction_flag = $transaction_status_flag;
                }
                $amount = $razorpayData->getAmount();
                $resultArr = '';
                try {
                    $refundStatus = $this->checkRazorpayRefund($order->getId());
                    if (!$refundStatus) {

                        $razorpayResponse = json_decode($razorpayData->getRazorpayResponse(), true);

                        /*Request Packet*/

                        if (isset($razorpayResponse['razorpay_payment_id'])) {
                            $requestPacket = ["payment_id" => $razorpayResponse['razorpay_payment_id'],"order_id" => $order->getIncrementId()];
                            $razorpaylogger->info("--------Request Packet---------");
                            $razorpaylogger->info(json_encode($requestPacket));
                            $razorpaylogger->info("Razorpay Payment ID:".$razorpayResponse['razorpay_payment_id']);
                            $result = $this->refundPayment($razorpayResponse['razorpay_payment_id']);
                            $resultArr = (array)$result;
                            if (isset($result['id'])) {
                                $transaction_status = 'success';
                            } else {
                                $transaction_status = 'fail';
                            }
                            $razorpaylogger->info("========Refund Response Packet========");
                            $razorpaylogger->info(json_encode($resultArr));
                        }
                    }
                } catch (\Exception $e) {
                          $razorpaylogger->info("Razorpay Error:".$e->getMessage());
                          $transaction_status = 'fail';
                          $resultArr = ["error" => $e->getMessage()];

                }
            }
            /*Save Data to razorpay_payments table*/
            if ($resultArr != '') {
                try {
                      $razorpay = $this->_razorPayPayment;
                      $razorpay->setOrderId($order->getId());
                      $razorpay->setOrderIncrementId($order->getIncrementId());
                      $razorpay->setRazorpayOrderId($razorpay_order_id);
                      $razorpay->setRazorpayRequest(json_encode($requestPacket));
                      $razorpay->setRazorpayResponse(json_encode($resultArr));
                      $razorpay->setTransactionFlag($transaction_flag);
                      $razorpay->setTransactionType($transaction_type);
                      $razorpay->setTransactionStatus($transaction_status);
                      $razorpay->setTransactionTo($transaction_to);
                      $razorpay->setAmount($amount);
                      $razorpay->save();
                      return $transaction_status;
                } catch (\Exception $e) {
                    $razorpaylogger->info("Razorpay Error:".$e->getMessage());
                }
            }
        }
    }

    /**
     *
     * @param $increment_id
     * @return false|int
     */
    public function isRazorpayOrderFailure($increment_id = null)
    {
        if ($increment_id != null) {
            $razorpayData = $this->_razorPayPayment->getCollection()
                ->addFieldToFilter('order_increment_id', ['eq' => $increment_id])
                ->addFieldToFilter('transaction_status', ['eq' => "fail"])
                ->addFieldToFilter('transaction_type', ['eq' => "payment"])
                ->addFieldToFilter('retry_count', ['gteq' => "3"]);
            return $razorpayData->count();
        }
        return false;
    }

    /**
     *
     * @param $increment_id
     * @return false|int
     */
    public function isRazorpayOrderSuccess($increment_id = null)
    {
        if ($increment_id != null) {
            $razorpayData = $this->_razorPayPayment->getCollection()
                ->addFieldToFilter('order_increment_id', ['eq' => $increment_id])
                ->addFieldToFilter('transaction_status', ['eq' => "success"]);
            return $razorpayData->count();
        }
        return false;
    }

    /**
     * Fetches product type
     *
     * @param $increment_id
     * @return false
     */
    public function getOrderItemType($increment_id = null)
    {
        if ($increment_id != null) {
            $order_data = $this->orderFactory->create()->loadByIncrementId($increment_id);
            $orderItems = $order_data->getAllVisibleItems();
            foreach ($orderItems as $item) {
                return $item->getProductType();
            }
        }
        return false;
    }

    /**
     *
     * @return type
     */
    public function getTuneScript()
    {
        return $this->scopeConfig->getValue(self::TUNE_SCRIPT, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    /**
     *
     * @return mixed
     */
    public function getKeyid()
    {
        return $this->key_id;
    }

    /**
     *
     * @param $disposition
     * @return mixed
     */
    public function dispositionType($disposition)
    {
        try {
            $result = $this->_varFactory->create()->loadByCode('razorpay_msgs')->getHtmlValue();
            $dispositionVals = $this->_varFactory->create()->loadByCode('razorpay_msgs')->getPlainValue();
            $dispositionVals = json_decode($dispositionVals);
            foreach ($dispositionVals as $key => $value) {
                if ($disposition == $key) {
                    $result =  $value;
                }
            }
        } catch (Exception $ex) {

        }
        return $result;
    }

    /**
     *
     * @param $order_id
     * @param $incrementId
     * @param $delivery_date
     * @return array|void
     */
    public function getPushFieldsNotes($order_id, $incrementId, $delivery_date)
    {
        if ($order_id != '') {
            $SellerInfoCollection = $this->customSellerInfo->getCollection()->addFieldToFilter('order_id', $order_id);
            $SellerInfoCollection = $SellerInfoCollection->getFirstItem();
            return [
                'order_id' => $incrementId,
                'dealer_name'=>$SellerInfoCollection->getSellerName(),
                'dealer_id'=>$SellerInfoCollection->getSellerId(),'delivery_date'=>$delivery_date
            ];
        }
    }

    /**
     *
     * @param $payload
     * @param $logger
     * @return void
     */
    public function SaveRazorpaywebhookevent($payload, $logger)
    {
        $logger->info("======== Webhook event Save in razorpay event table ==========");
        $event_name = isset($payload['event']) ? $payload['event'] : '';
        $order_id = isset($payload['payload']['payment']['entity']['order_id']) ? $payload['payload']['payment']['entity']['order_id'] : '';
        $order_increment_id = "";
        if (isset($payload['payload']['order']['entity']['notes']['order_id'])) {
            $order_increment_id = $payload['payload']['order']['entity']['notes']['order_id'];
        }
        try {
            $logger->info("Event Name: ".$event_name." order_id: ".$order_id);
            if (($order_id != '') && ($event_name != '') && ($order_increment_id != '')) {
                $razorpaywebhookeventdata = $this->razorpaywebhookeventFactory->create();
                $razorpaywebhookeventdata->setOrderid($order_id);
                $razorpaywebhookeventdata->setIncrementalId($order_increment_id);
                $razorpaywebhookeventdata->setEventName($event_name);
                $razorpaywebhookeventdata->setEventJson(json_encode($payload));
                $razorpaywebhookeventdata->save();
                $logger->info("======== Webhook event Saved ==========");
            }
        } catch (\Exception $e) {
            $logger->info("Webhook events store Error:" . $e->getMessage());
        }
    }
}
