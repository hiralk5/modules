<?php

/**
 * RAZORPAY FULLPAYMENT order API helper
 *
 * @category  Embitel
 * @package   Embitel_CashOnDelivery
 * @author    bratati <bratati.dolai@embitel.com>
 * @copyright 2017-2018 Embitel technologies (I) Pvt. Ltd
 */
namespace Razorpay\Magento\Helper;

use Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    public const CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER = 'atos_configuration/orderpush/orderpush_email';

    public const ORDER_API_FAILED_EMAIL = 'razorpay/mediaagility_api_detail/orderpush_failed_email_template';

    /**
     * @var \Magento\Framework\Pricing\Helper\Data
     */
    private $pricingHelper;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    private $transportBuilder;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Embitel\SellerModule\Model\CustomSellerInfo
     */
    private $sellerInfoModel;

    /**
     * @var \Razorpay\Magento\Model\OrderPush
     */
    private $orderPushModel;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Razorpay\Magento\Model\OrderPush $orderPushModel
     * @param \Embitel\SellerModule\Model\CustomSellerInfo $sellerInfoModel
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Pricing\Helper\Data $pricingHelper
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Razorpay\Magento\Model\OrderPush $orderPushModel,
        \Embitel\SellerModule\Model\CustomSellerInfo $sellerInfoModel,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Pricing\Helper\Data $pricingHelper
    ) {
        $this->orderPushModel = $orderPushModel;
        $this->sellerInfoModel = $sellerInfoModel;
        $this->storeManager = $storeManager;
        $this->transportBuilder = $transportBuilder;
        $this->pricingHelper = $pricingHelper;
        parent::__construct($context);
    }

    /**
     *
     * @param $order
     * @return array
     */
    public function orderPushReqBody($order)
    {
        $bodyData = [];
        if ($order->getId() > 0) {
            $items = $order->getAllVisibleItems();
            if (is_array($items) && count($items) > 0) {
                $templateId = $this->scopeConfig->getValue(
                    'razorpay/mediaagility_api_detail/templatetype',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                );

                // payment method start
                $paymentMethod = $this->scopeConfig->getValue(
                    'razorpay/mediaagility_api_detail/payment_method',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                );
                if (empty($paymentMethod)) {
                    $paymentMethod = 'credit card/UPI';
                }
                 // payment method end

                // expectedtime start
                $expectedHrs = $this->scopeConfig->getValue(
                    'razorpay/mediaagility_api_detail/expected_time',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                );
                if (empty($expectedHrs)) {
                    $expectedHrs = 4;
                }
                $currentTimeZoneSet= date_default_timezone_get(); // setting default timezone
                date_default_timezone_set('Asia/Kolkata');
                $startTime = date("Y-m-d H:i:s");
                date_default_timezone_set($currentTimeZoneSet); // setting default timezone
                $expectedTime = date('d/m/Y h:m a', strtotime('+'. (int)$expectedHrs .'hour', strtotime($startTime)));

                $customerName = $order->getCustomerName();
                $mobileNo = $order->getBillingAddress()->getTelephone();

                //production support @30-4-2020 start
                $basegrandTotal = $order->getBaseGrandTotal();
                $basegrandTotal = $this->pricingHelper->currency($basegrandTotal, false, false);
               //end

                // parameter build start
                $bodyData = ['templateType' => $templateId];
                foreach ($items as $item) {
                    $bodyData['fields'][]= ['name' => 'jobCode', 'inputValue' => $order->getIncrementId()];
                    $bodyData['fields'][] = ['name' => 'subject', 'inputValue' => $item->getSku()];


                    //totalCashcalculation
                    $sellerrInfo = $this->getSellerInfo($item->getId());
                    $dealerId = isset($sellerrInfo['seller_id']) ? $sellerrInfo['seller_id'] : 0;
                   // $dealerId = '335555'; // need to revert back after
                    $bodyData['fields'][] = ['name' => 'description', 'inputValue' =>   sprintf(
                        "%s",
                        $basegrandTotal
                    )];
                    $bodyData['fields'][] = ['name' => 'expectedTime','inputValue' => $expectedTime];
                    $bodyData['fields'][] = ['name' => 'sticky','inputValue' => 0];
                    $bodyData['fields'][] = ['name' => 'owner', 'inputValue' => 0];
                    $bodyData['fields'][] = ['name' => 'dealerId', 'inputValue' => $dealerId];
                    $bodyData['fields'][] = ['name' => 'totalAmount','inputValue' =>  sprintf(
                        "%s",
                        $basegrandTotal
                    )];
                    $bodyData['fields'][] = ['name' => 'collectableAmount','inputValue' => 0];
                    $bodyData['fields'][] = ['name' => 'customerName','inputValue' => $customerName];
                    $bodyData['fields'][] = ['name' => 'customerMobileNo','inputValue' => $mobileNo];
                    $bodyData['fields'][] = ['name' => 'dropAddress','inputValue' =>$this->getShippingFormatedAddress($order)];
                    $bodyData['fields'][] = ['name' => 'customerId','inputValue' =>$paymentMethod]; // this is cod payment
                }

                $requestBody =  json_encode($bodyData);

                $this->orderPushModel
                        ->setOrderIncrementId($order->getIncrementId())
                        ->setCreateJobRequestBody($requestBody)
                        ->setOrderPushFlag(1)
                        ->save();
            }
        }

        return $bodyData;
    }

    /**
     *
     * @param $itemId
     * @return array
     */
    public function getSellerInfo($itemId)
    {
        $sellerrInfo = ['seller_id' => 0, 'cash_amount' => 0, 'seller_address'=> ''];
        $sellcollection = $this->sellerInfoModel->getCollection()
           ->addFieldToFilter('order_item_id', $itemId);
        ;
        if ($sellcollection->count() > 0) {
            foreach ($sellcollection as $sellerQ) {
                $offerPrice = (!is_null($sellerQ->getOfferPrice()) )?  $sellerQ->getOfferPrice() : 0;
                $proFee = (!is_null($sellerQ->getProcessingFee())) ?  $sellerQ->getProcessingFee() : 0 ;
                $delCharg = (!is_null($sellerQ->getDeliveryCharges())) ?  $sellerQ->getDeliveryCharges() : 0;
                $discountAmt = (!is_null($sellerQ->getDiscountAmount())) ?  $sellerQ->getDiscountAmount() : 0;
                $isParentUploaded = (!is_null($sellerQ->getIsParentUploaded())) ?  $sellerQ->getIsParentUploaded() : 0;
                $parentDealerId = (!is_null($sellerQ->getParentDealerId())) ?  $sellerQ->getParentDealerId() : 0;

                // has parent dealer
                if ($isParentUploaded == 1 && $parentDealerId != 0) {
                    $sellerrInfo['seller_id'] = $parentDealerId;
                } else {
                    $sellerrInfo['seller_id'] = $sellerQ->getSellerId();
                }
                $sellerrInfo['scheme_id'] = $sellerQ->getSchemeId();

                //$sellerrInfo['cash_amount'] = ($offerPrice + $proFee + $delCharg - $discountAmt);
                $sellerrInfo['cash_amount'] = ($offerPrice);
            }
        }

        return $sellerrInfo;
    }

    /**
     *
     * @param $order
     * @return string
     */
    public function getShippingFormatedAddress($order)
    {
        $shipAddress = $city = $postcode = '';
        $shipstreet = [];
        $residenceState = ($order->getBillingAddress()->getRegion() != 'null' &&
            $order->getBillingAddress()->getRegion() != null) ? $order->getBillingAddress()->getRegion() : 'NoState';
        if ($order->getShippingAddress()) {
            $shipstreet = $order->getShippingAddress()->getStreet();
                $city = $order->getShippingAddress()->getCity();
                $postcode = $order->getShippingAddress()->getPostcode();
        }
        if (isset($shipstreet[1])) {
            $ship2 = $shipstreet[1];
        } else {
            $ship2 = 'NA';
        }
        if (isset($shipstreet[0])) {
            $shipAddress .= $shipstreet[0];
        }
        if (!empty($ship2)) {
            $shipAddress = ' ' .$ship2;
        }
        //$shipAddress = ' '. $order->getShippingAddress()->getCity() . ' '. $residenceState . ' '. $order->getShippingAddress()->getPostcode();
        $shipAddress .= ' '. $city . ' '. $residenceState . ' '. $postcode;

        return $shipAddress;
    }

    /**
     * Send Email of failed Order API
     *
     * @param $orderIncrmentId
     * @param $apiUrl
     * @param $requestData
     * @param $responseData
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function sendOrderPushApiFailedEmail($orderIncrmentId, $apiUrl, $requestData, $responseData)
    {
        $recipients = explode(",", $this->getEmailRecipient());
        if (!empty($recipients)) {
            $orderPushInfo = [];
            $orderPushInfo['order_id'] = $orderIncrmentId;
            $orderPushInfo['order_push_url'] = $apiUrl;
            $orderPushInfo['request_data'] = $requestData;
            $orderPushInfo['response_data'] = var_export($responseData, true);

            $postObject = new \Magento\Framework\DataObject();
            $postObject->setData($orderPushInfo);

            $templateData = ['orderpush' => $postObject];

            $storeId = $this->storeManager->getStore()->getId();

            // @var \Magento\Framework\Mail\Template\TransportBuilder $transport
            $transport = $this->transportBuilder->setTemplateIdentifier(
                $this->getEmailTemplateId()
            )->setTemplateOptions(
                ['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $storeId]
            )->setTemplateVars(
                $templateData
            )->setFrom(
                $this->getsender()
            )->addTo(
                $recipients
            )->getTransport();

             $transport->sendMessage();
        }

        return $this;
    }

     /**
      * Get Sender details from configuration.
      *
      * @param  string $type
      * @param  integer $storeId
      * @return  array
      */
    public function getSender()
    {
        $senderName = $this->scopeConfig->getValue('trans_email/ident_general/name', ScopeInterface::SCOPE_STORE);
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_general/email', ScopeInterface::SCOPE_STORE);

        $sender ['name'] = $senderName;
        $sender ['email'] = $senderEmail;

        return $sender;
    }

    /**
     * Retrieve Template id of order push failed from configuration.
     *
     * @param  integer $storeId
     * @return string
     */
    public function getEmailTemplateId()
    {
        return 'razorpay_mediaagility_api_detail_orderpush_failed_email_template';
    }

    /**
     * Get Email Recipients from configuration.
     *
     * @param  integer $storeId
     * @return string]
     */
    public function getEmailRecipient($storeId = null)
    {
        return  $this->scopeConfig->getValue(
            self::CONFIG_NOTIFY_CUSTOMER_EMAIL_RECEIVER,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }
}
