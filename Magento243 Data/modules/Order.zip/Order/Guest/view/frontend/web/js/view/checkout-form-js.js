define([
    'ko',
    'uiComponent',
    'Magento_Customer/js/model/customer',
    'jquery',
    'mage/url'
    ], function (ko, Component, customer,urlBuilder,jquery) {

    "use strict";
    return Component.extend({   
        defaults: {
            template: 'Order_Guest/checkout-form'
        },
        isGuest: true,
        initialize: function () {
            this._super();
        },
        isLoggedIn: function () {
            console.log("customer");
            return customer.isLoggedIn();
        }
     // var param = $('[name="isguest"]').val();
     // alert(param);
        /*,initObservable: function () {

            this._super()
                .observe({
                    isGuest: ko.observable(false)
                });
            var isGuest=0;  
            self = this;
            this.isGuest.subscribe(function (newValue) {
                // var isGuestUrl  = urlBuilder.build('/Order_Guest/checkout/saveInQuote');
                // console.log(isGuestUrl);
                if(newValue) {
                    isGuest = 1;
                }
                else{
                    isGuest = 0;
                }
                jQuery.ajax({
                    showLoader: true,
                    // url: "/order_guest/checkout/saveInQuote",
                    data: {isGuest : isGuest},
                    type: "POST",
                    dataType: 'json',
                    
                }).done(function (data) {
                    console.log('success');
                });
            });
            return this;
        }*/
    });
});