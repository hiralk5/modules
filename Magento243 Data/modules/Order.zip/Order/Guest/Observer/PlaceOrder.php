<?php
namespace Order\Guest\Observer;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\QuoteFactory;
use Psr\Log\LoggerInterface;
// use Magento\Quote\Model\QuoteRepository;


class PlaceOrder implements ObserverInterface
{
    
    protected $_logger;
    protected $orderFactory;
    protected $quoteFactory;
    public function __construct(LoggerInterface $logger,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        // QuoteRepository $quoteRepository,
         \Magento\Checkout\Model\Session $checkoutSession,
        QuoteFactory $quoteFactory) {
        $this->_logger = $logger;
        $this->quoteFactory = $quoteFactory;
        $this->orderFactory = $orderFactory;
        $this->checkoutSession = $checkoutSession;
        // $this->quoteRepository = $quoteRepository;
    }
    public function execute(Observer $observer)
    {
        $observer = $observer->getEvent();
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('1');
        /*if($isGuest !== 0 && $isGuest !== null){
            $quoteId = $this->checkoutSession->getQuoteId();
            $quote = $this->quoteRepository->get($quoteId);
            $quote->setData('is_guest',1);
            $quote->save();
        }*/
        $quoteid = $observer->getQuote();
        //$quote  = $this->quoteFactory->create()->load($quoteid);
        $logger->info(json_encode($quoteid->getData()));
        $logger->info('2');
        $order = $observer->getOrder();
        // $salse_order  = $this->orderFactory->create()->load($order);
        $logger->info('3');
        $logger->info(json_encode(($order->getData())));
        $logger->info('4');
       
        // $quote->setIsGuest(1);
        // $quote->save();
/*        $logger->info(json_encode(($quoteid->getData())));
        $logger->info('456');
        $logger->info(json_encode(($order->getData())));
        $logger->info('123');*/
        // $salse_order->setData('is_guest',1);
        // $logger->info(json_encode($order));
        // $salse_order->save();
    }
}