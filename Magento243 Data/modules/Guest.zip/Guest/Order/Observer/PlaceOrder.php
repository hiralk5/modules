<?php
namespace Guest\Order\Observer;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\QuoteFactory;
use Psr\Log\LoggerInterface;

class PlaceOrder implements ObserverInterface
{
    /**
    * @var \Psr\Log\LoggerInterface
    */
    protected $_logger;

    /**
    * @var \Magento\Customer\Model\Session
    */
    protected $quoteFactory;

    /**
     * Constructor
     *
     * @param \Psr\Log\LoggerInterface $logger
     */

    public function __construct(LoggerInterface $logger,
        QuoteFactory $quoteFactory) {
        $this->_logger = $logger;
        $this->quoteFactory = $quoteFactory;
    }

    public function execute(Observer $observer)
    {
        // echo 123;die;
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info('Your text message');
        
        $order = $observer->getResult();
        $logger->info(json_encode($order));
        $quoteId = $order->getQuoteId();
        $logger->info(json_encode($quoteId));
        $quote  = $this->quoteFactory->create()->load($quoteId);
        $logger->info(json_encode($quoteId));
        exit;
        // $order->setIsGuest($quote->getIsGuest());
        // $order->save();
    }
}