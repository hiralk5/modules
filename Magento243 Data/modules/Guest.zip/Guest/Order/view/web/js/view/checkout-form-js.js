define([
	'ko',
	'uiComponent'
	], function (ko, Component) {

	"use strict";
	return Component.extend({
		defaults: {
			template: 'Order_Guest/checkout-form'
		},
		isGuest: true,
		initialize: function () {
            this._super();
        },
        initObservable: function () {

            this._super()
                .observe({
                    isGuest: ko.observable(false)
                });
            var isGuest=0;	
            self = this;
            this.isGuest.subscribe(function (newValue) {
                var linkUrls  = url.build('module/checkout/saveInQuote');
                if(newValue) {
                    isGuest = 1;
                }
                else{
                    isGuest = 0;
                }
                $.ajax({
                    showLoader: true,
                    url: linkUrls,
                    data: {isGuest : isGuest},
                    type: "POST",
                    dataType: 'json'
                }).done(function (data) {
                    console.log('success');
                });
            });
            return this;
        }
	});
});