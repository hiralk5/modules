<?php
namespace Guest\Order\Controller\Customer;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Http\Context as AuthContext;
class Index extends Action
{
    private $customerSession;
    private $authContext;
    public function __construct(Context $context, Session $session, AuthContext $authContext)
    {
        $this->customerSession = $session;
        $this->authContext = $authContext;
        parent::__construct($context);
    }
    public function execute()
    {
        // by using Session model
        if ($this->customerSession->isLoggedIn()) 
        {
            // customer login code
        }
        else
        {
            // customer not login
        }
        // using HTTP context
        $isLoggedIn = $this->authContext->getValue(\Magento\Customer\Model\Context::CONTEXT_AUTH);
        if ($isLoggedIn) 
        {
            //your coding
        }
    }
}