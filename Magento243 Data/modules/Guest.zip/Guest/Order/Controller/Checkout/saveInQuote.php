<?php

namespace Guest\Order\Controller\Checkout;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\ForwardFactory;
use Magento\Framework\View\LayoutFactory;
use Magento\Checkout\Model\Cart;
use Magento\Framework\App\Action\Action;
use Magento\Quote\Model\QuoteRepository;

class saveInQuote extends Action
{
    protected $resultForwardFactory;
    protected $layoutFactory;
    protected $cart;
    protected $_customerSession;
    protected $checkoutSession;

    public function __construct(
        Context $context,
        ForwardFactory $resultForwardFactory,
        LayoutFactory $layoutFactory,
        Cart $cart,
        \Magento\Checkout\Model\Session $checkoutSession,
        QuoteRepository $quoteRepository,
        \Magento\Customer\Model\Session $session
    )
    {
        $this->resultForwardFactory = $resultForwardFactory;
        $this->layoutFactory = $layoutFactory;
        $this->cart = $cart;
        $this->_customerSession = $session;
        $this->checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;

        parent::__construct($context);
    }

    public function execute()
    {
        if ($this->_customerSession->isLoggedIn()) {
    // Customer is logged in 

            $checkVal = $this->getRequest()->getParam('checkVal');
            $quoteId = $this->checkoutSession->getQuoteId();
            $quote = $this->quoteRepository->get($quoteId);
            $quote->setIsGuest($checkVal);
            $quote->save();
        }
    }
}